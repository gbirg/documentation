#!/bin/sh

kill -9 `ps -ef | grep org.eclipse.osgi-3.6.0.v20100517.jar | grep -v grep | awk '{print $2}'`

PRG="$0"

while [ -h "$PRG" ]; do
    ls=`ls -ld "$PRG"`
    link=`expr "$ls" : '.*-> \(.*\)$'`
    if expr "$link" : '/.*' > /dev/null; then
        PRG="$link"
    else
        PRG=`dirname "$PRG"`/"$link"
    fi
done
VCD_SYSTEM_HOME=`dirname "$PRG"`

# Absolute path
VCD_SYSTEM_HOME=`cd "$VCD_SYSTEM_HOME" ; pwd`

# echo Resolved VCD_SYSTEM_HOME: $VCD_SYSTEM_HOME
# echo "JAVA_HOME $JAVA_HOME"

cygwin=false;
case "`uname`" in
    CYGWIN*)
        cygwin=true
        ;;
esac

# Build a classpath containing our two magical startup JARs (we look for " /" as per ROO-905)
VCD_CP=`echo "$VCD_SYSTEM_HOME"/*.jar | sed 's/ \//:\//g'`
# echo VCD_CP: $VCD_CP

# Store file locations in variables to facilitate Cygwin conversion if needed

VCD_SYSTEM_OSGI_FRAMEWORK_STORAGE="$VCD_SYSTEM_HOME/cache"
# echo "VCD_SYSTEM_OSGI_FRAMEWORK_STORAGE: $VCD_SYSTEM_OSGI_FRAMEWORK_STORAGE"

VCD_SYSTEM_AUTO_DEPLOY_DIRECTORY="$VCD_SYSTEM_HOME/bundle"
# echo "VCD_SYSTEM_AUTO_DEPLOY_DIRECTORY: $VCD_SYSTEM_AUTO_DEPLOY_DIRECTORY"


cygwin=false;
case "`uname`" in
    CYGWIN*)
        cygwin=true
        ;;
esac

if [ "$cygwin" = "true" ]; then
	export VCD_SYSTEM_HOME=`cygpath -wp "$VCD_SYSTEM_HOME"`
	export VCD_CP=`cygpath -wp "$VCD_CP"`
	export VCD_SYSTEM_OSGI_FRAMEWORK_STORAGE=`cygpath -wp "$VCD_SYSTEM_OSGI_FRAMEWORK_STORAGE"`
	export VCD_SYSTEM_AUTO_DEPLOY_DIRECTORY=`cygpath -wp "$VCD_SYSTEM_AUTO_DEPLOY_DIRECTORY"`
fi

if [ "$1" = "start" ]; then
 mkdir -p logs
 touch "$VCD_SYSTEM_HOME"/logs/stdout.out
 java  -server -Dorg.osgi.framework.storage="$VCD_SYSTEM_OSGI_FRAMEWORK_STORAGE" \
 			-Duser.home="$VCD_SYSTEM_HOME/data" \
 			-Dvcd.config.path="$VCD_SYSTEM_HOME/configuration" \
 			-jar $VCD_CP -console -clean 2300 \
 			 >> "$VCD_SYSTEM_HOME"/logs/stdout.out 2>&1 &
  if [ ! -z "$VCD_PID" ]; then
        echo $! > $VCD_PID
  fi
elif [ "$1" = "stop" ]; then
  shift
  FORCE=0
  if [ "$1" = "-force" ]; then
    shift
    FORCE=1
  fi
    
telnet localhost 2300 << EOF
	exit
EOF
  
  if [ $FORCE -eq 1 ]; then
    if [ ! -z "$VCD_PID" ]; then
       echo "Killing: `cat $VCD_PID`"
       kill -9 `cat $VCD_PID`
    else
       echo "Kill failed: \$VCD_PID not set"
    fi
  fi
else

  echo "Usage: vcd-system.sh ( commands ... )"
  echo "commands:"
  echo "  start             Start VCD-System in a separate window"
  echo "  stop              Stop VCD-System"
  exit 1

fi

