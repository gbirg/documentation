
1- Edit the gen.bat script

2- The JAXWS_WSIMPORT variable must point to the wsimport.bat script of the JAX-WS 2.1.X

3- Launch the gen.bat script

The generated files will be located in the "gen" directory.
