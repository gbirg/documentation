/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 13 oct. 2010
 * Time: 12:15:33
 */
package eu.peppol.lsp.xkms.extensions;


public class PEPPOLConstants
{
	/**
	 * Name space URI of the PEPPOL XKMS extension v2.
	 */
	public static final String PEPPOL_XKMS_EXT_NAMESPACE_URI = "http://uri.peppol.eu/xkmsExt/v2#";
	
	public static final String CERT_QUALITY_URI = PEPPOL_XKMS_EXT_NAMESPACE_URI + "certquality";
	public static final String CSP_ASSURANCE_URI = PEPPOL_XKMS_EXT_NAMESPACE_URI + "CSPAssurance";
	public static final String VALIDATE_SCHEME_URI = PEPPOL_XKMS_EXT_NAMESPACE_URI + "valScheme";
	public static final String VALIDATE_MODEL_URI = PEPPOL_XKMS_EXT_NAMESPACE_URI + "valModel";
	public static final String REASON_URI = PEPPOL_XKMS_EXT_NAMESPACE_URI + "reason";
	public static final String REVOCATION_REASON_URI = PEPPOL_XKMS_EXT_NAMESPACE_URI + "revocationReason";
	
	/**
	 * Return acquired OCSP response for validated certificate (not multiple
	 * OCSPs of the whole chain!).
	 */
	public static final String RESPONDWITH_OCSP = PEPPOL_XKMS_EXT_NAMESPACE_URI + "OCSP";
	
	/**
	 * Return PEPPOL extended response. 
	 */
	public static final String RESPONDWITH_PEPPOL_EXTENDED = "http://uri.peppol.eu/xkmsExt/v2";
	
	/**
	 * Return information as defined by ETSI TS 102 231 for the according
	 * tsl:ServiceInformation element (contains - besides other details -
	 * the quality of certificate and status of issuing CSP).
	 */
	public static final String RESPONDWITH_TSL_SERVICE_INFORMATION = "http://uri.etsi.org/02231/v2#ServiceInformation";
	
	/**
	 * Return quality of certificate and status of issuing CSP according to the
	 * rating defined in chapter [?5.2] for eIDQuality (further detailed in
	 * PEPPOL D1.3 Part 7 "eID and eSignature Quality Classification").
	 * This is the default behaviour, if no element xkms:RespondWith or
	 * the foregoing xkms:RespondWith URI pointing to the ESI TSL alternative
	 * present in the request).
	 */
	public static final String RESPONDWITH_EID_QUALITY = PEPPOL_XKMS_EXT_NAMESPACE_URI + "eIDQuality";
	
	/**
	 * Attention: If not provided, XKMS responder MAY use cached OCSP response
	 * for validation (OCSP caching may be an implementation feature to reduce
	 * network latencies).
	 */
	public static final String RESPONDWITH_OCSP_NO_CACHE = PEPPOL_XKMS_EXT_NAMESPACE_URI + "OCSPNoCache";
	
	/**
	 * Details on validation process to be delivered.
	 */
	public static final String RESPONDWITH_VALIDATION_DETAILS = PEPPOL_XKMS_EXT_NAMESPACE_URI + "ValidationDetails";

}