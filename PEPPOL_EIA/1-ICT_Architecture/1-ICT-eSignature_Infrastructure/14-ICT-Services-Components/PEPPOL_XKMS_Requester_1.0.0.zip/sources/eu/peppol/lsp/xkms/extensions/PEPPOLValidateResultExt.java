/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 14 oct. 2010
 * Time: 08:06:59
 */
package eu.peppol.lsp.xkms.extensions;

import java.util.ArrayList;
import java.util.List;

import eu.peppol.lsp.xkms.jaxb.peppol.EIDQualityType;
import eu.peppol.lsp.xkms.jaxb.peppol.ErrorExtensionType;
import eu.peppol.lsp.xkms.jaxb.peppol.ResponderDetailsType;
import eu.peppol.lsp.xkms.jaxb.peppol.ValidateResultExtEUType;
import eu.peppol.lsp.xkms.jaxb.peppol.ValidationDetailsType;
import eu.peppol.lsp.xkms.jaxb.tsl.TSPServiceInformationType;

/**
 * This class represents the PEPPOL Validate Result extension which corresponds
 * with the ValidateResultExtEUType.
 */
public class PEPPOLValidateResultExt
{
	private CertificateQuality certQuality;
	private CSPAssurance cspAssurance;
	private TSPServiceInformationType serviceInformation;
	private ValidationDetails validationDetails;
	private List<ErrorExtension> errorExtensions;
	private List<ResponderDetails> responderDetails;
	
	/**
	 * Creates a new <code>PEPPOLValidateResultExt</code>.
	 * 
	 * @param  validateResultExtEUType
	 *         The JAXB object which represents the PEPPOL Validate Result
	 *         extension.
	 */
	public PEPPOLValidateResultExt(
		ValidateResultExtEUType validateResultExtEUType)
	{
		EIDQualityType eIDQualityType = validateResultExtEUType.getEIDQuality();
		if (eIDQualityType != null)
		{
			this.certQuality = CertificateQuality.fromValue(eIDQualityType.getCertificateQuality());
			this.cspAssurance = CSPAssurance.fromValue(eIDQualityType.getCSPAssurance());
		}
		
		this.serviceInformation = validateResultExtEUType.getServiceInformation();
		
		ValidationDetailsType validationDetailsType = validateResultExtEUType.getValidationDetails();
		if (validationDetailsType != null)
		{
			this.validationDetails = new ValidationDetails(validationDetailsType);
		}
		
		List<ErrorExtensionType> errorExtensionTypeList = validateResultExtEUType.getErrorExtension();
		this.errorExtensions = new ArrayList<ErrorExtension>(errorExtensionTypeList.size());
		for (ErrorExtensionType errorExtensionType : errorExtensionTypeList)
		{
			ErrorExtension errorExtension = new ErrorExtension(errorExtensionType);
			this.errorExtensions.add(errorExtension);
		}
		
		List<ResponderDetailsType> responderDetailsTypeList = validateResultExtEUType.getResponderDetails();
		this.responderDetails = new ArrayList<ResponderDetails>(responderDetailsTypeList.size());
		for (ResponderDetailsType responderDetailsType : responderDetailsTypeList)
		{
			ResponderDetails responderDetails = new ResponderDetails(responderDetailsType);
			this.responderDetails.add(responderDetails);
		}
		
	}

	/**
	 * Returns the certificate quality or <code>null</code> if the certificate
	 * quality is not supplied by the PEPPOL XKMS responder.
	 * 
	 * @return the certificate quality or <code>null</code> if the certificate
	 * quality is not supplied by the PEPPOL XKMS responder.
	 */
	public CertificateQuality getCertQuality()
	{
		return certQuality;
	}

	/**
	 * Returns the the certificate issuing CSP status or <code>null</code> if
	 * the CPS status is not supplied by the PEPPOL XKMS responder.
	 * 
	 * @return the the certificate issuing CSP status or <code>null</code> if
	 * the CPS status is not supplied by the PEPPOL XKMS responder.
	 */ 
	public CSPAssurance getCSPAssurance()
	{
		return cspAssurance;
	}

	/**
	 * Returns the service information according to ETSI TSL specification or
	 * <code>null</code> if the service information is not supplied by the
	 * PEPPOL XKMS responder.
	 * 
	 * @return  the service information according to ETSI TSL specification or
	 * <code>null</code> if the service information is not supplied by the
	 * PEPPOL XKMS responder.
	 */
	public TSPServiceInformationType getServiceInformation()
	{
		return serviceInformation;
	}

	/**
	 * Returns details on the certificate validation or <code>null</code> if
	 * this information is not supplied by the PEPPOL XKMS responder.
	 * 
	 * @return details on the certificate validation or <code>null</code> if
	 * this information is not supplied by the PEPPOL XKMS responder.
	 */
	public ValidationDetails getValidationDetails()
	{
		return validationDetails;
	}

	/**
	 * Returns the <code>List</code> of <code>ErrorExtension</code> which
	 * report errors concerning the validation process.
	 * 
	 * @return the <code>List</code> of <code>ErrorExtension</code> which
	 * report errors concerning the validation process (never 
	 * <code>null</code>).
	 */
	public List<ErrorExtension> getErrorExtensions()
	{
		return errorExtensions;
	}
	
	/**
	 * Returns a <code>List</code> of details for each XKMS responder used.
	 * <p>
	 * This <code>List</code> MUST contain at least one element.
	 * 
	 * @return a <code>List</code> of details for each XKMS responder used
	 * (never <code>null</code>).
	 */
	public List<ResponderDetails> getResponderDetails()
	{
		return responderDetails;
	}
}
