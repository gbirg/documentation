/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 14 oct. 2010
 * Time: 10:09:38
 */
package eu.peppol.lsp.xkms.extensions;

import java.util.Date;

import javax.xml.datatype.Duration;

import eu.peppol.lsp.xkms.jaxb.peppol.ResponderDetailsType;
import eu.peppol.lsp.xkms.jaxb.tsl.TSPInformationType;

/**
 * This class contains details of the XKMS responder used to validate the XKMS
 * request.
 */
public class ResponderDetails
{
	private TSPInformationType tspInformation;
	private String configurationVersion;
	private Long ocspCacheingInterval;
	private String tslIdentifier;
	private String policyIdentifier;
	private String algPolicyIdentifier;
	private String chainingTo;
	
	/**
	 * Creates a new <code>ResponderDetails</code>.
	 * 
	 * @param  responderDetailsType
	 *         The JAXB object which represents the ResponderDetails to build.
	 */
	public ResponderDetails(ResponderDetailsType responderDetailsType)
	{
		this.tspInformation = responderDetailsType.getTSPInformation();
		this.configurationVersion = responderDetailsType.getConfigurationVersion();
		
		Duration interval = responderDetailsType.getOCSPCacheingInterval();
		if (interval != null)
		{
			this.ocspCacheingInterval = interval.getTimeInMillis(new Date());
		}
		
		this.tslIdentifier = responderDetailsType.getTSLIdentifier();
		this.policyIdentifier = responderDetailsType.getPolicyIdentifier();
		this.algPolicyIdentifier = responderDetailsType.getAlgPolicyIdentifier();
		this.chainingTo = responderDetailsType.getChainingTo();
	}

	/**
	 * Returns the TSP information of the XKMS responder or 
	 * <code>null</code> if information is not supplied.
	 * 
	 * @return the TSP information of the XKMS responder or 
	 * <code>null</code> if information is not supplied.
	 */
	public TSPInformationType getTSPInformation()
	{
		return tspInformation;
	}

	/**
	 * Returns information about the responders configuration version or 
	 * <code>null</code> if information is not supplied.
	 * 
	 * @return information about the responders configuration version or 
	 * <code>null</code>.
	 */
	public String getConfigurationVersion()
	{
		return configurationVersion;
	}

	/**
	 * Returns the cacheing interval time used by the XKMS responder for
	 * the OCSP responses or <code>null</code> if not specified.
	 * 
	 * @return the cacheing interval time used by the XKMS responder for
	 * the OCSP responses or <code>null</code> if not specified.
	 */
	public Long getOCSPCacheingInterval()
	{
		return ocspCacheingInterval;
	}

	/**
	 * Returns the URI of the Trusted Services List instance used in this
	 * concrete validation process (may be exposed by the EU member states
	 * as machine readable XML file or in PDF format) or <code>null</code>
	 * if not specified.
	 * 
	 * @return the URI of the Trusted Services List instance used in this
	 * concrete validation process (may be exposed by the EU member states
	 * as machine readable XML file or in PDF format) or <code>null</code>.
	 */
	public String getTSLIdentifier()
	{
		return tslIdentifier;
	}

	/**
	 * Returns an URI pointing to the policy document of this XKMS responder
	 * instance or <code>null</code> if not specified.
	 * 
	 * @return an URI pointing to the policy document of this XKMS responder
	 * instance or <code>null</code> if not specified.
	 */
	public String getPolicyIdentifier()
	{
		return policyIdentifier;
	}

	/**
	 * Returns an URI pointing to a document which expose regulations on
	 * suitability of cryptographic algorithms with regard to underlying
	 * time scale online or <code>null</code> if not specified.
	 * 
	 * @return URI pointing to a document which expose regulations on
	 * suitability of cryptographic algorithms with regard to underlying
	 * time scale online or <code>null</code> if not specified.
	 */
	public String getAlgPolicyIdentifier()
	{
		return algPolicyIdentifier;
	}

	/**
	 * Returns the URL of the responder the request is forwarded to (in case of
	 * chaining) or <code>null</code> if not specified.
	 * 
	 * @return the URL of the responder the request is forwarded to (in case of
	 * chaining) or <code>null</code> if not specified.
	 */
	public String getChainingTo()
	{
		return chainingTo;
	}
}
