/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 13 oct. 2010
 * Time: 17:05:19
 */
package eu.peppol.lsp.xkms.extensions;


public enum RevocationReason
{
	/**
	 * This reason indicates that it is unspecified as to why the certificate
	 * has been revoked.
	 */
	UNSPECIFIED (PEPPOLConstants.REVOCATION_REASON_URI + "Unspecified"),
	
	/**
	 * This reason indicates that it is known or suspected that the user
	 * certificate subject's private key has been compromised.
	 */
	KEY_COMPROMISE (PEPPOLConstants.REVOCATION_REASON_URI + "KeyCompromise"),
	
	/**
	 * This reason indicates that it is known or suspected that the issuer
	 * certificate subject's private key has been compromised.
	 */
	CA_COMPROMISE (PEPPOLConstants.REVOCATION_REASON_URI + "CACompromise"),
	
	/**
	 * This reason indicates that the subject's name or other information has
	 * changed.
	 */
	AFFILIATION_CHANGED (PEPPOLConstants.REVOCATION_REASON_URI + "AffiliationChanged"),
	
	/**
	 * This reason indicates that the certificate has been superseded.
	 */
	SUPERSEDED (PEPPOLConstants.REVOCATION_REASON_URI + "Superseded"),
	
	/**
	 * This reason indicates that the certificate is no longer needed.
	 */
	CESSATION_OF_OPERATION (PEPPOLConstants.REVOCATION_REASON_URI + "CessationOfOperation"),
	
	/**
	 * This reason indicates that the certificate has been put on hold.
	 */
	CERTIFICATE_HOLD (PEPPOLConstants.REVOCATION_REASON_URI + "CertificateHold"),
	
	/**
	 * This reason indicates that the certificate was previously on hold and
	 * should be removed from the CRL.
	 */
	REMOVE_FROM_CRL (PEPPOLConstants.REVOCATION_REASON_URI + "RemoveFromCRL"),
	
	/**
	 * This reason indicates that the privileges granted to the subject of the
	 * certificate have been withdrawn.
	 */
	PRIVILEGE_WITHDRAWN (PEPPOLConstants.REVOCATION_REASON_URI + "PrivilegeWithdrawn"),
	
	/**
	 * This reason indicates that it is known or suspected that the certificate
	 * subject's private key has been compromised.
	 */
	AA_COMPROMISE (PEPPOLConstants.REVOCATION_REASON_URI + "AACompromise"),
	
	/**
	 * No revocation reason available.
	 */
	NONE (PEPPOLConstants.REVOCATION_REASON_URI + "None");
	
	
	private final String value;
	
	RevocationReason(String v) 
	{
        value = v;
    }

    public String value() 
    {
        return value;
    }

    public static RevocationReason fromValue(String v) 
    {
    	if (v == null)
    	{
    		return null;
    	}
    	
        for (RevocationReason c: RevocationReason.values()) 
        {
            if (c.value.equals(v)) 
            {
                return c;
            }
        }
        throw new IllegalArgumentException(v.toString());
    }
}
