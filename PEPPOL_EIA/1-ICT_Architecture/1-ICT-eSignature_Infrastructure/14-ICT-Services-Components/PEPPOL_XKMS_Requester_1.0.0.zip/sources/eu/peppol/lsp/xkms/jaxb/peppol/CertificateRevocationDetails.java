
package eu.peppol.lsp.xkms.jaxb.peppol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RevocationTimeInstant" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}RevocationReason"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "revocationTimeInstant",
    "revocationReason"
})
@XmlRootElement(name = "CertificateRevocationDetails")
public class CertificateRevocationDetails {

    @XmlElement(name = "RevocationTimeInstant", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar revocationTimeInstant;
    @XmlElement(name = "RevocationReason", required = true)
    protected String revocationReason;

    /**
     * Gets the value of the revocationTimeInstant property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRevocationTimeInstant() {
        return revocationTimeInstant;
    }

    /**
     * Sets the value of the revocationTimeInstant property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRevocationTimeInstant(XMLGregorianCalendar value) {
        this.revocationTimeInstant = value;
    }

    /**
     * Gets the value of the revocationReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevocationReason() {
        return revocationReason;
    }

    /**
     * Sets the value of the revocationReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevocationReason(String value) {
        this.revocationReason = value;
    }

}
