
package eu.peppol.lsp.xkms.jaxb.peppol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eIDQualityType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="eIDQualityType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}CertificateQuality"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}CSPAssurance"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "eIDQualityType", propOrder = {
    "certificateQuality",
    "cspAssurance"
})
public class EIDQualityType {

    @XmlElement(name = "CertificateQuality", required = true)
    protected String certificateQuality;
    @XmlElement(name = "CSPAssurance", required = true)
    protected String cspAssurance;

    /**
     * Gets the value of the certificateQuality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCertificateQuality() {
        return certificateQuality;
    }

    /**
     * Sets the value of the certificateQuality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCertificateQuality(String value) {
        this.certificateQuality = value;
    }

    /**
     * Gets the value of the cspAssurance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCSPAssurance() {
        return cspAssurance;
    }

    /**
     * Sets the value of the cspAssurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCSPAssurance(String value) {
        this.cspAssurance = value;
    }

}
