
package eu.peppol.lsp.xkms.jaxb.peppol;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import eu.peppol.lsp.xkms.jaxb.tsl.TSPServiceInformationType;
import eu.peppol.lsp.xkms.jaxb.xkms.MessageExtensionAbstractType;


/**
 * <p>Java class for ValidateResultExtEUType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidateResultExtEUType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.w3.org/2002/03/xkms#}MessageExtensionAbstractType">
 *       &lt;sequence>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}eIDQuality" minOccurs="0"/>
 *         &lt;element ref="{http://uri.etsi.org/02231/v2#}ServiceInformation" minOccurs="0"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}ValidationDetails" minOccurs="0"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}ErrorExtension" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}ResponderDetails" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidateResultExtEUType", propOrder = {
    "eidQuality",
    "serviceInformation",
    "validationDetails",
    "errorExtension",
    "responderDetails"
})
public class ValidateResultExtEUType
    extends MessageExtensionAbstractType
{

    @XmlElement(name = "eIDQuality")
    protected EIDQualityType eidQuality;
    @XmlElement(name = "ServiceInformation", namespace = "http://uri.etsi.org/02231/v2#")
    protected TSPServiceInformationType serviceInformation;
    @XmlElement(name = "ValidationDetails")
    protected ValidationDetailsType validationDetails;
    @XmlElement(name = "ErrorExtension")
    protected List<ErrorExtensionType> errorExtension;
    @XmlElement(name = "ResponderDetails", required = true)
    protected List<ResponderDetailsType> responderDetails;

    /**
     * Gets the value of the eidQuality property.
     * 
     * @return
     *     possible object is
     *     {@link EIDQualityType }
     *     
     */
    public EIDQualityType getEIDQuality() {
        return eidQuality;
    }

    /**
     * Sets the value of the eidQuality property.
     * 
     * @param value
     *     allowed object is
     *     {@link EIDQualityType }
     *     
     */
    public void setEIDQuality(EIDQualityType value) {
        this.eidQuality = value;
    }

    /**
     * Gets the value of the serviceInformation property.
     * 
     * @return
     *     possible object is
     *     {@link TSPServiceInformationType }
     *     
     */
    public TSPServiceInformationType getServiceInformation() {
        return serviceInformation;
    }

    /**
     * Sets the value of the serviceInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link TSPServiceInformationType }
     *     
     */
    public void setServiceInformation(TSPServiceInformationType value) {
        this.serviceInformation = value;
    }

    /**
     * Gets the value of the validationDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ValidationDetailsType }
     *     
     */
    public ValidationDetailsType getValidationDetails() {
        return validationDetails;
    }

    /**
     * Sets the value of the validationDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValidationDetailsType }
     *     
     */
    public void setValidationDetails(ValidationDetailsType value) {
        this.validationDetails = value;
    }

    /**
     * Gets the value of the errorExtension property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the errorExtension property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getErrorExtension().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ErrorExtensionType }
     * 
     * 
     */
    public List<ErrorExtensionType> getErrorExtension() {
        if (errorExtension == null) {
            errorExtension = new ArrayList<ErrorExtensionType>();
        }
        return this.errorExtension;
    }

    /**
     * Gets the value of the responderDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the responderDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResponderDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ResponderDetailsType }
     * 
     * 
     */
    public List<ResponderDetailsType> getResponderDetails() {
        if (responderDetails == null) {
            responderDetails = new ArrayList<ResponderDetailsType>();
        }
        return this.responderDetails;
    }

}
