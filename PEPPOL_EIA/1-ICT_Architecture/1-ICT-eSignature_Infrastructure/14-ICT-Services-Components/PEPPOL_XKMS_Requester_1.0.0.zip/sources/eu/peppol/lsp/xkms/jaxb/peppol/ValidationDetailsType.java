
package eu.peppol.lsp.xkms.jaxb.peppol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import eu.peppol.lsp.xkms.jaxb.isocc.ISOCountryCodeType;


/**
 * <p>Java class for ValidationDetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidationDetailsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}ValidateScheme"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}ValidateModel" minOccurs="0"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}ValidationTimeQueried"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}ValidationTime"/>
 *         &lt;element name="CertIssuingCountry" type="{http://www.tm-xml.org/XMLSchema/common}ISOCountryCodeType"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}OCSPNoCache" minOccurs="0"/>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}CertificateRevocationDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidationDetailsType", propOrder = {
    "validateScheme",
    "validateModel",
    "validationTimeQueried",
    "validationTime",
    "certIssuingCountry",
    "ocspNoCache",
    "certificateRevocationDetails"
})
public class ValidationDetailsType {

    @XmlElement(name = "ValidateScheme", required = true)
    protected String validateScheme;
    @XmlElement(name = "ValidateModel")
    protected String validateModel;
    @XmlElement(name = "ValidationTimeQueried", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar validationTimeQueried;
    @XmlElement(name = "ValidationTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar validationTime;
    @XmlElement(name = "CertIssuingCountry", required = true)
    protected ISOCountryCodeType certIssuingCountry;
    @XmlElement(name = "OCSPNoCache")
    protected Boolean ocspNoCache;
    @XmlElement(name = "CertificateRevocationDetails")
    protected CertificateRevocationDetails certificateRevocationDetails;

    /**
     * Gets the value of the validateScheme property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidateScheme() {
        return validateScheme;
    }

    /**
     * Sets the value of the validateScheme property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidateScheme(String value) {
        this.validateScheme = value;
    }

    /**
     * Gets the value of the validateModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidateModel() {
        return validateModel;
    }

    /**
     * Sets the value of the validateModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidateModel(String value) {
        this.validateModel = value;
    }

    /**
     * Gets the value of the validationTimeQueried property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getValidationTimeQueried() {
        return validationTimeQueried;
    }

    /**
     * Sets the value of the validationTimeQueried property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setValidationTimeQueried(XMLGregorianCalendar value) {
        this.validationTimeQueried = value;
    }

    /**
     * Gets the value of the validationTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getValidationTime() {
        return validationTime;
    }

    /**
     * Sets the value of the validationTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setValidationTime(XMLGregorianCalendar value) {
        this.validationTime = value;
    }

    /**
     * Gets the value of the certIssuingCountry property.
     * 
     * @return
     *     possible object is
     *     {@link ISOCountryCodeType }
     *     
     */
    public ISOCountryCodeType getCertIssuingCountry() {
        return certIssuingCountry;
    }

    /**
     * Sets the value of the certIssuingCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISOCountryCodeType }
     *     
     */
    public void setCertIssuingCountry(ISOCountryCodeType value) {
        this.certIssuingCountry = value;
    }

    /**
     * Gets the value of the ocspNoCache property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOCSPNoCache() {
        return ocspNoCache;
    }

    /**
     * Sets the value of the ocspNoCache property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOCSPNoCache(Boolean value) {
        this.ocspNoCache = value;
    }

    /**
     * Gets the value of the certificateRevocationDetails property.
     * 
     * @return
     *     possible object is
     *     {@link CertificateRevocationDetails }
     *     
     */
    public CertificateRevocationDetails getCertificateRevocationDetails() {
        return certificateRevocationDetails;
    }

    /**
     * Sets the value of the certificateRevocationDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link CertificateRevocationDetails }
     *     
     */
    public void setCertificateRevocationDetails(CertificateRevocationDetails value) {
        this.certificateRevocationDetails = value;
    }

}
