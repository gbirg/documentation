@javax.xml.bind.annotation.XmlSchema(namespace = "http://uri.peppol.eu/xkmsExt/v2#", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package eu.peppol.lsp.xkms.jaxb.peppol;
