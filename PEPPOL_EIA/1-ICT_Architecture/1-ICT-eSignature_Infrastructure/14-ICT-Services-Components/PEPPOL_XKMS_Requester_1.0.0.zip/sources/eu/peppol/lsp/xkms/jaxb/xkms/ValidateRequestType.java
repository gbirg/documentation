
package eu.peppol.lsp.xkms.jaxb.xkms;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ValidateRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidateRequestType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.w3.org/2002/03/xkms#}RequestAbstractType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.w3.org/2002/03/xkms#}QueryKeyBinding"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidateRequestType", propOrder = {
    "queryKeyBinding"
})
public class ValidateRequestType
    extends RequestAbstractType
{

    @XmlElement(name = "QueryKeyBinding", required = true)
    protected QueryKeyBindingType queryKeyBinding;

    /**
     * Gets the value of the queryKeyBinding property.
     * 
     * @return
     *     possible object is
     *     {@link QueryKeyBindingType }
     *     
     */
    public QueryKeyBindingType getQueryKeyBinding() {
        return queryKeyBinding;
    }

    /**
     * Sets the value of the queryKeyBinding property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryKeyBindingType }
     *     
     */
    public void setQueryKeyBinding(QueryKeyBindingType value) {
        this.queryKeyBinding = value;
    }

}
