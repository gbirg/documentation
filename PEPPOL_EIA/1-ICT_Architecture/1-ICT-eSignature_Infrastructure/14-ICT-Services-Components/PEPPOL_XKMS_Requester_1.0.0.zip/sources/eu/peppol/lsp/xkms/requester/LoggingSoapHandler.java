/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 12 oct. 2010
 * Time: 18:53:17
 */
package eu.peppol.lsp.xkms.requester;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.log4j.Logger;

class LoggingSoapHandler 
	implements SOAPHandler<SOAPMessageContext>
{
	private static final Logger log = Logger.getLogger(LoggingSoapHandler.class);
	
	private File logDirectory;
	
	public LoggingSoapHandler(
		File logDirectory)
	{
		this.logDirectory = logDirectory;
	}

	public Set<QName> getHeaders()
	{
		return null;
	}

	public void close(
		MessageContext context)
	{
		log.debug("Close");
	}

	public boolean handleFault(
		SOAPMessageContext context)
	{
		return true;
	}

	public boolean handleMessage(
		SOAPMessageContext context)
	{
		log.debug("Handle message");
		Boolean outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
		String messageBoundType = (outboundProperty ? "request" : "response");
		log.debug("Bound message: " + messageBoundType);
		
		SOAPMessage soapMessage = context.getMessage();
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		try 
		{
			soapMessage.writeTo(output);
			log.debug("SOAP message: " + output.toString());
			
			if (logDirectory != null && logDirectory.isDirectory())
			{
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddhhmmssS");
				String filename = messageBoundType + "-" + dateFormat.format(new Date()) + ".xml";
				File logFile = new File(logDirectory, filename);
				FileOutputStream fos = new FileOutputStream(logFile);
				fos.write(output.toByteArray());
				fos.close();
			}
		} 
		catch (Exception exception) 
		{
			log.error("SOAP error: " + exception.getMessage());
		}

		return true;
	}
}
