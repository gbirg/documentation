/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 20 janv. 2011
 * Time: 08:29:25
 */
package eu.peppol.lsp.xkms.requester.cmd;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Properties;

public class ConfigFileHandler
{
	private static final String XKMS_RESPONDER_WS_ENDPOINT_ADDRESS = "xkms.responder.ws.endpoint.address";
	private static final String XKMS_REQUEST_SIGNATURE_KEYSTORE_FILE = "xkms.request.signature.keystore.file";
	private static final String XKMS_REQUEST_SIGNATURE_KEYSTORE_PASSWORD = "xkms.request.signature.keystore.password";
	private static final String XKMS_REQUEST_SIGNATURE_KEYSTORE_TYPE = "xkms.request.signature.keystore.type";
	private static final String XKMS_REQUEST_SIGNATURE_KEYSTORE_ALIAS = "xkms.request.signature.keystore.alias";
	private static final String XKMS_REQUEST_SIGNATURE_DIGEST_ALGORITHM = "xkms.request.signature.digest.algorithm";
	private static final String XKMS_RESPONSE_SIGNATURE_CERT_FILE = "xkms.response.signature.cert.file";
	private static final String XKMS_RESPONDER_SSL_SERVER_CERT_FILE = "xkms.responder.ssl.server.cert.file";
	
	private File configFile;
	
	private String xkmsResponderWsEndpointAddress;
	private PrivateKey xkmsRequestSignerPrivateKey;
	private X509Certificate xkmsRequestSignerCertificate;
	private String xkmsRequestSignerDigestAlgorithm;
	private X509Certificate xkmsResponseSignerCertificate;
	private X509Certificate xkmsResponderSSLCertificate;
	
	
	public ConfigFileHandler(
		File configFile) 
		throws IOException, KeyStoreException, NoSuchAlgorithmException, 
			CertificateException, UnrecoverableKeyException
	{
		this.configFile = configFile;
		
		FileInputStream fis = new FileInputStream(configFile);
        Properties properties = new Properties();
        properties.load(fis);
        fis.close();
        
        xkmsResponderWsEndpointAddress = properties.getProperty(XKMS_RESPONDER_WS_ENDPOINT_ADDRESS);
        if (xkmsResponderWsEndpointAddress == null || xkmsResponderWsEndpointAddress.length() == 0)
        {
        	throw new IOException(XKMS_RESPONDER_WS_ENDPOINT_ADDRESS + " parameter must be specified in the config file");
        }
        
        /////////////////////////////////////////////////////////////
        // Private key and certificate used to sign XKMS requests
        String keystoreFile = properties.getProperty(XKMS_REQUEST_SIGNATURE_KEYSTORE_FILE);
        if (keystoreFile != null && keystoreFile.length() > 0)
        {
        	char[] password = null;
        	String param = properties.getProperty(XKMS_REQUEST_SIGNATURE_KEYSTORE_PASSWORD);
        	if (param != null)
        	{
        		password = param.toCharArray();
        	}
        	
        	String keyStoreType = "PKCS12";
        	param = properties.getProperty(XKMS_REQUEST_SIGNATURE_KEYSTORE_TYPE);
        	if (param != null && param.length() > 0)
        	{
        		keyStoreType = param;
        	}
        	
        	String alias = properties.getProperty(XKMS_REQUEST_SIGNATURE_KEYSTORE_ALIAS);
        	
			KeyStore keyStore = KeyStore.getInstance(keyStoreType);
			fis = new FileInputStream(keystoreFile);
			keyStore.load(fis, password);
			fis.close();
			
			if (alias == null || alias.length() == 0)
			{
				alias = keyStore.aliases().nextElement();
			}
			
			xkmsRequestSignerPrivateKey = (PrivateKey) keyStore.getKey(alias, password);
			xkmsRequestSignerCertificate = (X509Certificate) keyStore.getCertificate(alias);
			
			xkmsRequestSignerDigestAlgorithm = properties.getProperty(
							XKMS_REQUEST_SIGNATURE_DIGEST_ALGORITHM, 
							"http://www.w3.org/2000/09/xmldsig#sha1");
        }
        
        /////////////////////////////////////////////////////////////
        // Certificate used to validate signatures of XKMS responses
        String xkmsResponseSignatureCertFile = properties.getProperty(XKMS_RESPONSE_SIGNATURE_CERT_FILE);
        if (xkmsResponseSignatureCertFile != null && xkmsResponseSignatureCertFile.length() > 0)
        {
	        fis = new FileInputStream(xkmsResponseSignatureCertFile);
	        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
	        xkmsResponseSignerCertificate = (X509Certificate) certFactory.generateCertificate(fis);
			fis.close();
        }
        
        /////////////////////////////////////////////////////////////
        // SSL server certificate of the XKMS responder
        String sslServerCertFile = properties.getProperty(XKMS_RESPONDER_SSL_SERVER_CERT_FILE);
        if (sslServerCertFile != null && sslServerCertFile.length() > 0)
        {
	        fis = new FileInputStream(sslServerCertFile);
	        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
	        xkmsResponderSSLCertificate = (X509Certificate) certFactory.generateCertificate(fis);
			fis.close();
        }
	}

	public File getConfigFile()
	{
		return configFile;
	}

	public String getXKMSResponderWsEndpointAddress()
	{
		return xkmsResponderWsEndpointAddress;
	}

	public PrivateKey getXKMSRequestSignerPrivateKey()
	{
		return xkmsRequestSignerPrivateKey;
	}

	public X509Certificate getXKMSRequestSignerCertificate()
	{
		return xkmsRequestSignerCertificate;
	}

	public String getXKMSRequestSignerDigestAlgorithm()
	{
		return xkmsRequestSignerDigestAlgorithm;
	}

	public X509Certificate getXKMSResponseSignerCertificate()
	{
		return xkmsResponseSignerCertificate;
	}

	public X509Certificate getXKMSResponderSSLCertificate()
	{
		return xkmsResponderSSLCertificate;
	}
}
