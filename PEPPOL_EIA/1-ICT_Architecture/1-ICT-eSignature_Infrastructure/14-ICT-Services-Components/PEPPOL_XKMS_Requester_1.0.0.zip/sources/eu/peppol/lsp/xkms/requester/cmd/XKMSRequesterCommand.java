/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 19 janv. 2011
 * Time: 15:11:42
 */
package eu.peppol.lsp.xkms.requester.cmd;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.security.Security;
import java.security.cert.CRLException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import eu.peppol.lsp.xkms.ValidateRequest;
import eu.peppol.lsp.xkms.ValidateResult;
import eu.peppol.lsp.xkms.extensions.CSPAssurance;
import eu.peppol.lsp.xkms.extensions.CertificateQuality;
import eu.peppol.lsp.xkms.extensions.ErrorExtension;
import eu.peppol.lsp.xkms.extensions.PEPPOLConstants;
import eu.peppol.lsp.xkms.extensions.PEPPOLValidateResultExt;
import eu.peppol.lsp.xkms.extensions.ResponderDetails;
import eu.peppol.lsp.xkms.extensions.ValidationDetails;
import eu.peppol.lsp.xkms.jaxb.tsl.AddressType;
import eu.peppol.lsp.xkms.jaxb.tsl.DigitalIdentityListType;
import eu.peppol.lsp.xkms.jaxb.tsl.ElectronicAddressType;
import eu.peppol.lsp.xkms.jaxb.tsl.ExtensionType;
import eu.peppol.lsp.xkms.jaxb.tsl.ExtensionsListType;
import eu.peppol.lsp.xkms.jaxb.tsl.InternationalNamesType;
import eu.peppol.lsp.xkms.jaxb.tsl.MultiLangNormStringType;
import eu.peppol.lsp.xkms.jaxb.tsl.NonEmptyMultiLangURIListType;
import eu.peppol.lsp.xkms.jaxb.tsl.NonEmptyMultiLangURIType;
import eu.peppol.lsp.xkms.jaxb.tsl.PostalAddressListType;
import eu.peppol.lsp.xkms.jaxb.tsl.PostalAddressType;
import eu.peppol.lsp.xkms.jaxb.tsl.ServiceSupplyPointsType;
import eu.peppol.lsp.xkms.jaxb.tsl.TSPInformationType;
import eu.peppol.lsp.xkms.jaxb.tsl.TSPServiceInformationType;
import eu.peppol.lsp.xkms.jaxb.xkms.KeyBindingType;
import eu.peppol.lsp.xkms.jaxb.xkms.StatusType;
import eu.peppol.lsp.xkms.jaxb.xmldsig.KeyInfoType;
import eu.peppol.lsp.xkms.jaxb.xmldsig.X509DataType;
import eu.peppol.lsp.xkms.requester.XKMSRequester;
import eu.peppol.lsp.xkms.requester.XKMSRequesterException;

public class XKMSRequesterCommand
{
	private static final String XKMS_SERVICE = "http://uri.peppol.eu/XKMS";
	
	private static Options createCommandOptions()
	{
		Options options = new Options();
		
		Option help = new Option("help", "print this message");
		options.addOption(help);
		
		Option version = new Option("version", "print the version information and exit");
		options.addOption(version);
		
		Option cert = new Option("cert", "file containing the certificate to be validated");
		cert.setArgs(1);
		cert.setArgName("cert_file");
		options.addOption(cert);
		
		Option validtime = new Option("validtime", "validation time to be used (format must be yyyy-mm-dd'T'hh:mm:ss)");
		validtime.setArgs(1);
		validtime.setArgName("time");
		options.addOption(validtime);
		
		Option config = new Option("config", "file containing the configuration parameters");
		cert.setArgs(1);
		cert.setArgName("config_file");
		options.addOption(config);
		
		Option log = new Option("log", "log directory containing XKMS requests and results");
		log.setArgs(1);
		log.setArgName("log_directory");
		options.addOption(log);
		
		return options;
	}

	public static void main(String[] args)
	{
		BouncyCastleProvider provider = new BouncyCastleProvider();
		Security.addProvider(provider);
		
	    try 
	    {
	    	/////////////////////////////////////////////////////////
	    	//
	    	// Parse command line parameters
	    	//
	    	
	    	if (args.length == 0)
	    	{
	    		System.err.println("Invalid usage.");
	    		System.err.println("Try PeppolXKMSRequester -help");
	    		return;
	    	}
	    	
	    	Options options = createCommandOptions();
		    CommandLineParser parser = new GnuParser();
	        CommandLine line = parser.parse(options, args);
	        
	        if (line.hasOption("help")) 
	        {
	        	HelpFormatter formatter = new HelpFormatter();
	        	formatter.printHelp("PeppolXKMSRequester", options, true);
	        	return;
	        }
	        
	        if (line.hasOption("version")) 
	        {
	        	System.err.println("PEPPOL XKMS Requester version " 
	        					+ XKMSRequesterCommand.class.getPackage().getImplementationVersion());
	        	return;
	        }

	        // Certificate to be validated
	        if (!line.hasOption("cert")) 
	        {
	            System.err.println("Missing required parameter: cert");
	            return;
	        }
	        File certFile = new File(line.getOptionValue("cert"));
	        if (!certFile.exists())
	        {
	        	System.err.println("Certificate file \"" + certFile.getAbsolutePath() + "\" not found");
	            return;
	        }
	        
	        FileInputStream fis = new FileInputStream(certFile);
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509", "BC");
            List<X509Certificate> certificates = (List<X509Certificate>) certFactory.generateCertPath(fis, "PEM").getCertificates();
            fis.close();
            
            // Config file
            File configFile = null;
            if (!line.hasOption("config")) 
	        {
            	configFile = new File("config.properties");
            	if (!configFile.exists())
    	        {
    	        	System.err.println("Default config file \"" + configFile.getAbsolutePath() + "\" not found." +
    	        			"\nYou may use -config to specify the configuration file to be used.");
    	            return;
    	        }
	        }
            else
            {
            	configFile = new File(line.getOptionValue("config"));
            	if (!configFile.exists())
    	        {
    	        	System.err.println("Specified config file \"" + configFile.getAbsolutePath() + "\" not found");
    	            return;
    	        }
            }
            
            ConfigFileHandler configHandler = new ConfigFileHandler(configFile);
            
            // Log directory
            File logDirectory = null;
            if (line.hasOption("log")) 
	        {
            	logDirectory = new File(line.getOptionValue("log"));
            	if (logDirectory.mkdirs())
            	{
            		System.out.println("Creates the log directory: " + logDirectory.getAbsolutePath());
            	}
	        }

            Date validationTime = null;
            if (line.hasOption("validtime")) 
	        {
            	String param = line.getOptionValue("validtime");
            	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            	try
            	{
            		validationTime = dateFormat.parse(param);
            	}
            	catch (ParseException exception)
            	{
            		System.err.println("Invalid date format for the -validtime.\nFormat must be yyyy-mm-ddThh:mm:ss (for example: 2011-01-01T12:00:00)");
            		return;
            	}
	        }
            
            // Do XKMS validation
            validate(certificates, configHandler, validationTime, logDirectory);            
	    }
	    catch (Exception exception) 
	    {
	        exception.printStackTrace(System.err);
	    }
	    finally
	    {
	    	Security.removeProvider(provider.getName());
	    }
	}
	
	private static void validate(
		List<X509Certificate> certificates, 
		ConfigFileHandler config,
		Date validationTime,
		File logDirectory) 
		throws XKMSRequesterException, CertificateException, CRLException
	{
		XKMSRequester xkmsClient = new XKMSRequester(config.getXKMSResponderWsEndpointAddress());
		
		if (logDirectory != null)
		{
			xkmsClient.setLogging(true, logDirectory);
		}
		
		if (config.getXKMSRequestSignerPrivateKey() != null)
		{
			xkmsClient.setRequestSignatureParams(
							config.getXKMSRequestSignerPrivateKey(), 
							config.getXKMSRequestSignerCertificate(), 
							config.getXKMSRequestSignerDigestAlgorithm(), 
							null);
		}
		
		if (config.getXKMSResponseSignerCertificate() != null)
		{
			xkmsClient.setResponderCertificate(config.getXKMSResponseSignerCertificate());
		}
		
		if (config.getXKMSResponderSSLCertificate() != null)
		{
			xkmsClient.setSSLServerPublicKey(config.getXKMSResponderSSLCertificate().getPublicKey());
		}
		
		/////////////////////////////////////////////////////////////
		//
		// Creates the XKMS Validate request
		//
		/////////////////////////////////////////////////////////////
		
		ValidateRequest request = new ValidateRequest(XKMS_SERVICE, certificates);
		request.addRespondWith(PEPPOLConstants.RESPONDWITH_PEPPOL_EXTENDED);
		request.addRespondWith(PEPPOLConstants.RESPONDWITH_EID_QUALITY);
		request.addRespondWith(PEPPOLConstants.RESPONDWITH_VALIDATION_DETAILS);
		request.addRespondWith(PEPPOLConstants.RESPONDWITH_TSL_SERVICE_INFORMATION);
		request.addRespondWith(PEPPOLConstants.RESPONDWITH_OCSP);
		
		if (validationTime != null)
		{
			request.setValidationTime(validationTime);
		}
		
		/////////////////////////////////////////////////////////////
		//
		// Send the Validate request to the XKMS responder
		//
		/////////////////////////////////////////////////////////////
		
		ValidateResult result = xkmsClient.validate(request);
		
		System.out.println("--------------------");
		System.out.println("XKMS Validate Result");
		System.out.println("--------------------");
		System.out.println("Id: " + result.getId());
		System.out.println("Service: " + result.getService());
		System.out.println("ResultMajor: " + result.getResultMajor().value());
		System.out.println("ResultMinor: " + ((result.getResultMinor() != null) ? result.getResultMinor().value() : "<not specified>"));
		System.out.println("RequestId: " + result.getRequestId());
		
		/////////////////////////////////////////////////////////////
		//
		// Process the validate result
		//
		/////////////////////////////////////////////////////////////
		
		// Get CRLs and OCSP responses
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		Collection<X509CRL> crls = new ArrayList<X509CRL>();
		Collection<byte[]> ocspResponses = new ArrayList<byte[]>();
		for (KeyBindingType keyBinding : result.getKeyBindings())
		{
			System.out.println("KeyBinding");
			displayStatus(keyBinding.getStatus(), System.out, "  ");

			KeyInfoType keyInfo = keyBinding.getKeyInfo();
			if (keyInfo != null)
			{
				for (Object keyInfoContent : keyInfo.getContent())
				{
					if (keyInfoContent instanceof JAXBElement<?>)
					{
						Object value = ((JAXBElement<?>) keyInfoContent).getValue();
						if (value instanceof X509DataType)
						{
							X509DataType x509Data = (X509DataType) value;
							for (Object x509DataContent : x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName())
							{
								if (x509DataContent instanceof JAXBElement<?>)
								{
									JAXBElement<?> jaxbElement = (JAXBElement<?>) x509DataContent;					
									if (jaxbElement.getName().getLocalPart().equals("X509CRL"))
									{
										byte[] encodedCRL = (byte[]) jaxbElement.getValue();
										X509CRL crl = (X509CRL) certFactory.generateCRL(
														new ByteArrayInputStream(encodedCRL));
										System.out.println("  CRL found in the validate result");
									}
								}
								else if (x509DataContent instanceof Element)
								{
									// OCSP response MUST be carried in ds:X509Data extension ##other foreseen by [XMLDSIG].
									// Format and namespace of this extension MUST follow the ETSI XAdES specification [XAdES]
									// for xades:OCSPValuesType; the element name has to be xades:RevocationValues containing
									// xades:OCSPValues as only constituent of the sequence defined for xades:RevocationValues.
									Element element = (Element) x509DataContent;
									if ("http://uri.etsi.org/01903/v1.3.2#".equals(element.getNamespaceURI()) 
										&& "RevocationValues".equals(element.getLocalName()))
									{
										ocspResponses.addAll(XKMSRequesterCommand.getOCSPResponsesFromRevocationValues(element));
										System.out.println("  OCSP response found in the validate result");
									}
								}
							}
						}
					}
				}
			}
		}
		
		// PEPPOL validate result extension
		PEPPOLValidateResultExt peppolResult = result.getPeppolValidateResultExt();
		if (peppolResult != null)
		{
			System.out.println("--------------------");
			System.out.println("PEPPOL Validate Result Extension");
			System.out.println("--------------------");
			
			CertificateQuality certQuality = peppolResult.getCertQuality();
			if (certQuality != null)
			{
				System.out.println("  CertQuality: " + certQuality.value());
			}
			
			CSPAssurance cspAssurance = peppolResult.getCSPAssurance();
			if (cspAssurance != null)
			{
				System.out.println("  CSPAssurance: " + cspAssurance.value());
			}
			
			TSPServiceInformationType serviceInformation = peppolResult.getServiceInformation();
			if (serviceInformation != null)
			{
				System.out.println("  ServiceInformation:");
				displayTSPServiceInformationType(serviceInformation, System.out, "    ");
			}

			ValidationDetails validationDetails = peppolResult.getValidationDetails();
			if (validationDetails != null)
			{
				System.out.println("  ValidationDetails:");
				displayValidationDetails(validationDetails, System.out, "    ");
			}
			
			List<ErrorExtension> errorExtensions = peppolResult.getErrorExtensions();
			displayErrorExtensionList(errorExtensions, System.out, "  ");
			
			List<ResponderDetails> responderDetailsList = peppolResult.getResponderDetails();
			displayResponderDetailsList(responderDetailsList, System.out, "  ");
		}
	}
	
	public static void displayStatus(
		StatusType status,
		PrintStream out, 
		String indent)
	{
		out.print(indent);
		out.println("Status: " + status.getStatusValue());
		
		for (String validReason : status.getValidReason())
		{
			out.print(indent);
			out.println("  ValidReason: " + validReason);
		}
		
		for (String indeterminateReason : status.getIndeterminateReason())
		{
			out.print(indent);
			out.println("  IndeterminateReason: " + indeterminateReason);
		}
		
		for (String invalidReason : status.getInvalidReason())
		{
			out.print(indent);
			out.println("  InvalidReason: " + invalidReason);
		}
	}
	
	public static void displayTSPServiceInformationType(
		TSPServiceInformationType tspServiceInformationType, 
		PrintStream out, 
		String indent)
	{
		out.print(indent);
		out.print("ServiceName: ");
		displayMultiLangNormStringListType(tspServiceInformationType.getServiceName().getName(), System.out);
		
		DigitalIdentityListType serviceDigitalIdentity = tspServiceInformationType.getServiceDigitalIdentity();
		if (serviceDigitalIdentity != null)
		{
			out.print(indent);
			out.println("ServiceDigitalIdentity: " + serviceDigitalIdentity.getDigitalId().toString());
			// TODO displayDigitalIdentityListType(serviceDigitalIdentity.getDigitalId(), System.out, indent + "  ");
		}
		
		out.print(indent);
		out.println("ServiceStatus: " + tspServiceInformationType.getServiceStatus());
		
		out.print(indent);
		out.println("StatusStartingTime: " + tspServiceInformationType.getStatusStartingTime());
		
		NonEmptyMultiLangURIListType schemeServiceDefinitionURI = tspServiceInformationType.getSchemeServiceDefinitionURI();
		if (schemeServiceDefinitionURI != null)
		{
			out.print(indent);
			out.print("SchemeServiceDefinitionURI: "); 
			displayNonEmptyMultiLangURIListType(schemeServiceDefinitionURI.getURI(), System.out);
		}
		
		ServiceSupplyPointsType serviceSupplyPoints = tspServiceInformationType.getServiceSupplyPoints();
		if (serviceSupplyPoints != null)
		{
			out.print(indent);
			out.println("ServiceSupplyPointsType: " + serviceSupplyPoints.getServiceSupplyPoint().toString());
		}
		
		NonEmptyMultiLangURIListType tspServiceDefinitionURI = tspServiceInformationType.getTSPServiceDefinitionURI();
		if (tspServiceDefinitionURI != null)
		{
			out.print(indent);
			out.print("TSPServiceDefinitionURI: "); 
			displayNonEmptyMultiLangURIListType(tspServiceDefinitionURI.getURI(), System.out);
		}
		
		ExtensionsListType serviceInformationExtensions = tspServiceInformationType.getServiceInformationExtensions();
		if (serviceInformationExtensions != null)
		{
			out.print(indent);
			out.println("ServiceInformationExtensions:"); 
			displayExtensionsListType(serviceInformationExtensions.getExtension(), out, indent + "  ");
		}
	}
	
	public static void displayValidationDetails(
		ValidationDetails validationDetails, 
		PrintStream out, 
		String indent)
	{
		out.print(indent);
		out.println("ValidateScheme: " + validationDetails.getValidateScheme().value());
		
		out.print(indent);
		out.println("ValidateModel: " + (validationDetails.getValidateModel() != null ? validationDetails.getValidateModel().value() : ""));
		
		out.print(indent);
		out.println("ValidationTimeQueried: " + validationDetails.getValidationTimeQueried());
		
		out.print(indent);
		out.println("ValidationTime: " + validationDetails.getValidationTime());
		
		out.print(indent);
		out.println("CertIssuingCountry: " + validationDetails.getCertIssuingCountry().value());
		
		out.print(indent);
		out.println("OCSPNoCache: " + validationDetails.getOCSPNoCache());
		
		if (validationDetails.getRevocationReason() != null)
		{
			out.print(indent);
			out.println("CertificateRevocationDetails:");
						
			out.print(indent);
			out.println("  RevocationReason: " + validationDetails.getRevocationReason());
			
			out.print(indent);
			out.println("  RevocationTimeInstant: " + validationDetails.getRevocationTimeInstant());
		}
	}
	
	public static void displayErrorExtensionList(
		List<ErrorExtension> errorExtensionList, 
		PrintStream out, 
		String indent)
	{
		for (ErrorExtension errorExtension : errorExtensionList)
		{
			out.print(indent);
			out.println("ErrorExtension:");
			
			out.print(indent);
			out.println("  Reason: " + errorExtension.getReason().value());
			
			out.print(indent);
			out.println("  Detail: " + errorExtension.getDetail());
		}
	}
	
	public static void displayResponderDetailsList(
		List<ResponderDetails> responderDetailsList, 
		PrintStream out, 
		String indent)
	{
		for (ResponderDetails responderDetails : responderDetailsList)
		{
			out.print(indent);
			out.println("ResponderDetails:");
			
			if (responderDetails.getTSPInformation() != null)
			{
				out.print(indent);
				out.println("  TSPInformation:");
				displayTSPInformation(responderDetails.getTSPInformation(), out, indent + "    ");
			}
			
			if (responderDetails.getConfigurationVersion() != null)
			{
				out.print(indent);
				out.println("  ConfigurationVersion: " + responderDetails.getConfigurationVersion());
			}
			
			if (responderDetails.getOCSPCacheingInterval() != null)
			{
				out.print(indent);
				out.println("  OCSPCacheingInterval: " + responderDetails.getOCSPCacheingInterval());
			}
			
			if (responderDetails.getTSLIdentifier() != null)
			{
				out.print(indent);
				out.println("  TSLIdentifier: " + responderDetails.getTSLIdentifier());
			}
			
			if (responderDetails.getPolicyIdentifier() != null)
			{
				out.print(indent);
				out.println("  PolicyIdentifier: " + responderDetails.getPolicyIdentifier());
			}
			
			if (responderDetails.getAlgPolicyIdentifier() != null)
			{
				out.print(indent);
				out.println("  AlgPolicyIdentifier: " + responderDetails.getAlgPolicyIdentifier());
			}
			
			if (responderDetails.getChainingTo() != null)
			{
				out.print(indent);
				out.println("  ChainingTo: " + responderDetails.getChainingTo());
			}
		}
	}
	
	public static void displayTSPInformation(
		TSPInformationType tspInformation, 
		PrintStream out, 
		String indent)
	{
		out.print(indent);
		out.print("TSPName: ");
		displayMultiLangNormStringListType(tspInformation.getTSPName().getName(), out);
		
		InternationalNamesType tspTradeName = tspInformation.getTSPTradeName();
		if (tspTradeName != null)
		{
			out.print(indent);
			out.print("TSPTradeName: ");
			displayMultiLangNormStringListType(tspTradeName.getName(), out);
		}
		
		out.print(indent);
		out.println("TSPAddress: ");
		displayAddressType(tspInformation.getTSPAddress(), out, indent + "  ");
		
		out.print(indent);
		out.print("TSPInformationURI: ");
		displayNonEmptyMultiLangURIListType(tspInformation.getTSPInformationURI().getURI(), out);
		
		ExtensionsListType tspInformationExtensions = tspInformation.getTSPInformationExtensions();
		if (tspInformationExtensions != null)
		{
			out.print(indent);
			out.print("TSPInformationExtensions: ");
			displayExtensionsListType(tspInformationExtensions.getExtension(), out, indent + "  ");
		}
	}
		
	public static void displayMultiLangNormStringListType(
		List<MultiLangNormStringType> list,
		PrintStream out)
	{
		for (Iterator<MultiLangNormStringType> it = list.iterator(); it.hasNext(); )
		{
			MultiLangNormStringType value = it.next();
			out.print(" [value=" );
			out.print(value.getValue());
			out.print(", lang=" + value.getLang() + "]");
			if (it.hasNext())
			{
				out.print(", ");
			}
		}
	}
	
	public static void displayNonEmptyMultiLangURIListType(
		List<NonEmptyMultiLangURIType> list,
		PrintStream out)
	{
		for (Iterator<NonEmptyMultiLangURIType> it = list.iterator(); it.hasNext(); )
		{
			NonEmptyMultiLangURIType value = it.next();
			out.print(" [value=" );
			out.print(value.getValue());
			out.print(", lang=" + value.getLang() + "]");
			if (it.hasNext())
			{
				out.print(", ");
			}
		}
	}
	
	public static void displayExtensionsListType(
		List<ExtensionType> list, 
		PrintStream out, 
		String indent)
	{
		int index = 1;
		for (ExtensionType extension : list)
		{
			out.println();
			out.print(indent);
			out.print("Extension " +  index + ": ");
			out.print("isCritical=" + extension.isCritical());
			index++;
		}
	}
	
	public static void displayAddressType(
		AddressType addressType, 
		PrintStream out, 
		String indent)
	{
		PostalAddressListType postalAddresses = addressType.getPostalAddresses();
		out.print(indent);
		out.println("PostalAddresses:");
		for (PostalAddressType postalAddress : postalAddresses.getPostalAddress())
		{
			out.print(indent + "  ");
			out.println("PostalAddress:");
			out.print(indent + "    ");
			out.println("StreetAddress: " + postalAddress.getStreetAddress());
			out.print(indent + "    ");
			out.println("Locality: " + postalAddress.getLocality());
			out.print(indent + "    ");
			out.println("StateOrProvince: " + postalAddress.getStateOrProvince());
			out.print(indent + "    ");
			out.println("PostalCode: " + postalAddress.getPostalCode());
			out.print(indent + "    ");
			out.println("CountryName: " + postalAddress.getCountryName());
		}
		
		ElectronicAddressType electronicAddress = addressType.getElectronicAddress();
		out.println();
		out.print(indent);
		out.print("ElectronicAddress: " +  electronicAddress.getURI());
	}
	
	public static Collection<byte[]> getOCSPResponsesFromRevocationValues(
		Element revocationValuesElement)
	{
		Collection<byte[]> ocspResponses = new ArrayList<byte[]>();
		
		NodeList nodeList = revocationValuesElement.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node node = nodeList.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE 
				&& "OCSPValues".equals(node.getLocalName()))
			{
				nodeList = node.getChildNodes();
				for (int j = 0; j < nodeList.getLength(); j++)
				{
					node = nodeList.item(j);
					if (node.getNodeType() == Node.ELEMENT_NODE 
						&& "EncapsulatedOCSPValue".equals(node.getLocalName()))
					{
						ocspResponses.add(Base64.decodeBase64(node.getTextContent().getBytes()));
					}
				}
				break;
			}
		}
		
		return ocspResponses;
	}

}
