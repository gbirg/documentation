/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatepathvalidator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.GeneralSubtree;
import org.bouncycastle.asn1.x509.NameConstraints;
import org.bouncycastle.asn1.x509.PolicyInformation;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.jce.provider.X509CertificateObject;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;

/**
 *	Validator class for certificate extensions
 * @author leander
 * @author buengener
 * 
 */

public class ValidateCertExtensions
{
  static private final Logger LOG = Logger.getLogger(ValidateCertExtensions.class.getName());

  static Hashtable<String, String> certExts;

  static
  {
	  certExts = new Hashtable<String, String>();
	  certExts.put("KEY_USAGE", "2.5.29.15");
	  certExts.put("CERTIFICATE_POLICIES", "2.5.29.32");
	  certExts.put("SUBJECT_ALT_NAMES", "2.5.29.17");
	  certExts.put("BASIC_CONSTRAINTS", "2.5.29.19");
	  certExts.put("NAME_CONSTRAINTS", "2.5.29.30");
	  certExts.put("POLICY_CONSTRAINTS", "2.5.29.36");
	  certExts.put("EXTENDED_KEY_USAGE", "2.5.29.37");
	  certExts.put("INHIBIT_ANY_POLICY",  "2.5.29.54");
	  certExts.put("ANY_POLICY_OID", "2.5.29.32.0");
  }

  private GeneralSubtree[] permittedSubtrees = null;

  private GeneralSubtree[] excludedSubtrees = null;

  private HashSet<String> acceptablePolicySet = null;

  private boolean containsUnknownCriticalExtensionFlag = false;

  private int explicitPolicy;

  private int policyMapping;

  private int inhibitAnyPolicy;

  /**
   * Just the empty constructor
   */
  public ValidateCertExtensions()
  {
    acceptablePolicySet = new HashSet<String>();
    acceptablePolicySet.add(certExts.get("ANY_POLICY_OID"));
  }

  /**
   * This method verifies if the extensions of the given CertPath are valid. The acceptable policiesy can be obtaind by getAcceptablePolicies.   *
   * @param tbvCertPath X509CertificateObject[] The cert path. The first certificate is the trusted root. The last the user cert.
   * @throws MalformatedExtensionException Whenever an extension could not be parsed.
   * @return boolean true if the extensions in the path are valid. False otherwise.
   */
  public boolean validateCertPath(X509CertificateObject[] tbvCertPath)
        throws IOException
  {
    int n = tbvCertPath.length;
    explicitPolicy = n + 1;
    policyMapping = n + 1;
    inhibitAnyPolicy = n + 1;

    for (int i = 1; i < (tbvCertPath.length + 1); i++)
    {
      X509CertificateObject tbvCert = tbvCertPath[i - 1];
      if (LOG.isLoggable(Level.FINE))
        LOG.fine("Subject in tbvCert at Pos.: " + i + " " + tbvCert.getSubjectDN().getName());

      if (i < n)
      {
        if (!checkBasicConstraits(tbvCert))
        {
          LOG.fine("basic constraints not found");

          return false;
        }
      }

      Hashtable<Integer, List<Object>> subjectAltNames = getGeneralNames(tbvCert);
      if (!checkPermittedSubtrees(tbvCert, subjectAltNames, permittedSubtrees))
      {
        LOG.fine("permitted subtrees not vaild");

        return false;
      }

      if (!checkExcludedSubtrees(tbvCert, excludedSubtrees))
      {
        LOG.fine("excluded subtrees not vaild");

        return false;
      }

      updateSubtrees(tbvCert);

      updateInhibitAnyPolicy(tbvCert, i);

      if (explicitPolicy <= i)
      {
        if (!verifyExplicitPolicySet(tbvCert))
        {
          LOG.fine("explicit policy required and not found");

          return false;
        }
      }

      if (!checkAndUpdateCertPolicies(tbvCert))
      {
        LOG.fine("no acceptable policy left");

        return false;
      }

      updatePolicyConstraints(tbvCert, i);

      containsUnknownCriticalExtensionFlag =
            containsUnknownCriticalExtensionFlag || checkForUnknownCriticalExtensions(tbvCert);

      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("containsUnknownCriticalExtensionFlag:" + containsUnknownCriticalExtensionFlag);
      }
    }

    return true;
  }

  /**
   * After calling the validateCertPath() method, this method returns the set of acceptable policies.
   * @return HashSet The set of acceptable policies.
   */
  public HashSet<String> getAcceptablePolicySet()
  {
    return acceptablePolicySet;
  }

  /**
   * Retruns true if any certificate in the path contains a critical but unknown certificate extension. You have to call validateCertPath() first, otherwise always false is reurned.
   * @return boolean
   */
  public boolean containsUnknownCriticalExtension()
  {
    return containsUnknownCriticalExtensionFlag;
  }

  /**
   * Check if the given certificate contains an unkown extension marked as critical.
   * @param tbvCert X509CertificateObject
   * @return boolean
   */
  @SuppressWarnings("unchecked")
  private boolean checkForUnknownCriticalExtensions(X509CertificateObject tbvCert)
  {
    Set<String> criticalOIDs = tbvCert.getCriticalExtensionOIDs();

    if (criticalOIDs == null)
    {
      return false;
    }

    for (String oid : criticalOIDs)
    {
        if (!certExts.values().contains(oid))
        	return true;
    }

    return false;
  }

  private boolean checkBasicConstraits(X509CertificateObject tbvCert)
  {
    // ATTENTION !!!!
    //this is a workaround, because older ca-certificates dont include the BasicConstraints-Extension
    //so the Validation will go wrong.
    BasicConstraints basicConstrains;
    byte[] tmpExtension = tbvCert.getExtensionValue(certExts.get("BASIC_CONSTRAINTS"));
    if (tmpExtension != null)
    {
      try
      {
        try
        {
      	  tmpExtension =  ((DEROctetString) ASN1Object.fromByteArray(tmpExtension)).getOctets();
          basicConstrains = new BasicConstraints((ASN1Sequence)ASN1Object.fromByteArray(tmpExtension));
        }
        catch (IOException e)
        {
          LOG.log(Level.SEVERE, "Cant get BasicConstrains from certificate", e);

          return false;
        }

        if (!basicConstrains.isCA())
        {
          LOG.fine("Found BasicConstrains, but no CA");

          return false;
        }

        // if KeyUsage is markt critical, it must contain CertSignKey
        if ((tbvCert.getCriticalExtensionOIDs() != null)
            && tbvCert.getCriticalExtensionOIDs().contains(certExts.get("KEY_USAGE")))
        {
          if (!tbvCert.getKeyUsage()[5])
          {
            LOG.fine("wrong keyusage for CA certs");

            return false;
          }
        }
      }
      catch (Throwable ex)
      {
        LOG.log(Level.SEVERE, "Cant check BasicConstrains", ex);
      }
    }
    return true;
  }

  private boolean checkPermittedSubtrees(X509CertificateObject tbvCert, Hashtable<Integer, List<Object>> subjectAltNames, GeneralSubtree[] _permittedSubtrees)
        throws IOException
  {
    if (_permittedSubtrees == null)
      return true;

    boolean containsDirectoryName = subjectAltNames.containsKey(GeneralName.directoryName);

    //extra check
    if (!containsDirectoryName)
    {
      boolean containDNName = subtreesContainDName(_permittedSubtrees, (X509Name) tbvCert.getSubjectDN());

      if (!containDNName)
      {
        return false;
      }
    }

    boolean containsAll = subtreesContainAllGeneralNames(_permittedSubtrees, subjectAltNames);

    if (!containsAll)
    {
    	LOG.fine("not all permitted subtrees found");
        return false;
    }

    return true;
  }

  private boolean checkExcludedSubtrees(X509CertificateObject tbvCert, GeneralSubtree[] _excludedSubtrees)
        throws IOException
  {
    if (_excludedSubtrees == null)
    {
      return true;
    }
    ASN1InputStream tmpASN1In = null;

    Hashtable<Integer, List<Object>> subjectAltNames = getGeneralNames(tbvCert);

    boolean containsDirectoryName = subjectAltNames.containsKey(GeneralName.directoryName);

    //extra check
    if (!containsDirectoryName)
    {
      boolean containDNName = subtreesContainDName(_excludedSubtrees, (X509Name) tbvCert.getSubjectDN());

      if (containDNName)
      {
        return false;
      }
    }

    if (subjectAltNames.size() > 0)
    {
      boolean containsAny = subtreesContainAnyOfGeneralNames(_excludedSubtrees, subjectAltNames);

      if (containsAny)
      {
        LOG.fine("FOUND excludedSubtree");

        return false;
      }
    }

    return true;
  }

  /**
   * checks if all of the permitted subtrees appear in all of the names.
   * @param excluded GeneralSubtree[]
   * @param names GeneralName[]
   * @return boolean
   */
  private boolean subtreesContainAllGeneralNames(GeneralSubtree[] permitted, Hashtable<Integer, List<Object>> subjectAltNames)
  {
	  for (Integer tn : subjectAltNames.keySet())
	  {
		  int tagNo = Integer.valueOf(tn);
		  for (Object checkObject : subjectAltNames.get(tagNo))
		  {
			  boolean tagIsContained = false;
			  for (GeneralSubtree tmpElement : permitted)
			  {
				  GeneralName permit = tmpElement.getBase();
				  if (permit.getTagNo() == tagNo)
				  {
					  Object permitObject = null;
					  switch (tagNo)
					  {
					  	case GeneralName.ediPartyName:
					  	case GeneralName.x400Address:
					  	case GeneralName.otherName:
					  		permitObject = permit.getName().getDERObject();
					  		break;
					  	case GeneralName.directoryName:
					  		tagIsContained = containsDNName(X509Name.getInstance(permit.getName()),
					  				(X509Name)checkObject);
					  		break;
					  	case GeneralName.uniformResourceIdentifier:
					  	case GeneralName.rfc822Name:
					  	case GeneralName.dNSName:
					  		permitObject = ((DERString)permit.getName()).getString();
					  		break;
					  	case GeneralName.registeredID:
					  		permitObject = DERObjectIdentifier.getInstance(permit.getName()).getId();
					  		break;
					  	case GeneralName.iPAddress:
					  		permitObject = DEROctetString.getInstance(permit.getName()).getOctets();
					  		break;
					  }
					  if (permitObject != null && permitObject.equals(checkObject))
					  {
						  tagIsContained = true;
						  break;
					  }
				  }
			  }
			  if (!tagIsContained)
				  return false;
		  }
	  }
	  return true;
  }

  /**
   * checks if any of the excluded subtrees appear in any of the names.
   * @param excluded GeneralSubtree[]
   * @param names GeneralName[]
   * @return boolean
   */
  private boolean subtreesContainAnyOfGeneralNames(GeneralSubtree[] excluded, Hashtable<Integer, List<Object>> subjectAltNames)
  {
    for (GeneralSubtree tmpElement : excluded)
    {
      GeneralName permit = tmpElement.getBase();
      Object permitObject = null;

      switch(permit.getTagNo())
      {
	  	case GeneralName.ediPartyName:
	  	case GeneralName.x400Address:
	  	case GeneralName.otherName:
	  		permitObject = permit.getName().getDERObject();
	  		break;
	  	case GeneralName.directoryName:
	  		for (Object x : subjectAltNames.get(GeneralName.directoryName))
	  			if (containsDNName(X509Name.getInstance(permit.getName()), (X509Name)x))
	  				return true;
	  		break;
	  	case GeneralName.uniformResourceIdentifier:
	  	case GeneralName.rfc822Name:
	  	case GeneralName.dNSName:
	  		permitObject = ((DERString)permit.getName()).getString();
	  		break;
	  	case GeneralName.registeredID:
	  		permitObject = DERObjectIdentifier.getInstance(permit.getName()).getId();
	  		break;
	  	case GeneralName.iPAddress:
	  		permitObject = DEROctetString.getInstance(permit.getName()).getOctets();
	  		break;
      }

      if (subjectAltNames.get(permit.getTagNo()).contains(permitObject))
    	  return true;
    }
    return false;
  }

  private boolean subtreesContainDName(GeneralSubtree[] excluded, X509Name name)
  {
    if (excluded != null)
    {
      for (GeneralSubtree tmpElement : excluded)
      {
        if (tmpElement.getBase().getTagNo() == GeneralName.directoryName)
        {
          if (containsDNName(X509Name.getInstance(tmpElement.getBase().getName()), name))
          {
            return true;
          }
        }
      }
    }

    return false;
  }

  /**
     (a) attribute values encoded in different types (e.g.,
     PrintableString and BMPString) may be assumed to represent
     different strings;
     (b) attribute values in types other than PrintableString are case
     sensitive (this permits matching of attribute values as binary
     objects);
     (c) attribute values in PrintableString are not case sensitive
     (e.g., "Marianne Swanson" is the same as "MARIANNE SWANSON"); and
     (d) attribute values in PrintableString are compared after
     removing leading and trailing white space and converting internal
     substrings of one or more consecutive white space characters to a
     single space.
   */
  @SuppressWarnings("unchecked")
  private boolean containsDNName(X509Name excluded, X509Name toCheck)
  {
    if ((excluded != null) && (toCheck != null))
    {
      Vector<DERObjectIdentifier> excludedOids = excluded.getOIDs();
      Vector excludedValues = excluded.getValues();
      Vector<DERObjectIdentifier> toCheckOids = toCheck.getOIDs();
      Vector toCheckValues = toCheck.getValues();

      for (int i = 0; i < excludedOids.size(); i++)
      {
        Object oid = excludedOids.get(i);
        Object value = excludedValues.get(i);

        if (toCheckOids.contains(oid))
        {

          if (toCheckValues.get(toCheckOids.indexOf(oid)).equals(value))
          {
            return true;
          }
        }
      }
    }

    return false;
  }

  private void updateSubtrees(X509CertificateObject tbvCert)
        throws IOException
  {

    byte[] tmpExtension = tbvCert.getExtensionValue(certExts.get("NAME_CONSTRAINTS"));
    if (tmpExtension != null)
    {
    	tmpExtension =  ((DEROctetString) ASN1Object.fromByteArray(tmpExtension)).getOctets();

    	NameConstraints nameConstraints = new NameConstraints((ASN1Sequence)ASN1Object.fromByteArray(tmpExtension));

    	ASN1Sequence seq = nameConstraints.getPermittedSubtrees();
    	GeneralSubtree[] newPermittedTrees = new GeneralSubtree[seq.size()];
    	for (int j = 0; j < seq.size(); j++)
    		newPermittedTrees[j] = new GeneralSubtree((ASN1Sequence) seq.getObjectAt(j));

    	seq = nameConstraints.getExcludedSubtrees();
    	GeneralSubtree[] newExcludedTrees = new GeneralSubtree[seq.size()];
    	for (int j = 0; j < seq.size(); j++)
    		newExcludedTrees[j] = new GeneralSubtree((ASN1Sequence) seq.getObjectAt(j));

    	excludedSubtrees = union(excludedSubtrees, newExcludedTrees);

    	permittedSubtrees = intersection(permittedSubtrees, newPermittedTrees);

    }

  }

  private GeneralSubtree[] intersection(GeneralSubtree[] a, GeneralSubtree[] b) throws IOException
  {
    HashSet<GeneralSubtree> intersect = new HashSet<GeneralSubtree>();

    if ((a != null) && (b != null))
    {
      for (GeneralSubtree tmpElement : a)
      {
        for (GeneralSubtree tmpElement2 : b)
        {
          boolean added = false;

          if (subtreesContainAllGeneralNames(new GeneralSubtree[] { tmpElement },
                                             getGeneralNames(new GeneralName[] { tmpElement2.getBase()})))
          {
            intersect.add(tmpElement2);
            added = true;
          }

          if (!added
              && subtreesContainAllGeneralNames(new GeneralSubtree[] { tmpElement2 },
            		  getGeneralNames(new GeneralName[] { tmpElement2.getBase()})))
          {
            intersect.add(tmpElement);
          }
        }
      }

      return intersect.toArray(new GeneralSubtree[intersect.size()]);
    }

    if ((a != null) && (b == null))
    {
      return a;
    }

    if (a == null)
    {
      return b;
    }

    return null;
  }

  private GeneralSubtree[] union(GeneralSubtree[] a, GeneralSubtree[] b)
  {
    if ((a != null) && (b != null))
    {
      GeneralSubtree[] result = new GeneralSubtree[a.length + b.length];

      for (int i = 0; i < a.length; i++)
      {
        result[i] = a[i];
      }

      for (int i = 0; i < b.length; i++)
      {
        result[a.length + i] = b[i];
      }

      return result;
    }

    if ((a != null) && (b == null))
    {
      return a;
    }

    if (a == null)
    {
      return b;
    }

    return null;
  }

  /**
   * Computed the intersecetion of the two given Hashsets (used for the policy testing).
   * @param a HashSet
   * @param b HashSet
   * @return HashSet
   */
  private HashSet<String> intersectionOfOIDs(HashSet<String> a, HashSet<String> b)
  {
    if (a == null)
    {
      return b;
    }

    if (b == null)
    {
      return a;
    }

    HashSet<String> intersection = new HashSet<String>();
    String[] oids = a.toArray(new String[a.size()]);

    for (String tmpElement : oids)
    {
      if (b.contains(tmpElement) || b.contains(certExts.get("ANY_POLICY_OID")))
      {
        intersection.add(tmpElement);
      }
    }

    return intersection;
  }

  private HashSet<String> getCertPolicyOIDs(X509CertificateObject tbvCert)
        throws IOException
  {
    //log.fine("Get Cert OIDs");
	  HashSet<String> oidSet = new HashSet<String>();
	  byte[] tmpExtension = tbvCert.getExtensionValue(certExts.get("CERTIFICATE_POLICIES"));
	  if (tmpExtension != null)
	  {
      	  tmpExtension =  ((DEROctetString) ASN1Object.fromByteArray(tmpExtension)).getOctets();
		  ASN1Sequence seq = (ASN1Sequence)ASN1Object.fromByteArray(tmpExtension);
		  DERObjectIdentifier doi;
		  for (int i=0; i < seq.size(); i++)
    		oidSet.add(new PolicyInformation((ASN1Sequence)seq.getObjectAt(i)).getPolicyIdentifier().getId());
	  }
	  return oidSet;
  }

  private boolean verifyExplicitPolicySet(X509CertificateObject tbvCert)
        throws IOException
  {
    HashSet<String> explicitPolicies = getCertPolicyOIDs(tbvCert);

    if (explicitPolicies.isEmpty())
    {
      return false;
    }

    return true;
  }

  private boolean checkAndUpdateCertPolicies(X509CertificateObject tbvCert)
        throws IOException
  {
    if ((tbvCert.getCriticalExtensionOIDs() != null)
        && tbvCert.getCriticalExtensionOIDs().contains(certExts.get("CERTIFICATE_POLICIES")))
    {
      HashSet<String> explicitPolicies = getCertPolicyOIDs(tbvCert);
      HashSet<String> intersection = intersectionOfOIDs(explicitPolicies, acceptablePolicySet);

      if ((intersection == null) || intersection.isEmpty())
      {
        return false;
      }
    }


    HashSet<String> explicitPolicies = getCertPolicyOIDs(tbvCert);

    if (!explicitPolicies.isEmpty())
    {
      acceptablePolicySet = intersectionOfOIDs(explicitPolicies, acceptablePolicySet);
    }



    return true;
  }

  private void updatePolicyConstraints(X509CertificateObject tbvCert, int i)
        throws IOException
  {
    byte[] tmpPolicy = tbvCert.getExtensionValue(certExts.get("POLICY_CONSTRAINTS"));

    if (tmpPolicy != null)
    {
    	tmpPolicy =  ((DEROctetString) ASN1Object.fromByteArray(tmpPolicy)).getOctets();
        ASN1Sequence seq = (ASN1Sequence) ASN1Object.fromByteArray(tmpPolicy);

        for (int j = 0; j < seq.size(); j++)
        {
          DERTaggedObject tagged = (DERTaggedObject) seq.getObjectAt(j);
          if (tagged.getTagNo() == 0)
        	  //RequieExplicitPolicy
        	  explicitPolicy = Math.min(DERInteger.getInstance(tagged, false).getValue().intValue()
        			  + i, explicitPolicy);
          else
        	  //InhibitPolicyMapping
              policyMapping = Math.min(DERInteger.getInstance(tagged, false).getValue().intValue()
            		  + i, policyMapping);
          }
    }
  }

  private boolean isSelfSigned(X509CertificateObject tbvCert)
  {
	  if (tbvCert.getIssuerDN().equals(tbvCert.getSubjectDN()))
	  {
		  // If the key identifier matches, return immediately
		  if (ResponderHelper.getAuthorityKeyIdentifier(tbvCert).
				  equals(ResponderHelper.getSubjectKeyIdentifier(tbvCert)))
			  return true;
		  try
		  {
			  tbvCert.verify(tbvCert.getPublicKey());
			  return true;
		  }
		  catch (Exception e)
		  {
			  LOG.fine("Found issuer certificate with matching subjectDN but verify failed.");
		  }
	  }
	  return false;
  }

  private void updateInhibitAnyPolicy(X509CertificateObject tbvCert, int i) throws IOException
  {
	  if (isSelfSigned(tbvCert))
		  inhibitAnyPolicy++;

	  byte[] tmpPolicy = tbvCert.getExtensionValue(certExts.get("INHIBIT_ANY_POLICY"));

	  if (tmpPolicy != null)
		  inhibitAnyPolicy =  Math.min(((DERInteger) ASN1Object.fromByteArray(tmpPolicy)).getValue().intValue()
				  + i, inhibitAnyPolicy);

	  if (inhibitAnyPolicy <= i)
		  acceptablePolicySet.remove(certExts.get("ANY_POLICY_OID"));
  }

  private static Hashtable<Integer, List<Object>> getGeneralNames(X509CertificateObject cert) throws IOException
  {
	  byte[] ext = cert.getExtensionValue(certExts.get("SUBJECT_ALT_NAMES"));
	  if (ext == null)
		  return new Hashtable<Integer, List<Object>>();

	  DEROctetString deros =  (DEROctetString) ASN1Object.fromByteArray(ext);
	  GeneralName[] gns = GeneralNames.getInstance((ASN1Sequence)ASN1Object.fromByteArray(deros.getOctets())).getNames();
	  return getGeneralNames(gns);
  }

  private static Hashtable<Integer, List<Object>> getGeneralNames(GeneralName[] gns) throws IOException
  {
	  Hashtable<Integer, List<Object>> ret = new Hashtable<Integer, List<Object>>();
	  int tn;
	  for (GeneralName genName : gns)
	  {
		 tn = Integer.valueOf(genName.getTagNo());
		 switch (tn)
		 {
		 case GeneralName.ediPartyName:
		 case GeneralName.x400Address:
		 case GeneralName.otherName:
        	if (ret.get(tn) == null)
        		ret.put(tn, new ArrayList<Object>());
            ret.get(tn).add(genName.getName().getDERObject());
            break;
		 case GeneralName.directoryName:
			 if (ret.get(tn) == null)
				 ret.put(tn, new ArrayList<Object>());
			 ret.get(tn).add(X509Name.getInstance(genName.getName()));
			 break;
		 case GeneralName.dNSName:
		 case GeneralName.rfc822Name:
		 case GeneralName.uniformResourceIdentifier:
			 if (ret.get(tn) == null)
				 ret.put(tn, new ArrayList<Object>());
			 ret.get(tn).add(((DERString)genName.getName()).getString());
			 break;
		 case GeneralName.registeredID:
	        	if (ret.get(tn) == null)
	        		ret.put(tn, new ArrayList<Object>());
	        	ret.get(tn).add(DERObjectIdentifier.getInstance(genName.getName()).getId());
	            break;
		 case GeneralName.iPAddress:
			 if (ret.get(tn) == null)
				 ret.put(tn, new ArrayList<Object>());
			 ret.get(tn).add(DEROctetString.getInstance(genName.getName()).getOctets());
			 break;
		 default:
			 throw new IOException("Bad tag number: " + genName.getTagNo());
		 }

	  }
	  return ret;

  }

}
