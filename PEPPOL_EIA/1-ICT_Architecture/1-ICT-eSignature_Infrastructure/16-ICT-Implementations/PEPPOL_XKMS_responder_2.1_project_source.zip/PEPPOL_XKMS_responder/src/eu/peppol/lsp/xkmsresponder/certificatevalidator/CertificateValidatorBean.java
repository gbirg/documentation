/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatevalidator;

import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.common.CVRequest;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;


/*
 * This class performs the parallelized certificate validation.
 * @author Andre Jens
 * @author mho
 * @version $Revision: 1.21 $
 * 
*/
public class CertificateValidatorBean extends Thread
{
  private static Logger LOG = Logger.getLogger(CertificateValidatorBean.class.getName());

  // unique ID of this object
  private static final long serialVersionUID = 576235245;

  private CVRequest[] cvRequests;

  private int index;

  private CertificatevalidatorResult cvResult;

  private Exception ex;

  /**
   * DOCUMENT ME!
   */
  public CertificateValidatorBean(CVRequest[] requests, int index)
  {
    LOG.fine("(constr) CertificateValidatorBean");
    this.cvRequests = requests;
    this.index = index;
  }

  /**
   * Uebergeben werden immer zwei Zertifikate.
   * Das zu pruefende Zertifikat und das Herausgeberzertifikat
   *
   * @param msg DOCUMENT ME!
   */
  public void run()
  {
	LOG.fine("(start) run()");
	try
    {
		CVRequest request = cvRequests[index];
		CertificatevalidatorResult result = null;

		X509Certificate[] certs = new X509Certificate[2];

		LOG.fine("OCSPResponderCheck is not set.");
		certs[0] = request.getUsercert();
		certs[1] = request.getIssuercert();

		if (!request.isTAOrBehind())
		{
			result =
				CertificateValidatorProcess.process(certs[0], certs[1], request.getOCSPNoCache(),
						request.getRequestID());
		}
		else
		{
			result = new CertificatevalidatorResult(certs[0]);
			IssuerDto tmpIssuerDto = null;

			try
			{
				tmpIssuerDto = Configuration.getIssuerDtoByUserCertificate(certs[0]);
				if (tmpIssuerDto == null)
					LOG.severe("Can not find Issuer: " + certs[0].getIssuerDN().getName());
				else
				{
					result.setCertQuality(tmpIssuerDto.getQuality());
					LOG.fine("CSPAssurance: " + tmpIssuerDto.getCSPAssurance());
					result.setCSPAssurance(tmpIssuerDto.getCSPAssurance());
					result.setValidationModel(tmpIssuerDto.getValidateModel());
					result.setCertQuality(tmpIssuerDto.getQuality());
					result.setAlgPolicyIdentifier(tmpIssuerDto.getAlgPolicyIdentifier());
					result.setTslIdentifier(tmpIssuerDto.getTSLIdentifier());
					result.setTspInformation(tmpIssuerDto.getTSPInformation());
					result.setTspServiceInformation(tmpIssuerDto.getTSPServiceInformation());
				}
			}
			catch (Exception ex)
			{
				LOG.log(Level.INFO, "Can not find Issuer: " + certs[0].getIssuerDN().getName(), ex);
			}

			result.setStatus(CertificatevalidatorResult.STATUS_VALID);
			result.addValidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
			result.addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
			result.setValidateScheme(ValMethodType.LOCAL);
		}

		if (LOG.isLoggable(Level.FINE))
		{
			LOG.fine("Received Certificate on Position " + request.getChainpos());
		}

		result.setChainpos(request.getChainpos());

		LOG.fine("Now sending Response");

		synchronized (cvRequests)
		{
			cvResult = result;
			LOG.fine("NOTIFY " + index);
			cvRequests.notifyAll();
		}
    }
	catch (Exception ex3)
    {
      LOG.log(Level.SEVERE, "Error in onMessage", ex3);
	  synchronized (cvRequests)
	  {
		  this.ex = ex3;
		  cvRequests.notifyAll();
	  }
    }
  }

  public CertificatevalidatorResult getCVResponse() throws Exception
  {
	  if (ex != null)
		  throw new Exception("Error in certificate validation.", ex);
	  return cvResult;
  }
}
