/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatevalidator;

import java.security.cert.X509Certificate;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;

/**
 * Stores the instances of OCSPResponseCacheEntry.
 * Cleanup of cache every 300 seconds, triggered by adding new entries.
 * @author buengener
 *
 * 
*/
public class OCSPResponseCache
{

  private static Logger LOG = Logger.getLogger(OCSPResponseCache.class.getName());

  private static Hashtable<String, OCSPResponseCacheEntry> cache =
        new Hashtable<String, OCSPResponseCacheEntry>();

  private static long nextCleanUp = 0;

  private static int cacheCleanInterval = 300000;

  public static synchronized void cleanCache()
  {
    LOG.fine("cleanCache() start CleanUP OCSPCache" + System.currentTimeMillis());

    // Cache aufraeumen
    nextCleanUp = System.currentTimeMillis() + cacheCleanInterval;
    long time = System.currentTimeMillis();
    Iterator<Entry<String, OCSPResponseCacheEntry>> it = cache.entrySet().iterator();
    while (it.hasNext())
    {
    	Entry<String, OCSPResponseCacheEntry> elem = it.next();
    	OCSPResponseCacheEntry entry = elem.getValue();
    	if (entry.getCacheTimeout() < time)
    		it.remove();
    }
  }

  public static synchronized void addEntry(X509Certificate certificate, long cacheTimeout, int state,
                              CvOCSPResult cvOCSPResult)
  {
	  if (nextCleanUp < System.currentTimeMillis())
		  cleanCache();
	  String certid = getCertificateId(certificate);
	  OCSPResponseCacheEntry entry = new OCSPResponseCacheEntry(certid, cacheTimeout, state, cvOCSPResult);
	  LOG.fine("addEntry() Caching OCSP Response with certid: " + certid + " until " + cacheTimeout);
      cache.put(certid, entry);
  }

  public static OCSPResponseCacheEntry findEntry(X509Certificate certificate)
  {
    try
    {
      String certid = getCertificateId(certificate);
      OCSPResponseCacheEntry tmpResponseCacheEntry = cache.get(certid);
      if (tmpResponseCacheEntry != null
    	  && System.currentTimeMillis() < tmpResponseCacheEntry.getCacheTimeout())
    	  	return tmpResponseCacheEntry;
    }
    catch (NullPointerException ex)
    {
      // cacheentry not found, return null
      LOG.severe("findEntry() - Certificate is null");
    }
    return null;
  }

  private static String getCertificateId(X509Certificate certificate)
  {
    return certificate.getIssuerDN().toString() + certificate.getSerialNumber();
  }
}
