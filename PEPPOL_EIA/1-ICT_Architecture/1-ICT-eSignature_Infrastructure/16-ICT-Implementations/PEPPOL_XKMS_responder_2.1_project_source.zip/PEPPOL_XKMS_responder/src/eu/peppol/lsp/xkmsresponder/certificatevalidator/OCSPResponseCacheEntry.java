/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatevalidator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;

/**
 * This class holds the information of a OCSP response for successive validations.
 * @author buengener
 *
 * 
*/
public class OCSPResponseCacheEntry
{
	protected Logger LOG = Logger.getLogger(OCSPResponseCacheEntry.class.getName());

  private final long cachetimeout;

  private final int status;

  private final String certid;

  private int ocspRespSignature = CvOCSPResult.OCSPResp_UNCHECKED;

  private int ocspRespStatus;

  private int revocationReason = CertificatevalidatorResult.REVOCATIONREASON_NONE;

  private Date revocationTime;

  private String producedAt;

  private byte[] ocspResp;

  private boolean isCommonPKIIndeterminate = false;

  private String errorcode;

  private CPVResponse cPVResponse;

  private final List<Integer> validReason = new ArrayList<Integer>();

  private final List<Integer> invalidReason = new ArrayList<Integer>();

  private final List<Integer> indeterminateReason = new ArrayList<Integer>();


  public OCSPResponseCacheEntry(String _certid, long _cachetime, int _state, CvOCSPResult _cvOcspResult)
  {
	  certid = _certid;
	  cachetimeout = _cachetime;
	  status = _state;
	  ocspRespSignature = _cvOcspResult.getOcspRespSignature();
	  producedAt = _cvOcspResult.getProducedAt();
	  ocspResp = _cvOcspResult.getOcspResp();
	  isCommonPKIIndeterminate = _cvOcspResult.isCommonPKIIndeterminate();
	  revocationReason = _cvOcspResult.getRevokationReason();
	  revocationTime = _cvOcspResult.getRevokationTime();
	  errorcode = _cvOcspResult.getErrorCode();
	  cPVResponse = _cvOcspResult.getCPVResponse();
	  ocspRespStatus = _cvOcspResult.getOcspRespStatus();
	  validReason.addAll(_cvOcspResult.getValidReason());
	  invalidReason.addAll(_cvOcspResult.getInvalidReason());
	  indeterminateReason.addAll(_cvOcspResult.getIndeterminateReason());
  }

  public Integer getOcspRespSignature()
  {
	return ocspRespSignature;
  }

  public int getOcspRespStatus()
  {
    return ocspRespStatus;
  }

  public String getProducedAt()
  {
	return producedAt;
  }

  public byte[] getOcspResp()
  {
	return ocspResp;
  }

  public boolean isCommonPKIIndeterminate()
  {
	return isCommonPKIIndeterminate;
  }

  public int getStatus()
  {
    return status;
  }

  public long getCacheTimeout()
  {
    return cachetimeout;
  }

  public String getCertID()
  {
    return certid;
  }

  public int getRevocationReason()
  {
		return revocationReason;
  }

  public Date getRevocationTime()
  {
		return revocationTime;
  }

  public String getErrorCode()
  {
		return errorcode;
  }

  public CPVResponse getCpvResponse()
  {
		return cPVResponse;
  }

  public void addReasons(CvOCSPResult result)
  {
	  for (Integer r : validReason)
		  result.addValidReason(r);
	  for (Integer r : invalidReason)
		  result.addInvalidReason(r);
	  for (Integer r : indeterminateReason)
		  result.addIndeterminateReason(r);
  }

}
