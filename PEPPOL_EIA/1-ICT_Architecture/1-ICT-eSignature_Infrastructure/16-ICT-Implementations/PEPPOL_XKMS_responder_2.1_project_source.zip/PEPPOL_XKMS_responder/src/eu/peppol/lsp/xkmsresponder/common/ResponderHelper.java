/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.common;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.Hashtable;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.security.auth.x500.X500Principal;

import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;

import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;


/*
 * Helper-Class which holds static Methods e.g. for
 * certificate creation. The methods *CurrentlyValidatingSignatureCertificate(..)
 * maintain a list of certificates currently under validation to avoid concurrent
 * validation processes.
 * @author mho
 * @author buengener
 * @version $Revision: 1.2 $
 * 
 */
public final class ResponderHelper
{

  /** Commons logger */
  private static final Logger LOG = Logger.getLogger(ResponderHelper.class.getName());

  public static final String DIGEST_ALGO = "SHA256";

  /** CertificateFactory */
  private static CertificateFactory cf = null;

  /** Encoding */
  public static final String ENCODING = "UTF-8";

  /** Host name */
  public static String hostName = null;

  public static Provider SECURITYPROVIDER = new BouncyCastleProvider();

  //all Certificates that already in the queue
  private static Hashtable<Long, Hashtable<String, X509Certificate>> currentlyValidatingSignatureCertificates;

  //  // Internal
  private static Hashtable<String, Boolean> ocspSuccess;

  private static final char[] hex  = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
	  'A', 'B', 'C', 'D', 'E', 'F'};

  static
  {
    LOG.fine("(start) init()");

    try
    {
      cf = CertificateFactory.getInstance("X509", SECURITYPROVIDER);
    }
    catch (CertificateException ex)
    {
      LOG.log(Level.SEVERE, "Error loading certfifcate factory", ex);
    }

    try
    {
      hostName = InetAddress.getLocalHost().getHostName() + "|";
    }
    catch (UnknownHostException e)
    {
      LOG.severe("Cant get Hostname.");

      hostName = "unknown";
    }
  }

  /**
   * Creates an x509Certificate from an byte-array
   *
   * @param _data the byte-array that holds the Certificate
   *
   * @return an instance of X509Certificate
   */
  public static X509Certificate createCertificate(byte[] _data)
  {
    return createCertificate(new java.io.ByteArrayInputStream(_data));
  }

  /**
   * Creates an x509Certificate from an byte-array
   *
   * @param _data the byte-array that holds the Certificate
   *
   * @return an instance of X509Certificate
   */
  public static X509Certificate createCertificate(InputStream in)
  {
    LOG.fine("(start) createCertificate(???)");

    if (in == null)
    {
      LOG.fine("IllegalArgumentException : Param in cant be null");
      throw new java.lang.IllegalArgumentException("IllegalArgumentException : Param in cant be null");
    }

    try
    {
    	X509Certificate ret = (X509Certificate) cf.generateCertificate(in);
    	return ret;
    }
    catch (GeneralSecurityException ex)
    {
    	LOG.log(Level.SEVERE, "Error reading certificate", ex);
    }
    return null;
  }

  public static void addCurrentlyValidatingSignatureCertificate(Long _requestID,
                                                                X509Certificate certificate)
  {
    if (currentlyValidatingSignatureCertificates == null)
    {
      currentlyValidatingSignatureCertificates = new Hashtable<Long, Hashtable<String, X509Certificate>>();
    }

    if (!currentlyValidatingSignatureCertificates.containsKey(_requestID))
    {
      Hashtable<String, X509Certificate> certs = new Hashtable<String, X509Certificate>();
      certs.put(certificate.getSerialNumber().toString() + certificate.getIssuerDN().getName(), certificate);
      currentlyValidatingSignatureCertificates.put(_requestID, certs);
    }
    else
    {
      Hashtable<String, X509Certificate> certs = currentlyValidatingSignatureCertificates.get(_requestID);
      certs.put(certificate.getSerialNumber().toString() + certificate.getIssuerDN().getName(), certificate);
    }
  }

  public static void removeCurrentlyValidatingSignatureCertificate(Long _requestID,
                                                                   X509Certificate certificate)
  {
    if (currentlyValidatingSignatureCertificates == null)
    {
      currentlyValidatingSignatureCertificates = new Hashtable<Long, Hashtable<String, X509Certificate>>();

    }

    if ((certificate != null) && (_requestID != null))
    {
      if (currentlyValidatingSignatureCertificates.containsKey(_requestID))
      {
        Hashtable<String, X509Certificate> certs =
              currentlyValidatingSignatureCertificates.get(_requestID);

        certs.remove(certificate.getSerialNumber().toString() + certificate.getIssuerDN().getName());

        if (certs.isEmpty())
        {
          currentlyValidatingSignatureCertificates.remove(_requestID);
        }
      }
    }
  }

  @SuppressWarnings("cast")
  public static boolean isCurrentlyValidatingSignatureCertificate(Long _requestID,
                                                                  X509Certificate certificate)
  {
    if (currentlyValidatingSignatureCertificates == null)
    {
      currentlyValidatingSignatureCertificates = new Hashtable<Long, Hashtable<String, X509Certificate>>();
    }

    if ((certificate != null) && (_requestID != null))
    {
      try
      {
        if (currentlyValidatingSignatureCertificates.containsKey(_requestID))
        {
          Hashtable<String, X509Certificate> certs =
                currentlyValidatingSignatureCertificates.get(_requestID);
          X509Certificate certFromList = null;
          certFromList = certs.get(certificate.getSerialNumber().toString() + certificate.getIssuerDN().getName());
          if (certFromList != null)
          {
            if (certFromList.equals(certificate))
            {
              LOG
                 .fine("Certificate of OCSP-Response Signature will be currently checked ! Dont check again");

              return true;
            }

            LOG.fine("Certificate of OCSP-Response Signature will be currently not checked ! Check again");

            return false;
          }
        }
        else
        {
          return false;
        }
      }
      catch (Exception ex)
      {
        LOG.log(Level.SEVERE, "Error while checking if certificates is currently checked.", ex);
        return false;
      }
    }

    return false;
  }

  /**
   * Simple distinguished name parser. Extracts the given key's property.
   *
   * @param subjectDN Distinguished name to be parsed
   * @param propertyKey Key for requested property
   *
   * @return Property
   */
  public static String getProperty(String subjectDN, String propertyKey)
  {
    final char separatorChar1 = ',';
    final char separatorChar2 = '+';
    final char assignmentChar = '=';
    boolean[] quoted = getQuotations(subjectDN, '\"');
    int i = -1;
    int j = indexOfNextNotQuotedChar(subjectDN, assignmentChar, i, quoted);
    int k1 = indexOfNextNotQuotedChar(subjectDN, separatorChar1, j, quoted);
    int k2 = indexOfNextNotQuotedChar(subjectDN, separatorChar2, j, quoted);
    int k = Math.min(k1, k2);

    if (k < 0)
    {
      k = Math.max(k1, k2);
    }

    while (j >= 0)
    {
      String key = subjectDN.substring(i + 1, j).trim();

      if (key.equals(propertyKey))
      {
        String value;

        if (k == -1)
        {
          value = subjectDN.substring(j + 1).trim();
        }
        else
        {
          value = subjectDN.substring(j + 1, k).trim();
        }

        return value;
      }

      if (k == -1)
      {
        return subjectDN; // not found
      }

      i = k;
      j = indexOfNextNotQuotedChar(subjectDN, assignmentChar, i, quoted);
      k1 = indexOfNextNotQuotedChar(subjectDN, separatorChar1, j, quoted);
      k2 = indexOfNextNotQuotedChar(subjectDN, separatorChar2, j, quoted);
      k = Math.min(k1, k2);

      if (k < 0)
      {
        k = Math.max(k1, k2);
      }
    }

    return subjectDN; // not found
  }

  private static int indexOfNextNotQuotedChar(String s, char c, int beginIndex, boolean[] quoted)
  {
    int idx = s.indexOf(c, beginIndex);

    while ((idx >= 0) && quoted[idx])
    {
      idx = s.indexOf(c, idx + 1);
    }

    return idx;
  }

  private static boolean[] getQuotations(String s, char quoteChar)
  {
    boolean[] quoted = new boolean[s.length()];
    int i = s.indexOf(quoteChar);
    int j = s.indexOf(quoteChar, i + 1);

    while ((i >= 0) && (j >= 0))
    {
      if (i < j)
      {
        for (int k = (i + 1); k < j; k++)
        {
          quoted[k] = true;
        }
      }

      i = s.indexOf(quoteChar, j + 1);
      j = s.indexOf(quoteChar, i + 1);
    }

    return quoted;
  }

  public static void setOCSPSuccess(String inpIssuerName, Boolean inpSuccess)
  {
    if (ocspSuccess == null)
    {
      ocspSuccess = new Hashtable<String, Boolean>();
    }
    ocspSuccess.put(inpIssuerName, inpSuccess);
  }

  public static Boolean getOCSPStatus(String inpIssuerName)
  {
    if (ocspSuccess == null)
    {
      ocspSuccess = new Hashtable<String, Boolean>();
    }
    return ocspSuccess.get(inpIssuerName);
  }

  public static String getFingerprint(X509Certificate cert) throws CertificateEncodingException
  {
    try
    {
      return ResponderHelper.getFingerprintHex(cert.getEncoded());
    }
    catch (NullPointerException ex)
    {
      LOG.fine("Error in getFingerprint: " + ex);
    }

    return null;
  }

  public static String getFingerprint(CertificateDto cert)
  {
    try
    {
      return getFingerprintHex(cert.getX509Certificate().getEncoded());
    }
    catch (CertificateEncodingException ex1)
    {
      LOG.severe("Error in getFingerprint: " + ex1);
    }
    catch (NullPointerException ex)
    {
      LOG.fine("Error in getFingerprint: " + ex);
    }

    return null;
  }

  public static String getFingerprintHex(byte[] data)
  {
	  try
	  {
		  MessageDigest md = MessageDigest.getInstance(DIGEST_ALGO, SECURITYPROVIDER);
		  return toHexString(md.digest(data));
	  }
	  catch (NoSuchAlgorithmException nsae)
	  {
		  LOG.log(Level.SEVERE, "Configuration error", nsae);
	  }
	  return null;
  }

  /**
   * DOCUMENT ME!
   *
   * @param b DOCUMENT ME!
   * @param seperator DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static String getTelesecCertificateSerialNumber(byte[] b, String seperator)
  {
    String serial = toHexString(b);

    if (serial.startsWith("0"))
    {
      serial = serial.substring(1);
    }

    LOG.fine("TelesecCertificateSerialNumber: 0x" + serial);

    return "0x" + serial;
  }

  /**
   * returns the extension SubjectKeyIdentifier from the given certificate
   *
   * @param _cert Certificate, from which the SubjectKeyIdentifier is searched
   * @return String the String representation of the SubjectKeyIdentifier
   */
  public static String getSubjectKeyIdentifier(X509Certificate _cert)
  {
    try
    {
      byte[] tmpExtension = _cert.getExtensionValue("2.5.29.14");
      if (tmpExtension == null)
    	  return "";

      tmpExtension = ((DEROctetString) ASN1Object.fromByteArray(tmpExtension)).getOctets();
      tmpExtension = ((DEROctetString) ASN1Object.fromByteArray(tmpExtension)).getOctets();
      return toHexString(tmpExtension);
    }
    catch (Exception ex)
    {
      LOG.log(Level.FINE, "Could not read SubjectKeyIdentifier.", ex);
      return "";
    }
  }

  /**
   * Returns the extension AuthorityKeyIdentifier from the given Certificate
   *
   * @param _cert Certificate, from which the AuthorityKeyIdentifier is searched
   * @return String the String representation of the AuthorityKeyIdentifier
   */
  public static String getAuthorityKeyIdentifier(X509Certificate _cert)
  {
	  return getAuthorityKeyIdentifier(_cert.getExtensionValue("2.5.29.35"));
  }

  /**
   * Returns the extension AuthorityKeyIdentifier from the given CRL
   *
   * @param inpX509CRL CRL, from which the AuthorityKeyIdentifier is searched
   * @return String the String representation of the AuthorityKeyIdentifier
   */
  public static String getAuthorityKeyIdentifier(X509CRL inpX509CRL)
  {
	  return getAuthorityKeyIdentifier(inpX509CRL.getExtensionValue("2.5.29.35"));
  }

  private static String getAuthorityKeyIdentifier(byte[] ext)
  {
	  try
	  {
		  if (ext == null)
			  return "";

		  ext = ((DEROctetString) ASN1Object.fromByteArray(ext)).getOctets();
		  ASN1TaggedObject tag = (ASN1TaggedObject)((ASN1Sequence)ASN1Object.fromByteArray(ext)).getObjectAt(0);
		  if (tag.getTagNo() == 0)
			  return toHexString(ASN1OctetString.getInstance(tag).getOctets());
		  return "";
	  }
	  catch (Exception ex)
	  {
		  LOG.log(Level.FINE, "Could not read AuthorityKeyIdentifier.", ex);
		  return "";
	  }
  }

  /**
   * Returns the String representation of the certificate subjectDN according to RFC 2253.
   * @param certificate Certificate for which the subject is requested
   * @return String the DN of the certificate subject
   */
  public static String getSubjectDN(X509Certificate certificate)
  {
    return certificate.getSubjectX500Principal().getName(X500Principal.RFC2253);
  }

  /**
   * Returns the String representation of the certificate subjectDN according to RFC 2253.
   * @param certificate a DTO object which contains the certificate the subject is requested
   * @return String the DN of the certificate subject
   */
  public static String getSubjectDN(CertificateDto certificate)
  {
    return getSubjectDN(certificate.getX509Certificate());
  }

  /**
   * Returns the String representation of the certificate issuerDN according to RFC 2253.
   * @param certificate certificate for which the issuer is requested
   * @return String the DN of the certificate issuer
   */
  public static String getIssuerDN(X509Certificate certificate)
  {
    return certificate.getIssuerX500Principal().getName(X500Principal.RFC2253);
  }

  /**
   * Returns the String representation of the certificate issuerDN according to RFC 2253.
   * @param certificate a DTO object which contains the certificate the issuer is requested
   * @return String the DN of the certificate issuer
   */
  public static String getIssuerDN(CertificateDto certificate)
  {
    return getIssuerDN(certificate.getX509Certificate());
  }

  /**
   * Returns the String representation of the CRL issuerDN according to RFC 2253.
   * @param crl CRL for which the issuer is requested
   * @return String the DN of the CRL issuer
   */
  public static String getIssuerDN(X509CRL crl)
  {
    return crl.getIssuerX500Principal().getName(X500Principal.RFC2253);
  }

  public static boolean isCriticalExtensionOID(X509Certificate tbvCert, String inpOID)
  {
    Set<String> tmpCriticalOIDs = tbvCert.getCriticalExtensionOIDs();
    if (tmpCriticalOIDs != null)
    {
      return tmpCriticalOIDs.contains(inpOID);
    }
    return false;
  }

  private static ByteArrayOutputStream readBoutFromStream(InputStream ins) throws IOException
  {
    byte[] inBytes = new byte[1024];
    ByteArrayOutputStream outs = new ByteArrayOutputStream();
    int readed;

    while ((readed = ins.read(inBytes)) > 0)
    {
      outs.write(inBytes, 0, readed);
    }

    try
    {
      ins.close();
    }
    catch (Exception e)
    {
      LOG.log(Level.WARNING, "Problem closing stream", e);
    }

    return outs;
  }

  /**
   * Read everything from given input stream into a String using default encoding.
   *
   * @param ins is closed if OK
   *
   * @return UTF-8 encoded String
   */
  public static String readFromStream(InputStream ins) throws IOException
  {
	  ByteArrayOutputStream baos = readBoutFromStream(ins);
	  String data = baos.toString(ENCODING);
	  if (data.startsWith("<?xml"))
	  {
		  int start = data.indexOf("encoding=\"") + 10;
		  int stop = data.indexOf('"', start);
		  String encoding = data.substring(start, stop);
		  if (!encoding.equals("UTF-8"))
			  return baos.toString(encoding);
	  }

	  return data;
  }

  public static byte[] readBytesFromStream(InputStream ins) throws IOException
  {
    return readBoutFromStream(ins).toByteArray();
  }

  /**
   * Return a hex representation of a given byte array
   * @param b data to transform
   */
  public static String toHexString(byte[] b)
  {
	  if (b.length == 0)
		  return "";
	  StringBuilder sb = new StringBuilder();
	  sb.append(hex[(b[0]>>4) & 0xf]);
	  sb.append(hex[b[0] & 0xf]);
	  for (int i = 1; i < b.length; i++)
	  {
		  sb.append(':');
		  sb.append(hex[(b[i]>>4) & 0xf]);
		  sb.append(hex[b[i] & 0xf]);
	  }
	  return sb.toString();
  }

  public static String base64encode(byte[] data)
  {
	  return new String(Base64.encode(data));
  }

  public static byte[] base64decode(String data)
  {
	  return Base64.decode(data);
  }

}
