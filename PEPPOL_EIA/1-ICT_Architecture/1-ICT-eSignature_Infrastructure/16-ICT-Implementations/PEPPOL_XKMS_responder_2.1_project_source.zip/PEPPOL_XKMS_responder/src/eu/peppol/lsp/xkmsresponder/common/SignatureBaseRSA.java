/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.common;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.xml.security.algorithms.JCEMapper;
import org.apache.xml.security.algorithms.SignatureAlgorithmSpi;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.signature.XMLSignatureException;


/**
 * SignatureAlgorithmSpy implementation which allows XML security to accessPrivateKey objects.
 *
 * @author mho
 * @author tt
 *
 * 
 */
public abstract class SignatureBaseRSA extends SignatureAlgorithmSpi
{
  /** {@link org.apache.commons.logging} logging facility */
  static Logger log =
        Logger.getLogger(SignatureBaseRSA.class.getName());

  private String uri;

  private String sigAlgoNameForNetKey;


  @Override
  public String engineGetURI()
  {
    return uri;
  }

  /**
   * Signature object for actually signing or verifying, could be a different one each time
   */
  private java.security.Signature signatureAlgorithm = null;

  /**
   * Signature object used for operations with "normal" RSA keys (opposed to NetPrivateKeys)
   */
  private java.security.Signature normalSignatureAlgorithm = null;

  /**
   * Constructor SignatureRSA
   *
   * @throws XMLSignatureException
   */
  protected SignatureBaseRSA(String _uri, String _sigAlgoName) throws XMLSignatureException
  {
    uri = _uri;
    sigAlgoNameForNetKey = _sigAlgoName;
//    String algorithmID = "SHA256withRSA"; //JCEMapper.translateURItoJCEID(this.engineGetURI());
    String algorithmID = JCEMapper.translateURItoJCEID(this.engineGetURI());

    // MOD MHO
    if (log.isLoggable(Level.FINE))
      log.fine("Created SignatureRSA using " + algorithmID);

    try
    {
      normalSignatureAlgorithm = Signature.getInstance(algorithmID);
      signatureAlgorithm = normalSignatureAlgorithm;
    }
    catch (java.security.NoSuchAlgorithmException ex)
    {
      Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
      throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
    }
  }

  @Override
  protected void engineSetParameter(AlgorithmParameterSpec params) throws XMLSignatureException
  {
    try
    {
      this.signatureAlgorithm.setParameter(params);
    }
    catch (InvalidAlgorithmParameterException ex)
    {
      throw new XMLSignatureException("empty", ex);
    }
  }

  @Override
  protected boolean engineVerify(byte[] signature) throws XMLSignatureException
  {
    try
    {
      return this.signatureAlgorithm.verify(signature);
    }
    catch (SignatureException ex)
    {
      throw new XMLSignatureException("empty", ex);
    }
  }

  @Override
  protected void engineInitVerify(Key publicKey) throws XMLSignatureException
  {
    if (!(publicKey instanceof PublicKey))
    {
      String supplied = publicKey.getClass().getName();
      String needed = PublicKey.class.getName();
      Object[] exArgs = { supplied, needed };
      throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
    }

    try
    {
      this.signatureAlgorithm.initVerify((PublicKey) publicKey);
    }
    catch (InvalidKeyException ex)
    {
      throw new XMLSignatureException("empty", ex);
    }
  }

  @Override
  protected byte[] engineSign() throws XMLSignatureException
  {
    try
    {
      return this.signatureAlgorithm.sign();
    }
    catch (SignatureException ex)
    {
      throw new XMLSignatureException("empty", ex);
    }
    finally
    {
      signatureAlgorithm = normalSignatureAlgorithm;
    }
  }

  @Override
  protected void engineInitSign(Key privateKey, SecureRandom secureRandom) throws XMLSignatureException
  {
	  signatureAlgorithm = normalSignatureAlgorithm;
      if (!(privateKey instanceof PrivateKey))
      {
        String supplied = privateKey.getClass().getName();
        String needed = PrivateKey.class.getName();
        Object[] exArgs = { supplied, needed };
        throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
      }

      try
      {
    	  this.signatureAlgorithm.initSign((PrivateKey) privateKey, secureRandom);
      }
      catch (InvalidKeyException ex)
      {
    	  throw new XMLSignatureException("empty", ex);
      }
  }

  @Override
  protected void engineInitSign(Key privateKey) throws XMLSignatureException
  {
	  signatureAlgorithm = normalSignatureAlgorithm;
      if (!(privateKey instanceof PrivateKey))
      {
        String supplied = privateKey.getClass().getName();
        String needed = PrivateKey.class.getName();
        Object[] exArgs = { supplied, needed };
        throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
      }

      try
      {
    	  this.signatureAlgorithm.initSign((PrivateKey) privateKey);
      }
      catch (InvalidKeyException ex)
      {
    	  throw new XMLSignatureException("empty", ex);
      }
  }

  @Override
  protected void engineUpdate(byte[] input) throws XMLSignatureException
  {
    try
    {
      this.signatureAlgorithm.update(input);
    }
    catch (SignatureException ex)
    {
      throw new XMLSignatureException("empty", ex);
    }
  }

  @Override
  protected void engineUpdate(byte input) throws XMLSignatureException
  {
    try
    {
      this.signatureAlgorithm.update(input);
    }
    catch (SignatureException ex)
    {
      throw new XMLSignatureException("empty", ex);
    }
  }

  @Override
  protected void engineUpdate(byte[] buf, int offset, int len) throws XMLSignatureException
  {
    try
    {
      this.signatureAlgorithm.update(buf, offset, len);
    }
    catch (SignatureException ex)
    {
      throw new XMLSignatureException("empty", ex);
    }
  }

  @Override
  protected String engineGetJCEAlgorithmString()
  {
    return this.signatureAlgorithm.getAlgorithm();
  }

  @Override
  protected String engineGetJCEProviderName()
  {
    return this.signatureAlgorithm.getProvider().getName();
  }

  @Override
  protected void engineSetHMACOutputLength(int HMACOutputLength) throws XMLSignatureException
  {
    throw new XMLSignatureException("algorithms.HMACOutputLengthOnlyForHMAC");
  }

  @Override
  protected void engineInitSign(Key signingKey, AlgorithmParameterSpec algorithmParameterSpec)
        throws XMLSignatureException
  {
    throw new XMLSignatureException("algorithms.CannotUseAlgorithmParameterSpecOnRSA");
  }

  /**
   * Class SignatureRSASHA1
   */
  public static class SignatureRSASHA1 extends SignatureBaseRSA
  {
    public SignatureRSASHA1() throws XMLSignatureException
    {
      super(XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA1, "SHA1withRSA");
    }
  }

  /**
   * Class SignatureRSASHA256
   */
  public static class SignatureRSASHA256 extends SignatureBaseRSA
  {
    public SignatureRSASHA256() throws XMLSignatureException
    {
      super(XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA256, "SHA256withRSA");
    }
  }

  /**
   * Class SignatureRSASHA384
   */
  public static class SignatureRSASHA384 extends SignatureBaseRSA
  {
    public SignatureRSASHA384() throws XMLSignatureException
    {
      super(XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA384, "SHA384withRSA");
    }
  }

  /**
   * Class SignatureRSASHA512
   */
  public static class SignatureRSASHA512 extends SignatureBaseRSA
  {
    public SignatureRSASHA512() throws XMLSignatureException
    {
      super(XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA512, "SHA512withRSA");
    }
  }

  /**
   * Class SignatureRSARIPEMD160
   */
  public static class SignatureRSARIPEMD160 extends SignatureBaseRSA
  {
    public SignatureRSARIPEMD160() throws XMLSignatureException
    {
      super(XMLSignature.ALGO_ID_SIGNATURE_RSA_RIPEMD160, "RIPEMD160withRSA");
    }
  }

  /**
   * Choose the appropriate Signature class
   * @throws XMLSignatureException if there is no such algorithm
   */
  private void initSignatureAlgorithmForNetKey() throws XMLSignatureException
  {
    try
    {
      this.signatureAlgorithm = Signature.getInstance(sigAlgoNameForNetKey, "NET");
    }
    catch (Exception ex)
    {
      Object[] exArgs = { sigAlgoNameForNetKey, ex.getLocalizedMessage() };
      throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
    }
  }

}
