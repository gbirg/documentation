/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.xml.security.Init;
import org.xml.sax.InputSource;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ProxyDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.SignatureTokenDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodCrlDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodLdapDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodOcspDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodXKMSDto;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Certificate;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Config;
import eu.peppol.lsp.xkmsresponder.importexport.schema.TACertificate;
import eu.peppol.lsp.xkmsresponder.importexport.schema.TACertificates;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValMethod;
import eu.peppol.lsp.xkmsresponder.requestcontroller.MessageExtensionHandler;
import eu.peppol.lsp.xkmsresponder.requestcontroller.XKMSSignature;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.crl.CRLDownloader;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.crl.CRLDownloaderTimer;
import eu.peppol.lsp.xkmsresponder.webadmin.ConfigData;

/**
 * This class represents the root configuration object. It contains all references
 * to the required objects like issuers, trusted anchor certificates or proxy configuration
 * and has static access methods for those objects.
 * @author nagel
 * @author buengener
 * 
*/
public class Configuration implements Serializable
{

  private static final long serialVersionUID = 3645896339287028076L;

  private static final Logger LOG = Logger.getLogger(Configuration.class.getName());

  private static Configuration instance = new Configuration();

  private final Map<String, IssuerDto> issuerDtoMap = new TreeMap<String, IssuerDto>();

  private static Hashtable<String, IssuerDto> pprsIssuer;

  private final Map<String, CertificateDto[]> issuerCertificatesMap = new Hashtable<String, CertificateDto[]>();

  // fields for TrustedAnchorListMb
  private Map<String, CertificateDto> trustedAnchorMap = new TreeMap<String, CertificateDto>(); // of key=Fingerprint,value=TrustedAnchorDto

  // fields for PropertiesMb
  private ProxyDto proxyDto = new ProxyDto();

  private SignatureTokenDto signatureTokenDto = new SignatureTokenDto();

  public static String CONF_DIR = System.getProperty("peppol.xkmsresponder.configdir", System.getProperty("user.home") + "/peppol") + "/";

  public static String CONF_FILENAME = "configuration.io";

  public static String service;

  public static Date configDate;

  public static boolean acceptTAmessagesOnly = Boolean.parseBoolean(System.getProperty("peppol.xkmsresponder.acceptTAmessagesOnly", "true"));

  // @todo: make configurable / see http timeout
  public static final long VALIDATION_TIMEOUT = 60000;

  public static Timer crlDownloadTimer, pprsDownloadTimer;

  public static void initialize()
  {
	  try
	  {
		  initializeEnvironment();
		  File configFile = new File(CONF_DIR + CONF_FILENAME);
		  if (configFile.exists())
		  {
			  ObjectInputStream ois = new ObjectInputStream(new FileInputStream(configFile));
			  instance = (Configuration)ois.readObject();
			  configDate = new Date(configFile.lastModified());
		  }
		  else
		  {
			  LOG.severe("No configuration found !");
			  instance = new Configuration();
			  File f = new File(CONF_DIR);
			  f.mkdirs();
			  if (!f.exists())
				  throw new IOException("Failed to create config dircetory " + CONF_DIR);
		  }

		  Configuration.storeConfiguration();
		  if (System.getProperty("peppol.xkmsresponder.eu_tsl.url") != null)
			  MessageExtensionHandler.getTSLs();
		  MessageExtensionHandler.loadTSLs();

	      // intialize CRL Downloader
	      for (ValMethodCrlDto vmcrldto :  getActiveValMethodCrlDtos())
	    	  CRLDownloader.loadCRL(vmcrldto.getName());

	      XKMSSignature.reloadSignatureKey(getSignatureTokenDto());

	      crlDownloadTimer = new Timer(true);
	      crlDownloadTimer.schedule(new CRLDownloaderTimer(), 3000, 60000);
	      LOG.fine("CRLDownloaderTimer started");

	      // initialize periodical PPRS download
	      pprsDownloadTimer = new Timer(true);
	      pprsDownloadTimer.schedule(new TimerTask()
		  {
			@Override
			public void run()
			{
				LOG.fine("Start PPRS download");
				pprsIssuer = MessageExtensionHandler.loadPPRS_TSL();
				if (LOG.isLoggable(Level.FINE))
					LOG.fine("PPRS loaded: " + pprsIssuer.toString());
			}
		  }, 0, Long.parseLong(System.getProperty("peppol.xkmsresponder.pprs.downloadinterval",
				  "360")) * 60000); // Update PPRS every 6h by default

	  }
	  catch (Throwable t)
	  {
		  LOG.log(Level.SEVERE, "Failed to initialize XKMS responder.", t);
	  }
  }

  public static void initializeEnvironment()
  {
	  System.setProperty("org.apache.xml.security.resource.config", "/eu/peppol/lsp/xkmsresponder/configuration/config.xml");
	  Init.init();
	  LOG.info("initXMLSecurity() initializing XMLSecurity was done");
  }

  public Configuration()
  {
    // nothing to do
  }

  public static IssuerDto getIssuerDtoPPRS(String countryCode)
  {
	  return pprsIssuer.get(countryCode);
  }

  public static boolean containsIssuer(String inpIssuerName)
  {
	  return instance.issuerDtoMap.containsKey(inpIssuerName);
  }

  public static IssuerDto removeIssuer(String inpIssuerName)
  {
	String[] names = getIssuerDto(inpIssuerName).certificateMap.keySet().toArray(new String[0]);
	for (String certName : names)
		removeIssuerCertificateDto(inpIssuerName, certName);
	return instance.issuerDtoMap.remove(inpIssuerName);
  }

  public static void clearIssuerList()
  {
	  instance.issuerDtoMap.clear();
	  instance.issuerCertificatesMap.clear();
  }

  public static Collection<IssuerDto> getIssuerDtos()
  {
      return instance.issuerDtoMap.values();
  }

  public static Set<String> getIssuerKeys()
  {
	  return instance.issuerDtoMap.keySet();
  }

  public static void putIssuerDto(IssuerDto inpIssuerDto)
  {
	  instance.issuerDtoMap.put(inpIssuerDto.getName(), inpIssuerDto);
  }

  public static IssuerDto getIssuerDto(String inpIssuerKey)
  {
	  return instance.issuerDtoMap.get(inpIssuerKey);
  }

  public static Collection<ValMethodCrlDto> getActiveValMethodCrlDtos()
  {
	  Collection<ValMethodCrlDto> ret = new ArrayList<ValMethodCrlDto>();
	  for (IssuerDto issdto : instance.issuerDtoMap.values())
	  {
		  if (issdto.getEnabled() && issdto.getValMethod().containsCRL())
			  ret.add(issdto.getValMethodCrlDto());
	  }
	  return ret;
  }

  public static CertificateDto getIssuerCertificateDto(String inpIssuerName, String inpFriendlyName)
  {
      return instance.issuerDtoMap.get(inpIssuerName).certificateMap.get (inpFriendlyName);
  }

  public static void putIssuerCertificateDto(String inpIssuerName,
                                                       CertificateDto inpCertificateDto)
  {
	  CertificateDto[] cdtos = instance.issuerCertificatesMap.get(inpCertificateDto.getSubjectDN());
	  CertificateDto[] cdtos_new;

	  if (cdtos == null)
		  cdtos_new = new CertificateDto[1];
	  else
	  {
		  cdtos_new = new CertificateDto[cdtos.length + 1];

		  for (int i = 0; i < cdtos.length; i++)
		  {
			  if (cdtos[i].getX509Certificate().equals(inpCertificateDto.getX509Certificate()))
				  throw new IllegalArgumentException("Certificate " + cdtos[i].getSubjectDN() + " already present in configuration.");
			  cdtos_new[i] = cdtos[i];
		  }
	  }

	  cdtos_new[cdtos_new.length-1] = inpCertificateDto;
	  instance.issuerCertificatesMap.put(inpCertificateDto.getSubjectDN(), cdtos_new);

	  instance.issuerDtoMap.get(inpIssuerName).certificateMap.put(inpCertificateDto.getFriendlyName(), inpCertificateDto);
  }

  /**
   * Returns the certificates of the given issuer
   *
   * @param inpIssuerName Friendly name of the issuer
   * @return a map of FriendlyName and CertificateDtos
   */
  public static Map<String, CertificateDto> getIssuerCertificateDtos(String inpIssuerName)
  {
      return instance.issuerDtoMap.get(inpIssuerName).certificateMap;
  }

  /**
   * Checks if a given certificate is a configured issuer certificate.
   *
   * @param inpCertificateDto
   * @return true, if the issuer certificate is found, otherwise false
   */
  public static boolean containsIssuerCertificate(X509Certificate inpCertificate)
  {
	  CertificateDto[] cdtos = instance.issuerCertificatesMap.get(ResponderHelper.getSubjectDN(inpCertificate));
	  if (cdtos == null)
		  return false;
	  for (int i = 0; i < cdtos.length; i++)
		  if (cdtos[i].getX509Certificate().equals(inpCertificate))
			  return true;
	  return false;
  }

  public static Collection<CertificateDto> getIssuerCertificateBySubjectDNAndSubjectKeyIdentifier(String subjectDN, String subjectKeyId)
  {
	  Collection<CertificateDto> ret = new ArrayList<CertificateDto>();

	  CertificateDto[] cdtos = instance.issuerCertificatesMap.get(subjectDN);

	  if (cdtos != null)
	  {
		  for (int i = 0; i < cdtos.length; i++)
		  {
			  if (instance.issuerDtoMap.get(cdtos[i].getIssuerName()).getEnabled())
			  {
				  if (cdtos[i].getSubjectKeyId().equals(subjectKeyId))
				  {
					  ret.clear();
					  ret.add(cdtos[i]);
					  return ret;
				  }
				  else if (cdtos[i].getSubjectKeyId().length() == 0 || subjectKeyId.length() == 0)
					  ret.add(cdtos[i]);
			  }
		  }
	  }

	  return ret;
  }

  public static CertificateDto getIssuerCertificateByUserCertificate(X509Certificate userCert)
  {
      String issuerDN = ResponderHelper.getIssuerDN(userCert);
      String issuerKeyIdentifier = ResponderHelper.getAuthorityKeyIdentifier(userCert);
      CertificateDto ret = null;

      Collection<CertificateDto> cdtos = getIssuerCertificateBySubjectDNAndSubjectKeyIdentifier(issuerDN, issuerKeyIdentifier);

      for (CertificateDto cdto : cdtos)
      {
    	  // If the key identifier matches, return immediately
    	  if (issuerKeyIdentifier.length() > 0
    			  && cdto.getSubjectKeyId().equals(issuerKeyIdentifier))
    		  return cdto;
    	  try
    	  {
    		  userCert.verify(cdto.getX509Certificate().getPublicKey());
    		  return cdto;
    	  }
    	  catch (Exception e)
    	  {
    		  LOG.fine("Found issuer certificate with matching subjectDN but verify failed.");
    	  }
      }

    return null;
  }

  public static IssuerDto getIssuerDtoByUserCertificate(X509Certificate userCert)
  {
	  CertificateDto cdto = getIssuerCertificateByUserCertificate(userCert);
	  if (cdto == null)
		  return null;
	  return getIssuerDto(cdto.getIssuerName());
  }

  public static CertificateDto removeIssuerCertificateDto(String inpIssuerName, String inpFriendlyName)
  {
	  IssuerDto idto = instance.issuerDtoMap.get(inpIssuerName);

	  CertificateDto cdto = idto.certificateMap.get(inpFriendlyName);
	  CertificateDto[] cdtos = instance.issuerCertificatesMap.get(cdto.getSubjectDN());
	  if (cdtos.length > 1)
	  {
		  CertificateDto[] cdtos_new = new CertificateDto[cdtos.length - 1];
		  for (int i = 0, j = 0; i < cdtos.length; i++)
			  if (!cdtos[i].equals(cdto))
				  cdtos_new[j++] = cdtos[i];
		  instance.issuerCertificatesMap.put(cdto.getSubjectDN(), cdtos_new);
	  }
	  else
		  instance.issuerCertificatesMap.remove(cdto.getSubjectDN());

	  return idto.certificateMap.remove(inpFriendlyName);
  }

  public static void dumpIssuer()
  {
	  LOG.fine("dumpIssuer() List of IssuerKeys with size " + instance.issuerDtoMap.size());
      for (String tmpIssuerName : instance.issuerDtoMap.keySet())
      {
        LOG.fine("dumpIssuer() IssuerKey.Name= " + tmpIssuerName + ";");
      }
  }

  // methods for TrustedAnchorList
  public static CertificateDto putTrustedAnchor(String inpFingerprint, CertificateDto inpTrustedAnchorDto)
  {
	  return instance.trustedAnchorMap.put(inpFingerprint, inpTrustedAnchorDto);
  }

  public static Map<String, CertificateDto> getTrustedAnchorMap()
  {
    synchronized (instance.trustedAnchorMap)
    {
      return instance.trustedAnchorMap;
    }
  }

  public static CertificateDto getTrustedAnchor(String inpFingerprint)
  {
    synchronized (instance.trustedAnchorMap)
    {
      return instance.trustedAnchorMap.get(inpFingerprint);
    }
  }

  public static boolean containsKeyTrustedAnchor(String inpFingerprint)
  {
    synchronized (instance.trustedAnchorMap)
    {
      return instance.trustedAnchorMap.containsKey(inpFingerprint);
    }
  }

  public static CertificateDto removeTrustedAnchor(String inpFingerprint)
  {
    synchronized (instance.trustedAnchorMap)
    {
      return instance.trustedAnchorMap.remove(inpFingerprint);
    }
  }

  public static Collection<CertificateDto> valuesTrustedAnchorList()
  {
    synchronized (instance.trustedAnchorMap)
    {
      return instance.trustedAnchorMap.values();
    }
  }

  public static void clearTrustedAnchorList()
  {
    synchronized (instance.trustedAnchorMap)
    {
      instance.trustedAnchorMap.clear();
    }
  }

  public static ProxyDto getProxyDto()
  {
	  return instance.proxyDto;
  }

  public static SignatureTokenDto getSignatureTokenDto()
  {
	  return instance.signatureTokenDto;
  }

  public static void clearProperties()
  {
    synchronized (instance.proxyDto)
    {
      instance.proxyDto = new ProxyDto();
    }

    synchronized (instance.signatureTokenDto)
    {
      instance.signatureTokenDto = new SignatureTokenDto();
    }
  }

	public static synchronized void loadConfig(byte[] config) throws Exception
	{
		loadConfig(new ByteArrayInputStream(config));
	}

	public static synchronized void loadConfig(InputStream in) throws Exception
	{
	      Config myData = null;

	      InputSource tmpInputSource = new InputSource(in);
	      myData = new ParseImportExportConfig().parseDefaultConfig(tmpInputSource);

	      clearTrustedAnchorList();

	      TACertificates tmpTACertificates = myData.getTACertificates();

	      if (tmpTACertificates != null)
	      {
	    	  if (tmpTACertificates.getTACertificate() != null)
	    	  {
		          for (TACertificate tmpTACertificate : tmpTACertificates.getTACertificate())
		          {
		        	  String tmpUser = tmpTACertificate.getInsertUser();
		        	  X509Certificate tmpCert = ResponderHelper.createCertificate(tmpTACertificate.getX509Certificate());
		        	  CertificateDto tmpTrustedAnchorDto =
		        		  new CertificateDto("", tmpCert, ConfigData.parseCN(tmpCert), false);
		        	  putTrustedAnchor(ResponderHelper.getFingerprint(tmpCert), tmpTrustedAnchorDto);
		          }
	    	  }
	      }

	      clearIssuerList();

	      List<eu.peppol.lsp.xkmsresponder.importexport.schema.Issuer> tmpIssuers = myData.getIssuers().getIssuer();


	      for (eu.peppol.lsp.xkmsresponder.importexport.schema.Issuer tmpIssuer : tmpIssuers)
	      {
	    	  String tmpIssuerName = tmpIssuer.getName().trim();
	    	  IssuerDto tmpIssuerDto = new IssuerDto(tmpIssuerName);
	    	  tmpIssuerDto.setAlgPolicyIdentifier(tmpIssuer.getAlgPolicyIdentifier());
	    	  tmpIssuerDto.setCSPAssurance(tmpIssuer.getEIDQuality().getCSPAssurance().getType());
	    	  tmpIssuerDto.setEnabled(tmpIssuer.isEnabled());
	    	  tmpIssuerDto.setQuality(tmpIssuer.getEIDQuality().getCertificateQuality().getType());
	    	  tmpIssuerDto.setTSLIdentifier(tmpIssuer.getTSLIdentifier());

	    	  if (tmpIssuer.getValidateModel() != null)
	    		  tmpIssuerDto.setValidateModel(tmpIssuer.getValidateModel().getType().toUpperCase());
	    	  else
	    		  tmpIssuerDto.setValidateModel(ConfigData.VAL_MODEL[0]);

	    	  ValMethod vm = tmpIssuer.getValMethod();
	    	  if (vm.getValMethodNONE() != null)
	    		  tmpIssuerDto.setValMethod(ValMethodType.NONE);
	    	  if (vm.getValMethodOCSP() != null)
	    	  {
	    		  tmpIssuerDto.setValMethod(ValMethodType.OCSP);
	    		  ValMethodOcspDto ocsp = new ValMethodOcspDto(tmpIssuerName);
	    		  ocsp.setCacheTimeout(vm.getValMethodOCSP().getCacheTimeout());
	    		  ocsp.setCheckRespSignature(vm.getValMethodOCSP().isCheckRespSignature());
	    		  ocsp.setSubType(vm.getValMethodOCSP().getSubType());
	    		  ocsp.setUrl(vm.getValMethodOCSP().getUrl());
	    		  ocsp.setUseCache(vm.getValMethodOCSP().isUseCache());
	    		  tmpIssuerDto.setValMethodOcspDto(ocsp);
	    	  }

	    	  if (vm.getValMethodCRL() != null)
	    	  {
	    		  if (vm.getValMethodLDAP() != null)
	    			  tmpIssuerDto.setValMethod(ValMethodType.CRL_LDAP);
	    		  else
	    			  tmpIssuerDto.setValMethod(ValMethodType.CRL);
	    		  ValMethodCrlDto crl = new ValMethodCrlDto(tmpIssuerName);
	    		  crl.setAttribute(vm.getValMethodCRL().getAttribute());
	    		  crl.setEscalation(vm.getValMethodCRL().getEscalation());
	    		  crl.setIgnoreNextUpdate(vm.getValMethodCRL().isIgnoreNextUpdate());
	    		  crl.setInterval(vm.getValMethodCRL().getIntervall());
	    		  crl.setSearchbase(vm.getValMethodCRL().getSearchbase());
	    		  crl.setSubType(vm.getValMethodCRL().getProtocol());
	    		  crl.setUrl(vm.getValMethodCRL().getUrl());
	    		  tmpIssuerDto.setValMethodCrlDto(crl);
	    	  }

	    	  if (vm.getValMethodLDAP() != null)
	    	  {
	    		  if (vm.getValMethodCRL() == null)
	    			  tmpIssuerDto.setValMethod(ValMethodType.LDAP);
	    		  ValMethodLdapDto ldap = new ValMethodLdapDto(tmpIssuerName);
	    		  ldap.setAttribute(vm.getValMethodLDAP().getAttribute());
	    		  ldap.setAuthenticationCredentials(vm.getValMethodLDAP().getAuthenticationCredentials());
	    		  ldap.setAuthenticationPrincipal(vm.getValMethodLDAP().getAuthenticationPrincipal());
	    		  ldap.setAuthenticationType(vm.getValMethodLDAP().getAuthenticationType());
	    		  ldap.setFilter(vm.getValMethodLDAP().getFilter());
	    		  ldap.setSearchbase(vm.getValMethodLDAP().getSearchbase());
	    		  ldap.setUrl(vm.getValMethodLDAP().getUrl());
	    		  tmpIssuerDto.setValMethodLdapDto(ldap);
	    	  }

	    	  if (vm.getValMethodXKMS() != null)
	    	  {
	    		  tmpIssuerDto.setValMethod(ValMethodType.XKMS);
	    		  ValMethodXKMSDto xkms = new ValMethodXKMSDto(tmpIssuerName);
	    		  xkms.setSigCertificate(vm.getValMethodXKMS().getSigCertificate());
	    		  xkms.setUrl(vm.getValMethodXKMS().getUrl());
	    		  tmpIssuerDto.setValMethodXkmsDto(xkms);
	    	  }

	    	  if (containsIssuer(tmpIssuerName))
	    		  tmpIssuerDto.setEnabled(getIssuerDto(tmpIssuerName).getEnabled());

	    	  putIssuerDto(tmpIssuerDto);

	    	  List<Certificate> tmpCertificates = tmpIssuer.getCertificates().getCertificate();

	    	  for (Certificate tmpCertificate : tmpCertificates)
	    	  {
	    		  String tmpFriendlyName = tmpCertificate.getFriendlyName();
	    		  byte[] tmpCertBytes = tmpCertificate.getX509Certificate();
	    		  Boolean tmpCheckOnline = Boolean.valueOf(tmpCertificate.isCheckOnline());

	    		  CertificateDto inpCertificateDto = new CertificateDto(tmpIssuerName,
	    				  ResponderHelper.createCertificate(tmpCertBytes), tmpFriendlyName, tmpCheckOnline);
	    		  putIssuerCertificateDto(tmpIssuerName, inpCertificateDto);
	    	  }
	      }

	      clearProperties();
	      if (myData.getProxy() != null)
	      {
		      getProxyDto().setNonProxyHosts(myData.getProxy().getNonProxyHosts());
		      getProxyDto().setPassword(myData.getProxy().getPassword());
		      getProxyDto().setProxyHost(myData.getProxy().getProxyHost());
		      getProxyDto().setProxyPort(myData.getProxy().getProxyPort());
		      getProxyDto().setTimeout(myData.getProxy().getTimeout());
		      getProxyDto().setUserName(myData.getProxy().getUsername());
	      }
	      if (myData.getSignature() != null)
	      {
		      getSignatureTokenDto().setAlias(myData.getSignature().getAlias());
		      getSignatureTokenDto().setData(myData.getSignature().getKeystore());
		      getSignatureTokenDto().setPin(myData.getSignature().getPin());
	      }

	      // CRL Downloader initialisieren
	      for (ValMethodCrlDto vmcrldto :  getActiveValMethodCrlDtos())
	    	  CRLDownloader.loadCRL(vmcrldto.getName());

	      XKMSSignature.reloadSignatureKey(getSignatureTokenDto());

	      if (crlDownloadTimer != null)
	    	  crlDownloadTimer.cancel();
	      crlDownloadTimer = new Timer(true);
	      crlDownloadTimer.schedule(new CRLDownloaderTimer(), 15000, 60000);

	}

	public static synchronized void storeConfiguration() throws Exception
	{
		FileOutputStream fos = new FileOutputStream(CONF_DIR + CONF_FILENAME);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(instance);
		oos.close();
    	configDate = new Date();
    	configSSL();
	}

	// Accept only TA certs as SSL server certs; Disable host name verification
	private static void configSSL() throws NoSuchAlgorithmException, KeyManagementException
	{
		SSLContext sc = SSLContext.getInstance("SSL");
		TrustManager[] trustTACerts =
			new TrustManager[]
			                 {	new X509TrustManager()
			                 	{
			                	 	public java.security.cert.X509Certificate[] getAcceptedIssuers()
			                	 	{
			                	 		return null;
			                	 	}
			                	 	public void checkClientTrusted(
			                	 			java.security.cert.X509Certificate[] certs, String authType)
			                	 	{
			                	 	}
			                	 	public void checkServerTrusted(
			                	 			java.security.cert.X509Certificate[] certs, String authType) throws CertificateException
			                	 	{
			                	 		if (acceptTAmessagesOnly)
			                	 		{
			                		    	boolean trustedCertFound = false;
				                	 		for (int i = 0; i < certs.length; i++)
				                	 		{
				                	 			if (Configuration.getTrustedAnchor(ResponderHelper.getFingerprint(certs[i])) != null)
			                		    		{
			                		    			trustedCertFound = true;
			                		    			break;
			                		    		}
				                	 		}
			                		    	if (!trustedCertFound)
			                		    	{
			                		    		if (LOG.isLoggable(Level.FINE))
			                		    		{
			                		    			LOG.severe("Num of certs "+ certs.length);
			                		    			for (int i = 0; i < certs.length; i++)
			                		    				LOG.severe("SSL cert:\n" + certs[i] + "\n" + ResponderHelper.base64encode(certs[i].getEncoded()));
			                		    		}
			                		    		throw new CertificateException("No signature certificate listed in trusted anchor configuration found in SSL server certificate chain.");
			                		    	}
			                	 		}
			                	 	}
			                 	}
			                 };

	      sc.init(null, trustTACerts, null);
	      HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	      HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier()
	      {
	    	  public boolean verify(String arg0, SSLSession arg1)
	    	  {
	    		  return true;
	    	  }
	      });
	}
}
