/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration;

import java.io.ByteArrayOutputStream;
import java.io.CharArrayReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeFactory;

import org.xml.sax.InputSource;

import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ProxyDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.SignatureTokenDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodCrlDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodLdapDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodOcspDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodXKMSDto;
import eu.peppol.lsp.xkmsresponder.importexport.schema.CSPAssurance;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Certificate;
import eu.peppol.lsp.xkmsresponder.importexport.schema.CertificateQuality;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Certificates;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Config;
import eu.peppol.lsp.xkmsresponder.importexport.schema.EIDQualityType;
import eu.peppol.lsp.xkmsresponder.importexport.schema.EnabledIssuers;
import eu.peppol.lsp.xkmsresponder.importexport.schema.FileType;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Issuer;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Issuers;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Proxy;
import eu.peppol.lsp.xkmsresponder.importexport.schema.Signature;
import eu.peppol.lsp.xkmsresponder.importexport.schema.TACertificate;
import eu.peppol.lsp.xkmsresponder.importexport.schema.TACertificates;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValMethod;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValMethodCRL;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValMethodLDAP;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValMethodNONE;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValMethodOCSP;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValMethodXKMS;
import eu.peppol.lsp.xkmsresponder.importexport.schema.ValidateModel;
import eu.peppol.lsp.xkmsresponder.xkms.NamespacePrefixMapperImpl;


/**
 * Utility class for import and export of configurations.
 * @author buengener
 *
 * 
*/
public class ImportExportHandler
{
  private static final Logger LOG = Logger.getLogger(ImportExportHandler.class.getName());

  private static JAXBContext jaxbContext;

  private static boolean init = false;

  private static final String certificate =
        "MIIFpDCCBIygAwIBAgIQQRxcc0IU26ui9yimUPiRBzANBgkqhkiG9w0"
              + "BAQUFADCBtDELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZWZXJpU2lnbiBUcn"
              + "VzdCBOZXR3b3JrMTswOQYDVQQLEzJUZXJtcyBvZiB1c2UgYXQgaHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL3JwYSAoYy"
              + "kwNDEuMCwGA1UEAxMlVmVyaVNpZ24gQ2xhc3MgMyBDb2RlIFNpZ25pbmcgMjAwNCBDQTAeFw0wNjA4MjkwMDAwMDBaFw"
              + "0wOTA5MTgyMzU5NTlaMIHjMQswCQYDVQQGEwJERTEPMA0GA1UECBMGQnJlbWVuMQ8wDQYDVQQHEwZCcmVtZW4xLTArBg"
              + "NVBAoUJGJyZW1lbiBvbmxpbmUgc2VydmljZXMgR21iSCAmIENvLiBLRzE1MDMGA1UECxMsRGlnaXRhbCBJRCBDbGFzcy"
              + "AzIC0gTmV0c2NhcGUgT2JqZWN0IFNpZ25pbmcxHTAbBgNVBAsUFFNvZnR3YXJlIERldmVsb3BtZW50MS0wKwYDVQQDFC"
              + "RicmVtZW4gb25saW5lIHNlcnZpY2VzIEdtYkggJiBDby4gS0cwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQ"
              + "C/CrvDiAoTcatk48wIQskRsfWpNEV3wU0sWVNdoLxJ1Jfj4jAjYVgSqh9M1prL79WvxWJYRLC3+ltR/qICzg60y8lpk4"
              + "ZPnWAo+6erKJD89TVX76HUKStS/oC0EH6pf7S0er4lfIb8lobpTbzZaZlnGN3FPl2HgMaeLAIYT7Uwu7XHlfnuWLqcXU"
              + "A74ozNZ/n2PrzcL/6/ngiSN9d7SsrcdqJD55pxWw+gDDqyH9rKMUMRR6yYGYIv4CK4TJZh2EG02yY3XKiWbnKJZuiZFu"
              + "sVgqgEoCY9OmPzR5EieKLFseDxDdkqQZKlQoBGKiUpS2ulWlehT0bqIcsS/FZoyFNPAgMBAAGjggF/MIIBezAJBgNVHR"
              + "MEAjAAMA4GA1UdDwEB/wQEAwIHgDBABgNVHR8EOTA3MDWgM6Axhi9odHRwOi8vQ1NDMy0yMDA0LWNybC52ZXJpc2lnbi"
              + "5jb20vQ1NDMy0yMDA0LmNybDBEBgNVHSAEPTA7MDkGC2CGSAGG+EUBBxcDMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3"
              + "d3LnZlcmlzaWduLmNvbS9ycGEwEwYDVR0lBAwwCgYIKwYBBQUHAwMwdQYIKwYBBQUHAQEEaTBnMCQGCCsGAQUFBzABhh"
              + "hodHRwOi8vb2NzcC52ZXJpc2lnbi5jb20wPwYIKwYBBQUHMAKGM2h0dHA6Ly9DU0MzLTIwMDQtYWlhLnZlcmlzaWduLm"
              + "NvbS9DU0MzLTIwMDQtYWlhLmNlcjAfBgNVHSMEGDAWgBQI9VHo+/49PWQ2fGjPW3io37nFNzARBglghkgBhvhCAQEEBA"
              + "MCBBAwFgYKKwYBBAGCNwIBGwQIMAYBAQABAf8wDQYJKoZIhvcNAQEFBQADggEBAHBaw9oeccpspgAiPZDLOVByhMxAs0"
              + "jUBEf1v13BKMtCRFChm/fcl7X0j/O/bWagrycMntnTAW066iC1TWyrnIWEK8LMaXGWj8NgkzXicEQ2w2b39RXgHDjvNb"
              + "uep/QmJwxwBC/Ui+7fQwZFX5uSvQW3rp2zECXhYXb7POBrVqye1hWKubdf6nhpq6rmehJMyoGhQrJ1Y0yACBaWlICIzE"
              + "eNjMjzZgNudWeru9CcaH5vePQsR9h6GxJFGaajI0qb8bDRCQKTeT+YcFRaWMQIE+SIrQce300pc9QXUdzs9VkI1zqcMi"
              + "5Tiown3azWpJzWDz8Vosr+VIh60wfbUihQwgo=";

  /**
   * Export all possible parts of the config
   *
   * @throws Exception
   * @return byte[] XML representation of the config file.
   */
  public static byte[] exportConfig() throws Exception
  {
    if (!init)
    {
      init();
    }

    Config config = new Config();
    Issuers tmpIssuers = new Issuers();

    Collection<IssuerDto> tmpIssuerDtos = Configuration.getIssuerDtos();

    EnabledIssuers tmpEnabledIssuers = new EnabledIssuers();

    for (IssuerDto tmpIssuerDto : tmpIssuerDtos)
    {
    	Issuer tmpIssuerImpl = new Issuer();
    	tmpIssuerImpl.setName(tmpIssuerDto.getName());
    	tmpIssuerImpl.setEnabled(Boolean.valueOf(tmpIssuerDto.getEnabled()));
    	tmpIssuerImpl.setValMethod(getValMethod(tmpIssuerDto));
    	tmpIssuerImpl.setTSLIdentifier(tmpIssuerDto.getTSLIdentifier());
    	tmpIssuerImpl.setAlgPolicyIdentifier(tmpIssuerDto.getAlgPolicyIdentifier());
    	ValidateModel vm = new ValidateModel();
    	vm.setType(tmpIssuerDto.getValidateModel());
    	tmpIssuerImpl.setValidateModel(vm);

          //          CertQuality tmpCertQuality = new CertQuality();
    	EIDQualityType tmpEIDQuality = new EIDQualityType();
    	CertificateQuality tmpCertificateQuality = new CertificateQuality();
    	tmpCertificateQuality.setType(tmpIssuerDto.getQuality());
    	CSPAssurance tmpCSPAssurance = new CSPAssurance();
    	tmpCSPAssurance.setType(tmpIssuerDto.getCSPAssurance());
    	tmpEIDQuality.setCertificateQuality(tmpCertificateQuality);
    	tmpEIDQuality.setCSPAssurance(tmpCSPAssurance);
    	tmpIssuerImpl.setEIDQuality(tmpEIDQuality);
    	Map<String, CertificateDto> tmpCertificateDtosMap =
    		Configuration.getIssuerCertificateDtos(tmpIssuerDto.getName());
    	tmpIssuerImpl.setCertificates(getCertificates(tmpCertificateDtosMap));
    	tmpIssuers.getIssuer().add(tmpIssuerImpl);
    }

    Collection<CertificateDto> tmpTrustedAnchorDtos = Configuration.valuesTrustedAnchorList();
    TACertificates tmpTACertificates = new TACertificates();
    List<TACertificate> tmpTACertificatesList = tmpTACertificates.getTACertificate();

    for (CertificateDto tmpTrustedAnchorDto : tmpTrustedAnchorDtos)
    {
    	TACertificate tmpTACertificate = new TACertificate();
        GregorianCalendar tmpGCal = new GregorianCalendar();
        tmpGCal.setTime(new Date());

        tmpTACertificate.setInsertDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(tmpGCal));
        tmpTACertificate.setInsertUser("admin");
        tmpTACertificate.setX509Certificate(tmpTrustedAnchorDto.getX509Certificate().getEncoded());
        tmpTACertificatesList.add(tmpTACertificate);
    }

    FileType tmpFile = new FileType();
    tmpFile.setType("peppol");
    config.setName("PEPPOL " + DateFormat.getDateTimeInstance().format(new Date()));
    config.setFileType(tmpFile);
    config.setIssuers(tmpIssuers);
    config.setEnabledIssuers(tmpEnabledIssuers);
    config.setTACertificates(tmpTACertificates);
    config.setProxy(getProxy());
    config.setSignature(getSignature());

    ByteArrayOutputStream outbefore = new ByteArrayOutputStream();

    Marshaller m = jaxbContext.createMarshaller();
    m.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapperImpl());
    m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
    m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
    m.marshal(config, outbefore);
    outbefore.close();
    return outbefore.toByteArray();
  }

  public static InputSource buildInputSource(String inpConfig) throws UnsupportedEncodingException
  {
    Reader tmpReader = new CharArrayReader(inpConfig.toCharArray());
    InputSource tmpInputSource = new InputSource(tmpReader);
    return tmpInputSource;
  }

  private static ValMethod getValMethod(IssuerDto inpIssuer) throws Exception
  {
    ValMethod tmpValType = new ValMethod();
    boolean tmpValMethodValid = false;

    if (inpIssuer.getValMethod().containsOCSP())
    {
      ValMethodOcspDto tmpDto = inpIssuer.getValMethodOcspDto();
      tmpValType.setValMethodOCSP(getValMethodOCSP(tmpDto));
      tmpValMethodValid = true;
    }
    if (inpIssuer.getValMethod().containsLDAP())
    {
      ValMethodLdapDto tmpDto = inpIssuer.getValMethodLdapDto();
      tmpValType.setValMethodLDAP(getValMethodLDAP(tmpDto));
      tmpValMethodValid = true;
    }
    if (inpIssuer.getValMethod().containsCRL())
    {
      ValMethodCrlDto tmpDto = inpIssuer.getValMethodCrlDto();
      tmpValType.setValMethodCRL(getValMethodCRL(tmpDto));
      tmpValMethodValid = true;
    }
    if (inpIssuer.getValMethod().containsXKMS())
    {
      LOG.fine("Found a Issuer wich contains XKMS");
      ValMethodXKMSDto tmpDto = inpIssuer.getValMethodXkmsDto();
      tmpValType.setValMethodXKMS(getValMethodXKMS(tmpDto));
      tmpValMethodValid = true;
    }

    if (inpIssuer.getValMethod().isNONE())
    {
      ValMethodNONE tmpNone = new ValMethodNONE();
      tmpNone.setName("nochecksystem");
      tmpValType.setValMethodNONE(tmpNone);
      tmpValMethodValid = true;
    }

    if (tmpValMethodValid)
    {
      return tmpValType;
    }
    throw new Exception("ValMethod has a invalid value");
  }

  private static ValMethodOCSP getValMethodOCSP(ValMethodOcspDto inpDto)
  {
    ValMethodOCSP tmpType = new ValMethodOCSP();
    tmpType.setUrl(inpDto.getUrl());
    tmpType.setUseCache(Boolean.valueOf(inpDto.getUseCache()));
    tmpType.setCacheTimeout(inpDto.getCacheTimeout());
    tmpType.setCheckRespSignature(inpDto.getCheckRespSignature().booleanValue());
    tmpType.setSubType(inpDto.getSubType());

    return tmpType;
  }

  private static ValMethodXKMS getValMethodXKMS(ValMethodXKMSDto inpDto)
  {
    ValMethodXKMS tmpType = new ValMethodXKMS();
    tmpType.setUrl(inpDto.getUrl());
    tmpType.setSigCertificate(inpDto.getSigCertificate());
    return tmpType;
  }

  private static ValMethodLDAP getValMethodLDAP(ValMethodLdapDto inpDto)
  {
    ValMethodLDAP tmpType = new ValMethodLDAP();
    tmpType.setUrl(inpDto.getUrl());
    tmpType.setSearchbase(inpDto.getSearchbase());
    tmpType.setFilter(inpDto.getFilter());
    tmpType.setAttribute(inpDto.getAttribute());
    tmpType.setAuthenticationType(inpDto.getAuthenticationType());
    tmpType.setAuthenticationPrincipal(inpDto.getAuthenticationPrincipal());
    tmpType.setAuthenticationCredentials(inpDto.getAuthenticationCredentials());

    return tmpType;
  }

  private static ValMethodCRL getValMethodCRL(ValMethodCrlDto inpDto)
  {
    ValMethodCRL tmpType = new ValMethodCRL();
    tmpType.setUrl(inpDto.getUrl());
    tmpType.setSearchbase(inpDto.getSearchbase());
    tmpType.setAttribute(inpDto.getAttribute());
    tmpType.setIntervall(inpDto.getIntervall().intValue());
    tmpType.setIgnoreNextUpdate(inpDto.getIgnoreNextUpdate());
    tmpType.setEscalation(inpDto.getEscalation());
    tmpType.setProtocol(inpDto.getSubType());

    return tmpType;
  }

  private static Certificates getCertificates(Map<String, CertificateDto> inpCertificateDtos)
        throws Exception
  {
    Certificates tmpCertificatesImpl = new Certificates();

    for (CertificateDto tmpCertificateDto : inpCertificateDtos.values())
    {
      Certificate tmpCertificate = new Certificate();
      tmpCertificate.setFriendlyName(tmpCertificateDto.getFriendlyName());
      tmpCertificate.setX509Certificate(tmpCertificateDto.getX509Certificate().getEncoded());
      tmpCertificatesImpl.getCertificate().add(tmpCertificate);
    }

    return tmpCertificatesImpl;
  }

  private static Proxy getProxy() throws Exception
  {
    ProxyDto tmpDto = Configuration.getProxyDto();

    Proxy tmpProxyImpl = new Proxy();
    tmpProxyImpl.setProxyHost(tmpDto.getProxyHost());
    tmpProxyImpl.setProxyPort(tmpDto.getProxyPort());
    tmpProxyImpl.setUsername(tmpDto.getUserName());
    tmpProxyImpl.setNonProxyHosts(tmpDto.getNonProxyHosts());
    tmpProxyImpl.setPassword(tmpDto.getPassword());
    tmpProxyImpl.setTimeout(tmpDto.getTimeout());

    return tmpProxyImpl;
  }

  private static Signature getSignature() throws Exception
  {
    SignatureTokenDto tmpDto = Configuration.getSignatureTokenDto();
    Signature tmpSignatureImpl = new Signature();
    tmpSignatureImpl.setKeystore(tmpDto.getData());
    tmpSignatureImpl.setAlias(tmpDto.getAlias());
    tmpSignatureImpl.setPin(tmpDto.getPin());

    return tmpSignatureImpl;
  }

  private static void init()
  {
    jaxbContext = null;

    try
    {
      if (jaxbContext == null)
      {
        jaxbContext =
              JAXBContext.newInstance("eu.peppol.lsp.xkmsresponder.importexport.schema",
                                      ImportExportHandler.class.getClassLoader());
      }

    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Can not create JAXB context", ex);
    }
  }

}
