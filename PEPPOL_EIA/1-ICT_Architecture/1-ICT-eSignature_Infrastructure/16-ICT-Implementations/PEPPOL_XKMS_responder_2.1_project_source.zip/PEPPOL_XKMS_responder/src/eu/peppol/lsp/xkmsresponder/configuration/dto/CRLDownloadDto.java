/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;
import java.util.Date;


/*
/**
 * Data holder class for CRL downloads
 * @author horstmann
 * 
*/
public class CRLDownloadDto implements Serializable, Cloneable
{
  /**
   *
   */
  private static final long serialVersionUID = 9083780589844611634L;

  private Date aThisUpdate;

  private Date aNextUpdate;

  private Integer aErrorCount = Integer.valueOf(0);

  private volatile Date aLastCheck;

  private String aLastError = "";

  private byte[] aLatestCRL;

  private String aName;

  /**
   * List only needed for removing suspended (re-revoked) certificates in indirect CRLs
   */
//  private List<String> issuerList;

  public CRLDownloadDto()
  {
    // nothing to do
  }

  /**
   * DOCUMENT ME!
   *
   * @param inpCRLDownload DOCUMENT ME!
   *
  public CRLDownloadDto(CRLDownload inpCRLDownload)
  {
    if (inpCRLDownload != null)
    {
      setName(inpCRLDownload.getName());
      setThisUpdate((inpCRLDownload.getThisUpdate() != null) ? (Date) inpCRLDownload.getThisUpdate().clone()
                                                            : null);
      setNextUpdate((inpCRLDownload.getNextUpdate() != null) ? (Date) inpCRLDownload.getNextUpdate().clone()
                                                            : null);
      setLockDate((inpCRLDownload.getLockDate() != null) ? (Date) inpCRLDownload.getLockDate().clone() : null);
      setLockID(inpCRLDownload.getLockID());
      setErrorCount(inpCRLDownload.getErrorCount());
      setMaxLock(inpCRLDownload.getMaxLock());
      setLastCheck((inpCRLDownload.getLastCheck() != null) ? (Date) inpCRLDownload.getLastCheck().clone()
                                                          : null);
      setLastError(inpCRLDownload.getLastError());
      setLatestCRL((inpCRLDownload.getLatestCRL() != null) ? (byte[]) inpCRLDownload.getLatestCRL().clone()
                                                          : null);
    }
  }
   */

  public Date getThisUpdate()
  {
    return (aThisUpdate == null) ? null : (Date) aThisUpdate.clone();
  }

  public void setThisUpdate(Date _thisUpdate)
  {
    aThisUpdate = (_thisUpdate != null) ? (Date) _thisUpdate.clone() : null;
  }

  public Date getNextUpdate()
  {
    return (aNextUpdate == null) ? null : (Date) aNextUpdate.clone();
  }

  public void setNextUpdate(Date _nextUpdate)
  {
    aNextUpdate = (_nextUpdate != null) ? (Date) _nextUpdate.clone() : null;
  }

  public Integer getErrorCount()
  {
    return aErrorCount;
  }

  public void setErrorCount(Integer errorCount)
  {
    this.aErrorCount = DtoHelper.getNullAsEmptyInteger(errorCount);
  }

  public Date getLastCheck()
  {
    return aLastCheck;
  }

  public void setLastCheck(Date _lastCheck)
  {
    aLastCheck = _lastCheck;
  }

  public String getLastError()
  {
    return aLastError;
  }

  public void setLastError(String lastError)
  {
    this.aLastError = DtoHelper.getNullAsEmptyString(lastError);
  }

  public byte[] getLatestCRL()
  {
    return (aLatestCRL != null) ? aLatestCRL.clone() : null;
  }

  public void setLatestCRL(byte[] latestCRL)
  {
    this.aLatestCRL = DtoHelper.getNullAsEmptyBytes(latestCRL);
  }

  public String getName()
  {
    return aName;
  }

  public void setName(String name)
  {
    this.aName = DtoHelper.getNullAsEmptyString(name);
  }
/*
  public List<String> getIssuerList()
  {
	return issuerList;
  }

  public void setIssuerList(List<String> issuerList)
  {
	this.issuerList = issuerList;
  }
*/
  /* (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }

    if (obj == null)
    {
      return false;
    }

    if (getClass() != obj.getClass())
    {
      return false;
    }

    final CRLDownloadDto other = (CRLDownloadDto) obj;

    if (aName == null)
    {
      if (other.aName != null)
      {
        return false;
      }
    }
    else if (!aName.equals(other.aName))
    {
      return false;
    }

    return true;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int PRIME = 31;
    int result = 17;
    result = (PRIME * result) + ((aName == null) ? 0 : aName.hashCode());

    return result;
  }

  /**
   * DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  @Override
  public String toString()
  {
    String returnString = "";
    returnString += ("Name = " + aName);
    returnString += (", ThisUpdate = " + aThisUpdate);
    returnString += (", NextUpdate = " + aNextUpdate);
    returnString += (", ErrorCount = " + aErrorCount);
    returnString += (", LastCheck = " + aLastCheck);
    returnString += (", LastError = " + aLastError);

    return returnString;
  }

  @Override
  public Object clone()
  {
    try
    {
      CRLDownloadDto ret = (CRLDownloadDto) super.clone();

      return ret;
    }
    catch (CloneNotSupportedException e)
    {
      throw new InternalError(e.getMessage());
    }
  }

}
