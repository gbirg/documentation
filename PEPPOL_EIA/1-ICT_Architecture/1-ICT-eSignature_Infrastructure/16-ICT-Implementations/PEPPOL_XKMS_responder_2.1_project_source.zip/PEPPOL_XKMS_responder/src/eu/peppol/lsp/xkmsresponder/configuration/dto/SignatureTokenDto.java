/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;


import java.io.Serializable;
import java.util.Arrays;

/*
/**
 * Data holder class for CRL signature tokens
 * @author horstmann
 * 
*/
public class SignatureTokenDto implements Serializable, Cloneable
{
  private static int hashCode(byte[] array)
  {
    final int PRIME = 31;

    if (array == null)
    {
      return 0;
    }

    int result = 1;

    for (byte tmpElement : array)
    {
      result = (PRIME * result) + tmpElement;
    }

    return result;
  }

  /**
   *
   */
  private static final long serialVersionUID = 4834876236334908454L;

  private String refId = null;

  private String alias = "";

  private byte[] data = new byte[0];

  private String pin = "";

  public SignatureTokenDto()
  {
    // nothing to do
  }

  /**
   * @return a deep copy
   */
  @Override
  public Object clone()
  {
    try
    {
      SignatureTokenDto ret = (SignatureTokenDto) super.clone();
      ret.setData((data != null) ? (byte[]) data.clone() : null);
      return ret;
    }
    catch (CloneNotSupportedException e)
    {
      throw new InternalError(e.getMessage());
    }
  }

  /**
   * DOCUMENT ME!
   * @return   DOCUMENT ME!
   */
  public String getAlias()
  {
    return alias;
  }

  /**
   * DOCUMENT ME!
   * @param _alias   DOCUMENT ME!
   */
  public void setAlias(String _alias)
  {
    alias = DtoHelper.getNullAsEmptyString(_alias);
  }

  /**
   * DOCUMENT ME!
   * @return   DOCUMENT ME!
   */
  public byte[] getData()
  {
    return (data != null) ? data.clone() : null;
  }

  /**
   * DOCUMENT ME!
   * @param _data   DOCUMENT ME!
   */
  public void setData(byte[] _data)
  {
    data = DtoHelper.getNullAsEmptyBytes(_data);
  }

  /**
   * DOCUMENT ME!
   * @return   DOCUMENT ME!
   */
  public String getPin()
  {
    return pin;
  }

  /**
   * DOCUMENT ME!
   * @param pin   DOCUMENT ME!
   */
  public void setPin(String pin)
  {
    this.pin = DtoHelper.getNullAsEmptyString(pin);
  }

  /**
   * DOCUMENT ME!
   *
   * @param obj DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }

    if (obj == null)
    {
      return false;
    }

    if (getClass() != obj.getClass())
    {
      return false;
    }

    final SignatureTokenDto other = (SignatureTokenDto) obj;

    if (alias == null)
    {
      if (other.alias != null)
      {
        return false;
      }
    }
    else if (!alias.equals(other.alias))
    {
      return false;
    }

    if (!Arrays.equals(data, other.data))
    {
      return false;
    }

    if (pin == null)
    {
      if (other.pin != null)
      {
        return false;
      }
    }
    else if (!pin.equals(other.pin))
    {
      return false;
    }

    return true;
  }

  /**
   * DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  @Override
  public int hashCode()
  {
    final int PRIME = 31;
    int result = 17;
    result = (PRIME * result) + ((alias == null) ? 0 : alias.hashCode());
    result = (PRIME * result) + SignatureTokenDto.hashCode(data);
    result = (PRIME * result) + ((pin == null) ? 0 : pin.hashCode());

    return result;
  }

  /**
   * DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  @Override
  public String toString()
  {
    String returnString = "";
    returnString += (", " + alias);
    returnString += (", " + SignatureTokenDto.hashCode(data));
    returnString += (", " + pin);

    return returnString;
  }

  /**
   * @return the refId
   */
  public String getRefId()
  {
    return refId;
  }

  /**
   * @param inpRefId the refId to set
   */
  public void setRefId(String inpRefId)
  {
    refId = DtoHelper.getNullAsEmptyString(inpRefId);
  }
}
