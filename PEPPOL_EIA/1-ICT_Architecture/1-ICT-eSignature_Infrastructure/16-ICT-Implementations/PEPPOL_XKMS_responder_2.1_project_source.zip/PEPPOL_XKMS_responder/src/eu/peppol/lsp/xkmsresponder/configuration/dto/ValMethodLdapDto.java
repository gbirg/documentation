/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;



/**
 * Represents a LDAP validation method configuration
 * @author horstmann
 * 
*/
public class ValMethodLdapDto extends AbstractValMethodDto implements Serializable
{
  private static final long serialVersionUID = -6110122909425002646L;

  private String searchbase = "";

  private String filter = "";

  private String attribute = "";

  private String authenticationType = "none";

  private String authenticationPrincipal = "";

  private String authenticationCredentials = "";

  public ValMethodLdapDto(String inpName)
  {
    super(inpName);
  }

  public String getAttribute()
  {
    return attribute;
  }

  public void setAttribute(String dn)
  {
    attribute = DtoHelper.getNullAsEmptyString(dn);
  }

  public String getAuthenticationType()
  {
    return authenticationType;
  }

  public void setAuthenticationType(String authentication_type)
  {
    authenticationType = DtoHelper.getNullAsEmptyString(authentication_type);
    if (authenticationType.equals(""))
    {
      authenticationType = "none";
    }
  }

  public String getAuthenticationPrincipal()
  {
    return authenticationPrincipal;
  }

  public void setAuthenticationPrincipal(String authentication_principal)
  {
    authenticationPrincipal = DtoHelper.getNullAsEmptyString(authentication_principal);
  }

  public String getAuthenticationCredentials()
  {
    return authenticationCredentials;
  }

  public void setAuthenticationCredentials(String authentication_credentials)
  {
    authenticationCredentials = DtoHelper.getNullAsEmptyString(authentication_credentials);
  }

  public String getSearchbase()
  {
    return searchbase;
  }

  public void setSearchbase(String searchbase)
  {
    this.searchbase = DtoHelper.getNullAsEmptyString(searchbase);
  }

  public String getFilter()
  {
    return filter;
  }

  public void setFilter(String filter)
  {
    this.filter = DtoHelper.getNullAsEmptyString(filter);
  }

  public String getUrl()
  {
    return url;
  }

  public void setUrl(String url)
  {
    this.url = DtoHelper.getNullAsEmptyString(url);
  }

  /* (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (!super.equals(obj))
    {
      return false;
    }

    final ValMethodLdapDto other = (ValMethodLdapDto) obj;

    if (attribute == null)
    {
      if (other.attribute != null)
      {
        return false;
      }
    }
    else if (!attribute.equals(other.attribute))
    {
      return false;
    }

    if (authenticationCredentials == null)
    {
      if (other.authenticationCredentials != null)
      {
        return false;
      }
    }
    else if (!authenticationCredentials.equals(other.authenticationCredentials))
    {
      return false;
    }

    if (authenticationPrincipal == null)
    {
      if (other.authenticationPrincipal != null)
      {
        return false;
      }
    }
    else if (!authenticationPrincipal.equals(other.authenticationPrincipal))
    {
      return false;
    }

    if (authenticationType == null)
    {
      if (other.authenticationType != null)
      {
        return false;
      }
    }
    else if (!authenticationType.equals(other.authenticationType))
    {
      return false;
    }

    if (filter == null)
    {
      if (other.filter != null)
      {
        return false;
      }
    }
    else if (!filter.equals(other.filter))
    {
      return false;
    }

    if (searchbase == null)
    {
      if (other.searchbase != null)
      {
        return false;
      }
    }
    else if (!searchbase.equals(other.searchbase))
    {
      return false;
    }

    if (url == null)
    {
      if (other.url != null)
      {
        return false;
      }
    }
    else if (!url.equals(other.url))
    {
      return false;
    }

    return true;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int PRIME = 31;
    int result = super.hashCode();
    result = (PRIME * result) + ((url == null) ? 0 : url.hashCode());

    return result;
  }

  /**
   * @return a deep copy
   */
  @Override
  public Object clone()
  {
    ValMethodLdapDto ret = (ValMethodLdapDto) super.clone();
    return ret;
  }


  @Override
  public String toString()
  {
	  StringBuilder ret = new StringBuilder();
	  String[] values = {Integer.toString(ValMethodType.LDAP_TYPE), refId, name, url, searchbase,
			  filter, attribute, authenticationType, authenticationPrincipal, authenticationCredentials};
	  for (String val : values)
	  {
		  ret.append(val);
		  ret.append("\t");
	  }
	  return ret.toString();
  }

  public boolean changed(ValMethodLdapDto inpOtherValMethodLdapDto)
  {
    if (!equals(inpOtherValMethodLdapDto))
    {
      return true;
    }

    return false;
  }

}
