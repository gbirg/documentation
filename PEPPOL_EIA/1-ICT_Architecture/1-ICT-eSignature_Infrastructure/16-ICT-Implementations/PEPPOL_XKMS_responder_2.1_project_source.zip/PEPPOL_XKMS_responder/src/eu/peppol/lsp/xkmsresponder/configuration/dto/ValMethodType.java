/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;
import java.util.Hashtable;

import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;

/*
 * Type class for validating methods.
 * @author nagel
 * @author buengener
 * 
*/
public class ValMethodType implements Serializable
{

	public static final int LOCAL_TYPE=0, OCSP_TYPE=1, CRL_TYPE=2, CRL_LDAP_TYPE=3, LDAP_TYPE=4, NONE_TYPE=5, XKMS_TYPE=6;

	public static final ValMethodType LOCAL = new ValMethodType(0);
	public static final ValMethodType OCSP = new ValMethodType(1);
	public static final ValMethodType CRL = new ValMethodType(2);
	public static final ValMethodType CRL_LDAP = new ValMethodType(3);
	public static final ValMethodType LDAP = new ValMethodType(4);
	public static final ValMethodType NONE = new ValMethodType(5);
	public static final ValMethodType XKMS = new ValMethodType(6);
	public static final ValMethodType[] vmt = {LOCAL, OCSP, CRL, LDAP, CRL_LDAP, NONE, XKMS};

	public static final String[] NAMES = {"LOCAL", "OCSP", "CRL", "CRL_LDAP", "LDAP", "NONE", "XKMS"};

	public static final Hashtable<String, String> XKMS_ID_TABLE = new Hashtable<String, String>()
	{
		{
			put(NAMES[0], XKMSConstants.VALIDATESCHEME_LOCAL);
			put(NAMES[1], XKMSConstants.VALIDATESCHEME_OCSP);
			put(NAMES[2], XKMSConstants.VALIDATESCHEME_CRL);
			put(NAMES[3], XKMSConstants.VALIDATESCHEME_CRL_LDAP);
			put(NAMES[4], XKMSConstants.VALIDATESCHEME_LDAP);
			put(NAMES[5], XKMSConstants.VALIDATESCHEME_NONE);
			// XKMS forward only used internally
		}
	};

	private int type;

	ValMethodType(int type)
	{
		this.type = type;
	}

	public String toString()
	{
		return NAMES[type];
	}

	public String getXKMSIdentifier()
	{
		return XKMS_ID_TABLE.get(NAMES[type]);
	}

	public int ordinal()
	{
		return type;
	}

	public boolean isNONE()
	{
		return (type == NONE_TYPE);
	}

	public boolean containsOCSP()
	{
		return (type == OCSP_TYPE);
	}

	public boolean containsCRL()
	{
		return (type == CRL_TYPE || type == CRL_LDAP_TYPE);
	}

	public boolean containsLDAP()
	{
		return (type == LDAP_TYPE || type == CRL_LDAP_TYPE);
	}

	public boolean containsXKMS()
	{
		return (type == XKMS_TYPE);
	}
}
