/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;

/**
 * Servlet which answers soap requests without completely parsing them.
 * This servlet works under the following restrictions:
 * <ul>
 *   <li> requests with wrong HTML meta data are not rejected
 *   <li> there must be exactly one body element
 *   <li> requests with wrong XML syntax are not rejected as long as
 *        relevant fields can be recognized
 *   <li> one instance of this servlet can only provide one service
 * </ul>
 *
 * @author tt
 *
 * 
*/
public class SimpleSoapServlet extends HttpServlet
{
  private static final long serialVersionUID = 1L;

  private static final Logger LOG = Logger.getLogger(SimpleSoapServlet.class.getName());

  protected String serviceName;

  protected String serviceUrl;

  private static List<String> supportedNamespaces;

  private SOAPEntry delegate = new SOAPEntry();

  static
  {
    supportedNamespaces = new ArrayList<String>();
    supportedNamespaces.add("http://schemas.xmlsoap.org/soap/envelope");
    supportedNamespaces.add("http://www.w3.org/2003/05/soap-envelope");
    InputStream is = SimpleSoapServlet.class.getResourceAsStream("/peppol_xkms_responder.wsdl");
    int i;
    byte[] tmp = new byte[1024];
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    try
    {
	    while ((i=is.read(tmp)) > -1)
	    	baos.write(tmp, 0, i);
	    is.close();
	    baos.close();
    }
    catch (IOException ioe)
    {
    	LOG.log(Level.SEVERE, "Problem loading WSDL at startup.", ioe);
    }
    WSDL = baos.toByteArray();
  }

  private static final String SOAP_START =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
              + "<soapenv:Envelope xmlns:soapenv=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
              + "   <soapenv:Body>\n";

  private static final String SOAP_END = "\n   </soapenv:Body>\n</soapenv:Envelope>\n";

  public static final String SOAP_FAULT_CODE_SENDER = "soapenv:Sender";

  public static final String SOAP_FAULT_CODE_RECEIVER = "soapenv:Receiver";

  public static final String SOAP_FAULT_CODE_DATA_ENCODING_UNKNOWN = "soapenv:DataEncodingUnknown";

  private static String ENCODING = "UTF-8";

  private static final byte[] WSDL;

  /**
   * Return a status report - the actual work of this servlet is done in post method.
   *
   * @param req may contain param "WSDL" (value not interpreted), everything else is ignored
   * @param res response to write into
   *
   * @throws IOException in case we cannot write to the response stream
   */
  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
  {
	if (req.getParameterNames().hasMoreElements())
	{
		String wsdl = (String)req.getParameterNames().nextElement();
		if (wsdl.equalsIgnoreCase("wsdl") && !req.getParameter(wsdl).equalsIgnoreCase("false"))
	    {
	        res.setContentType("text/xml");
	        OutputStream os = res.getOutputStream();
	        os.write(WSDL);
	        os.close();
	        return;
	    }
	}

    res.setContentType("text/html");
    serviceUrl =
          "http://" + req.getLocalName() + ":" + req.getLocalPort() + "/" + req.getRequestURI().substring(1);
    serviceName = serviceUrl.substring(serviceUrl.lastIndexOf('/') + 1);

    PrintWriter out = res.getWriter();

    out.println("<html><body>");
    out.println("<h2>This is a WebService named " + serviceName + "!</h2>");
    out.println("<p> Try to invoke  it using the POST method. </p>");
    out.println("<p> Learn more about how to invoke this service reading the <a href=\"" + serviceUrl
                  + "?WSDL=true\"> WSDL </a> file.</p>");
    out.println(" <p>Body element should fit XKMS 2 schema<br/>");
    out.println(" URL is " + serviceUrl + "</p>");
    out.println("</body></html>");

    out.close();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException
  {
	 if (Configuration.service == null)
		 Configuration.service = req.getRequestURL().toString();

    res.setContentType("application/soap+xml");
    InputStream in = req.getInputStream();
    String request = ResponderHelper.readFromStream(in);
    OutputStream out = res.getOutputStream();
    out.write(SOAP_START.getBytes(ENCODING));

    try
    {
      String prefix = XmlTagExtractor.getNamespacePrefix(request, supportedNamespaces);
      if (prefix == null)
      {
        prefix = "soapenv:";
      }

      try
      {
    	  request = XmlTagExtractor.extract(request, prefix + "Body", 0).content;
      }
      catch (IllegalArgumentException e)
      {
        throw new SoapFaultException(SimpleSoapServlet.SOAP_FAULT_CODE_SENDER, "Error processing request: " + e.getMessage());
      }
      LOG.fine("request is: " + request);
      String response = delegate.processContent(request);
      LOG.fine("response is: " + response);

      if (response.trim().startsWith("<?"))
      {
        response = response.substring(response.indexOf("<", response.indexOf("<") + 1));
      }

      out.write(response.getBytes(ENCODING));
    }
    catch (SoapFaultException e)
    {
    	if (e.getCause() == null)
    		LOG.log(Level.SEVERE, "doPost() SoapFaultException: "  + e.getMessage());
    	else
    		LOG.log(Level.SEVERE, "doPost() SoapFaultException: ", e);

    	out.write("      <soapenv:Fault>\n".getBytes(ENCODING));
    	out.write("          <soapenv:Code>\n".getBytes(ENCODING));
    	out.write(("             <soapenv:Value>" + e.getFaultCode() + "</soapenv:Value>\n").getBytes(ENCODING));
    	out.write("          </soapenv:Code>\n".getBytes(ENCODING));
    	out.write("          <soapenv:Reason>\n".getBytes(ENCODING));
    	out.write(("             <soapenv:Text xml:lang=\"en-US\">" + e.getFaultString() + "</soapenv:Text>\n").getBytes(ENCODING));
    	out.write("          </soapenv:Reason>\n".getBytes(ENCODING));
    	out.write("      </soapenv:Fault>".getBytes(ENCODING));
    }

    out.write(SOAP_END.getBytes(ENCODING));
    out.close();
  }

}
