/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Extract an single named XML tag from an XML structure.
 * This class is much faster than an XML parser because it ignores most of the
 * input. Use this class if
 * <li>
 *   <ul> you do not need to parse the XML structure completely
 *   <ul> you want to know the content of a single named XML tag or its attributes
 *   <ul> the schema forbids a nested tag with the same name as the tag to extract.
 * <li>
 * @author tt, revisor te
 * @since 2.3
 * 
*/
public class XmlTagExtractor
{
  private XmlTagExtractor()
  {
    // nothing to do here
  }

  /**
   * Holds the content of the tag as String, a map of Attributes (key=attribute name)
   * ant the position where the tag was found
   * @author tt
   *
   */
  public static class TagDescription
  {
    public final String content;

    public final Map<String, String> attributes;

    public final int pos;

    public final int length;

    protected TagDescription(String _content, Map<String, String> _attributes, int _pos, int _length)
    {
      content = _content;
      attributes = (_attributes != null) ? Collections.unmodifiableMap(_attributes) : null;
      pos = _pos;
      length = _length;
    }
  }

  public static String getNamespacePrefix(String input, List<String> namespaces)
        throws IllegalArgumentException
  {
    int pos = input.indexOf("xmlns:");
    while (pos != -1)
    {
      int ePos = input.indexOf("=", pos);
      int nsStart = input.indexOf("\"", pos);
      int nsEnd = input.indexOf("\"", nsStart + 1);
      String namespace = input.substring(nsStart + 1, nsEnd);
      if (namespaces.contains(namespace))
      {
        return input.substring(pos + 6, ePos).trim() + ":";
      }
      pos = input.indexOf("xmlns:", pos + 1);
    }
    pos = input.indexOf("xmlns=");
    if (pos != -1)
    {
      int nsStart = input.indexOf("\"", pos);
      int nsEnd = input.indexOf("\"", nsStart + 1);
      String namespace = input.substring(nsStart + 1, nsEnd);

      if (namespaces.contains(namespace))
      {
        return "";
      }
    }
    return null;
  }

  /**
   * Return a description of a specified tag within the input XML structure.
   *
   * @param input XML
   * @param tagName name of the tag including the namespace prefix
   * @param startPos position within the input string to start search from
   *
   * @return data object holding content and position of the extracted tag
   *
   * @throws IllegalArgumentException if XML is not well-formed at some
   * place which disturbs our search
   */
  public static TagDescription extract(String input, String tagName, int startPos)
        throws IllegalArgumentException
  {
    int tagPos = input.indexOf("<" + tagName, startPos);

    if (tagPos == -1)
        throw new IllegalArgumentException("No SOAP content found.");

    int tagEndPos = input.indexOf(">", tagPos + 1);
    int nextStartPos = input.indexOf("<", tagPos + 1);

    if ((tagEndPos == -1) || (nextStartPos != -1 && nextStartPos < tagEndPos))
    {
      throw new IllegalArgumentException("start tag " + tagName + " not completed");
    }

    String content = null;
    boolean selfClosing = input.charAt(tagEndPos - 1) == '/';
    int length = (tagEndPos + 1) - tagPos;

    if (!selfClosing)
    {
      int closingTagPos = input.indexOf("</" + tagName + ">", tagEndPos);

      if (closingTagPos == -1)
      {
        throw new IllegalArgumentException("closing tag </" + tagName + "> not found");
      }

      content = input.substring(tagEndPos + 1, closingTagPos);
      length = (input.indexOf(">", closingTagPos) + 1) - tagPos;
    }

    Map<String, String> attributes = new HashMap<String, String>();
    String attrStr =
          input.substring(tagPos + 1 + tagName.length(), selfClosing ? (tagEndPos - 1) : tagEndPos).trim();

    while (attrStr.length() > 0)
    {
      int equalsPos = attrStr.indexOf("=");

      if (equalsPos == -1)
      {
        throw new IllegalArgumentException("expected '=' after param name ");
      }

      String key = attrStr.substring(0, equalsPos).trim();
      int vPos = attrStr.indexOf("\"", equalsPos);

      if ((vPos == -1) || (attrStr.substring(equalsPos + 1, vPos).trim().length() > 0))
      {
        throw new IllegalArgumentException("expected param value to be enclosed in '\"'");
      }

      int endPos = attrStr.indexOf("\"", vPos + 1);

      if (endPos == -1)
      {
        throw new IllegalArgumentException("end of param " + key + " value not found");
      }

      attributes.put(key, attrStr.substring(vPos + 1, endPos));
      attrStr = attrStr.substring(endPos + 1);
    }

    return new TagDescription(content, attributes, tagPos, length);
  }
}
