/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import org.w3._2000._09.xmldsig.KeyInfoType;
import org.w3._2000._09.xmldsig.X509DataType;
import org.w3._2002._03.xkms.CompoundResultType;
import org.w3._2002._03.xkms.KeyBindingType;
import org.w3._2002._03.xkms.ResultType;
import org.w3._2002._03.xkms.StatusType;
import org.w3._2002._03.xkms.ValidateRequestType;
import org.w3._2002._03.xkms.ValidateResultType;
import org.w3._2002._03.xkms.ValidityIntervalType;

import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.entry.SoapFaultException;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSContentHandler;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSContextHolder;
import eu.peppol.uri.xkmsext.v2.ValidateResultExtEUType;

/**
 * This class parses incoming requests and constructs the response messages.
 * @author buengener
 *
 * 
*/

public class RequestController
{
  protected final String MAJOR_MINOR_ERROR = "Error";

  protected final String MAJOR_MINOR_NOMATCH = "NoMatch";

  protected static final String ERROR_XKMS =
        "<Fault>" + "\n<ResultMajor>" + XKMSConstants.XKMS_RESULT_MAJOR_Sender + "</ResultMajor>"
              + "\n<ResultMinor>" + XKMSConstants.XKMS_RESULT_MINOR_Failure + "</ResultMinor>" + "\n</Fault>";


  protected Logger LOG = Logger.getLogger(RequestController.class.getName());

  XKMSContentHandler xkmsHandler = null;

  private Hashtable<String, ValidateRequestType> requestTypeList = new Hashtable<String, ValidateRequestType>();


  public ValidateRequestType getValidateRequestTypeByID(String inpID)
  {
    LOG.fine("getValidateRequestTypeByID: " + inpID);
    LOG.fine("returning requestType: " + requestTypeList.get(inpID));
    return requestTypeList.get(inpID);
  }

  /**
   * The message process method of the RequestController.
   *
   * @param in InputStream of Client Request
   */

  public List<CPVRequest> getRequests(String in) throws SoapFaultException
  {
    LOG.fine("(start) Process Request Entry.");

    xkmsHandler = new XKMSContentHandler(in);

    List<ValidateRequestType> validateRequests = xkmsHandler.getRequestObjects();


    //Assembling of certificates included in ValidateRequests for CertificatePathValidator
    ArrayList<CPVRequest> cpvRequestList = new ArrayList<CPVRequest>();

    if ((validateRequests != null) && !validateRequests.isEmpty())
    {
    	for (ValidateRequestType vrt : validateRequests)
	    {
	      LOG.fine("Put Request wih RequestID: " + vrt.getId());

	      requestTypeList.put(vrt.getId(), vrt);

	      CPVRequest dCPVRequest = createCPVRequest(vrt);

	      if (dCPVRequest != null)
	      {
	        cpvRequestList.add(dCPVRequest);
	      }
	    }
    }
    return cpvRequestList;

  }

  public String createResponseMessage(Hashtable<String, CPVResponse> cpvResults,
                                      Hashtable<String, ValidateResultType> xkmsResponses) throws Exception
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Got a List CPVResponds from CertificatePathValidator" + " size: " + cpvResults.size());
    }

    try
    {
      completeXKMSResult(cpvResults, xkmsResponses);
      String msgString = new String(getXkmsResponse(), "UTF-8");
      return msgString;
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Error in RequestController.createResponse()", ex);
    }

    return null;
  }

  /**
   * This methods analyzes the further Request Informations obtained from RespondWith, and KeyUsage,
   * to complete the Result Messages.
   * @param checkInfo Hashtable
   * @throws Exception Exception
   */
  private void completeXKMSResult(Hashtable<String, CPVResponse> pCPVResults,
                                  Hashtable<String, ValidateResultType> xkmsResponses) throws Exception
  {
    RespondWithHelper helper = new RespondWithHelper();

    if (LOG.isLoggable(Level.FINE))
      LOG.fine("Start completeXKMSResult");

    for (ValidateRequestType vrt : xkmsHandler.getRequestObjects())
    {
      if (xkmsResponses.containsKey(vrt.getId()))
      {
        	LOG.fine("Found a single ValidateResult with forwarding");
        	xkmsHandler.getValidateResultObjects().put(vrt.getId(), xkmsResponses.get(vrt.getId()));
      }
      else
      {
        ValidateResultType validateResult = xkmsHandler.getValidateResultObjects().get(vrt.getId());
        Set<String> respondWiths = new HashSet<String>();
        if (xkmsHandler.isCompoundRequest())
          respondWiths.addAll(xkmsHandler.getRequestObject().getRespondWith());
        respondWiths.addAll(vrt.getRespondWith());
        KeyInfoType keyInfo = null;
        CertificatevalidatorResult tmpUserCertValidatorResult = null;
        CertificatevalidatorResult tmpIssuerCertValidatorResult = null;
        X509Certificate tmpUserCert = null;

        KeyBindingType keyBinding = new KeyBindingType();
        CPVResponse dCPVRespond = null;

        if (pCPVResults != null)
        {
          dCPVRespond = pCPVResults.get(vrt.getId());

          if (dCPVRespond == null)
          {
            setMajorAndMinor(validateResult, MAJOR_MINOR_NOMATCH);

            continue;
          }

          if (dCPVRespond.getCertificateCheckLists().length < 1)
          {
            LOG
               .severe("Fault in process. There is no object in the CertificatevalidatorResult[] array from the CPV.");
            setMajorAndMinor(validateResult, MAJOR_MINOR_ERROR);

            //;
            continue; // here is nothing more to do without usercert
          }

          tmpUserCertValidatorResult = dCPVRespond.getCertificateCheckLists()[0];

          tmpUserCert = tmpUserCertValidatorResult.getCertificate();

          if (dCPVRespond.getCertificateCheckLists().length > 1)
          {
            tmpIssuerCertValidatorResult = dCPVRespond.getCertificateCheckLists()[1];
          }

          // Builds Suitable KeyInfoType Elements for the RespondsWith Request
          if ((respondWiths != null) && !respondWiths.isEmpty())
          {
            CertificatevalidatorResult[] cpvResult = dCPVRespond.getCertificateCheckLists();
            keyInfo = helper.createRespondWithCertificate(cpvResult, respondWiths);
          }

          //Process KeyInfo
          // Adds the the obtained KeyInfo Objects to the KeyBinding Element
          if (keyInfo != null)
          {
            keyBinding.setKeyInfo(keyInfo);
          }

          if ((vrt.getQueryKeyBinding().getKeyUsage() != null)
              && !vrt.getQueryKeyBinding().getKeyUsage().isEmpty())
          {
            List<String> keyUsageList = KeyUsageHelper.getKeyUsageForResult(tmpUserCert);

            if (!keyUsageList.isEmpty())
            {
              for (int i = 0; i < keyUsageList.size(); i++)
              {
                keyBinding.getKeyUsage().add(keyUsageList.get(i));
              }
            }
          }

          //Process Status and add to KeyBinding
          Object objStatus = StatusHelper.getStatus(dCPVRespond);

          if (objStatus != null)
          {
            keyBinding.setStatus((StatusType) objStatus);
          }

          //Process ValidityIntervall and add to KeyBinding
          Object objValiInt = ValidityIntervalHelper.getValidityIntervall(tmpUserCertValidatorResult);

          if (objValiInt != null)
          {
            keyBinding.setValidityInterval((ValidityIntervalType) objValiInt);
          }

          //Add KeyBinding to ValidateResult
          validateResult.getKeyBinding().add(keyBinding);
        }

        if (respondWiths.contains(XKMSConstants.XKMS_RESPONDWITH_EU_EXTENSION))
        {
        	ValidateResultExtEUType tmpValidationResultExtEU = XKMSContentHandler.getValidateResultExtEU(validateResult);
	        MessageExtensionHandler.updateResultMessageExtension(tmpValidationResultExtEU,
	                                                                tmpUserCertValidatorResult,
	                                                                tmpIssuerCertValidatorResult);
        }
      }
    }
  }

      /**
       * This methods builds up a valid XKMS Result stream of all completed ResultType Objects
       * @return OutputStream
       * @throws java.io.IOException
       */
  @SuppressWarnings("unchecked")
  private byte[] getXkmsResponse() throws Exception
  {
    try
    {
      LOG.fine("(start) getXkmsStream()");

      ResultType resultType = null;

      XKMSContextHolder tmpXKMSContextHolder = XKMSContextHolder.getSingleton();
      Marshaller m = tmpXKMSContextHolder.getMarshaller();

      ByteArrayOutputStream outbefore = new ByteArrayOutputStream();

      if (xkmsHandler.isCompoundRequest())
      {
        resultType = xkmsHandler.getCompoundResult();

        if (!xkmsHandler.getValidateResultObjects().isEmpty())
        {

          List<ResultType> tmpLocateResultOrValidateResultOrRegisterResult =
                ((CompoundResultType) resultType).getLocateResultOrValidateResultOrRegisterResult();

          for (String id : xkmsHandler.getValidateResultObjects().keySet())
          {
        	  LOG.fine("Adde " + xkmsHandler.getValidateResultObjects().get(id));
        	  tmpLocateResultOrValidateResultOrRegisterResult.add(xkmsHandler.getValidateResultObjects().get(id));
          }
        }
        m.marshal(new JAXBElement(new QName("http://www.w3.org/2002/03/xkms#", "CompoundResult"),
                                  resultType.getClass(), resultType), outbefore);
      }
      else
      {
        //if the XKMS Request was a Single ValidateRequest. Buildup a stream out of it.
          resultType = xkmsHandler.getValidateResultObjects().values().iterator().next();
    	  LOG.fine("Add single validate result " + resultType);
    	  m.marshal(new JAXBElement(new QName("http://www.w3.org/2002/03/xkms#", "ValidateResult"),
                                  resultType.getClass(), resultType), outbefore);
      }

      tmpXKMSContextHolder.recycle(m);

      if (XKMSSignature.isSignatureEnabled())
        return XKMSSignature.signXKMS(new ByteArrayInputStream(outbefore.toByteArray()), resultType.getId());

      return outbefore.toByteArray();


    }
    catch (JAXBException ex)
    {
      if (LOG.isLoggable(Level.SEVERE))
      {
        LOG.log(Level.SEVERE, "Fehler: ", ex);
      }

      throw new Exception("Cant marshal the xkms-result object.");
    }
  }

  /**
   * Creates for the Certificate containing in the ValidateRequest a unique CPVRequest Object
   * for the CertificatePathValidator. This Object are distinguished by means of the ValidateRequest id.
   * @param id String ValidateRequestId
   * @return CPVRequest Object
   */
  private CPVRequest createCPVRequest(ValidateRequestType vrt)
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Start of CVPRequest creation");
    }

    CPVRequest cp = null;

    try
    {

      cp = new CPVRequest();

      for (Object o : vrt.getQueryKeyBinding().getKeyInfo().getContent())
      {
        LOG.fine("Content of KeyInfo: " + o.getClass() + " " + o);

        if (o instanceof JAXBElement)
        {
          X509DataType tmpData = (X509DataType) ((JAXBElement) o).getValue();
          for (Object tmpO : tmpData.getX509IssuerSerialOrX509SKIOrX509SubjectName().toArray())
          {
            if (tmpO instanceof JAXBElement && ((JAXBElement) tmpO).getName().getLocalPart().equals("X509Certificate"))
            {
              cp.addCertifcate(((byte[]) ((JAXBElement) tmpO).getValue()));
            }
          }
        }

        if (vrt.getQueryKeyBinding().getTimeInstant() != null)
        {
          GregorianCalendar time = vrt.getQueryKeyBinding().getTimeInstant().getTime().toGregorianCalendar();

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Add the Time instance for ValidateRequest ID: " + vrt.getId() + " " + "Time: "
                      + time.getTime().toString());
          }

          cp.setTimeInstance(time);
        }
        else
        {
          cp.setTimeInstance(null);
        }

        if (vrt.getRespondWith().contains(XKMSConstants.XKMS_RESPONDWITH_OCSPNOCACHE))
        {
          cp.setOcspNoCache(true);
        }
        else
        {
          cp.setOcspNoCache(false);
        }

        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("End of CVPRequest creation");
        }

        cp.setRequestID(vrt.getId());
      }

      return cp;
    }
    catch (Exception ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.SEVERE, "Error: ", ex);
      }

      return null;
    }
  }

  private void setMajorAndMinor(ValidateResultType pValidateResult, String pStr)
  {
    if (pStr.equalsIgnoreCase(MAJOR_MINOR_NOMATCH))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Sender);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_NoMatch);
    }
    else if (pStr.equalsIgnoreCase(MAJOR_MINOR_ERROR))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Receiver);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_Failure);
    }
  }

  private void setMajorAndMinorFromErrorCode(ValidateResultType pValidateResult, String errorCode)
  {
    if (errorCode.equals(XKMSConstants.ErrorExtension_Unknown))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Receiver);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_Failure);
    }

    if (errorCode.equals(XKMSConstants.ErrorExtension_SignatureKeyToShort))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Sender);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_NoAuthentication);
    }

    if (errorCode.equals(XKMSConstants.ErrorExtension_WrongTimeInstant))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Sender);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_MessageNotSupported);
    }

    if (errorCode.equals(XKMSConstants.ErrorExtension_UnknownCA))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Receiver);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_Failure);
    }

    if (errorCode.equals(XKMSConstants.ErrorExtension_WrongCertificateFormat))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Sender);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_MessageNotSupported);
    }

    if (errorCode.equals(XKMSConstants.ErrorExtension_TrustCenterNotReachable))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Receiver);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_Failure);
    }

    if (errorCode.equals(XKMSConstants.ErrorExtension_OpaqueClientDataToLong))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Sender);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_MessageNotSupported);
    }

    if (errorCode.equals(XKMSConstants.ErrorExtension_UnknownCA))
    {
      pValidateResult.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Sender);
      pValidateResult.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_Incomplete);
    }
  }
}
