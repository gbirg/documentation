/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.net.ConnectException;
import java.security.SignatureException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.Init;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.keys.keyresolver.KeyResolverException;
import org.apache.xml.security.signature.XMLSignature;
import org.w3._2002._03.xkms.ValidateRequestType;
import org.w3._2002._03.xkms.ValidateResultType;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSContentHandler;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSContextHolder;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSResponseHelper;
import eu.peppol.uri.xkmsext.v2.ErrorExtensionType;
import eu.peppol.uri.xkmsext.v2.ObjectFactory;
import eu.peppol.uri.xkmsext.v2.RequestingNodeChainType;
import eu.peppol.uri.xkmsext.v2.ResponderDetailsType;
import eu.peppol.uri.xkmsext.v2.ValidateResultExtEUType;

/**
 * This class performs XKMS forward validation.
 * @author buengener
 *
 * 
*/
public class XKMSForwarding extends Thread
{

  private IssuerDto aIssuerDto;

  private ValidateRequestType aValidateRequest;

  private ValidateResultType validateResult;

  private String requestID;

  private CPVRequest[] notifyObject;

private static final Logger LOG = Logger.getLogger(XKMSForwarding.class.getName());

  private static final String SOAP_START =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Body>";

  private static final String SOAP_END = "</soapenv:Body></soapenv:Envelope>";

  public XKMSForwarding(IssuerDto inpIssuer, ValidateRequestType inpValidateRequest)
  {
    aIssuerDto = inpIssuer;
    aValidateRequest = inpValidateRequest;
    requestID = aValidateRequest.getId();
  }

  public void setNotifyObject(CPVRequest[] notifyObject)
  {
	this.notifyObject = notifyObject;
  }

  public void run()
  {
    LOG.fine("(start) getXkmsStream()");

    ObjectFactory of = new ObjectFactory();
    DatatypeFactory df = null;

    try
    {
    	df = DatatypeFactory.newInstance();
	    XKMSContextHolder tmpXKMSContextHolder = XKMSContextHolder.getSingleton();
	    Marshaller m = tmpXKMSContextHolder.getMarshaller();

	    ByteArrayOutputStream outbefore = new ByteArrayOutputStream();

	    // R1030
	    aValidateRequest.setSignature(null);
	    aValidateRequest.setService(aIssuerDto.getValMethodXkmsDto().getUrl());
	    aValidateRequest.setId(XKMSResponseHelper.getMessageId());

	    RequestingNodeChainType rnct = XKMSContentHandler.extractRequestingNodeChain(aValidateRequest);

	    if (rnct == null)
	    	throw new IllegalArgumentException("Validation must be forwarded to another responder, "
	    			+ "but ValidateRequestExtEU-Tag is missing");

	    if (rnct.getRequestingNode().contains(Configuration.service))
	    	throw new LoopDetectedException("Loop detected when trying to forward request from "
	    			+ Configuration.service + " to " + aIssuerDto.getValMethodXkmsDto().getUrl());

	    rnct.getRequestingNode().add(Configuration.service);

	    m.marshal(new JAXBElement(new QName("http://www.w3.org/2002/03/xkms#", "ValidateRequest"),
	                              aValidateRequest.getClass(), aValidateRequest), outbefore);
	    if (LOG.isLoggable(Level.FINE))
	  	  LOG.fine("ValidateRequest in XKMSForwarding: " + outbefore.toString());
	    tmpXKMSContextHolder.recycle(m);

	    byte[] retBytes = outbefore.toByteArray();

	    if (XKMSSignature.isSignatureEnabled())
	  	  retBytes = XKMSSignature.signXKMS(new ByteArrayInputStream(retBytes), aValidateRequest.getId());

	    ByteArrayOutputStream ret = new ByteArrayOutputStream();
	    ret.write(SOAP_START.getBytes());
	    ret.write(retBytes);
	    ret.write(SOAP_END.getBytes());

	    byte[] tmpXkmsRequest = ret.toByteArray();

	    byte[] rsp;

	    rsp = ResponderTransport.sendHTTPRequest(aIssuerDto.getValMethodXkmsDto().getUrl(), tmpXkmsRequest, ResponderTransport.HTTP_SOAP_HEADER);


	    //SOAP envelope/body must be removed
	    String charSet = "UTF-8";
	    int begin = 0;
		int end;
		while (rsp[begin] != '>')
			begin++;
		String xmlDecl = new String(rsp, 0, begin);
		if ((begin=xmlDecl.indexOf("encoding")) >= 0)
		{
			begin = xmlDecl.indexOf('\"', begin)+1;
			end = xmlDecl.indexOf('\"', begin);
			charSet = xmlDecl.substring(begin, end);
		}

		String data = new String(rsp, charSet);
	    begin = data.indexOf("ValidateResult");
	    if (begin == -1)
	    {
	        createErrorResponse();
	        return;
	    }
	    while (data.charAt(begin) != '<')
	    	begin--;
	    end = data.lastIndexOf("ValidateResult>") + 15;
	    if (end == -1)
	    {
	      createErrorResponse();
	      return;
	    }

	    String validateResponse = data.substring(begin, end);

	    Unmarshaller u = tmpXKMSContextHolder.getUnmarshaller();
	    JAXBElement<ValidateResultType> tmpResponseObject = (JAXBElement<ValidateResultType>) u.unmarshal(new StringReader(validateResponse));
	    tmpXKMSContextHolder.recycle(u);

	    ValidateResultType tmpResult = tmpResponseObject.getValue();

        tmpResult.setId(XKMSResponseHelper.getMessageId());
        tmpResult.setRequestId(requestID);
	    tmpResult.setSignature(null);

	    checkSignature(validateResponse, ResponderHelper.createCertificate(aIssuerDto.getValMethodXkmsDto().getSigCertificate()));

	    validateResult = tmpResult;
    }
    catch (Exception e)
    {
    	LOG.log(Level.FINE, "Problem in XKMSForward", e);
        ValidateResultType tmpValidateResultType = new ValidateResultType();
        tmpValidateResultType.setService(Configuration.service);
        tmpValidateResultType.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Receiver);

        if (e instanceof SignatureException)
        {
        	// R1050
            tmpValidateResultType.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_ReasonTrustViolation);
            tmpValidateResultType.setService(aValidateRequest.getService());
        }
        else
        	tmpValidateResultType.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_Failure);

        tmpValidateResultType.setOpaqueClientData(aValidateRequest.getOpaqueClientData());
        tmpValidateResultType.setId(XKMSResponseHelper.getMessageId());
        tmpValidateResultType.setRequestId(requestID);
        tmpValidateResultType.setNonce(aValidateRequest.getNonce());

	    ValidateResultExtEUType result = new ValidateResultExtEUType();

	    ResponderDetailsType tmpResponderDetails =  MessageExtensionHandler.createResponderDetails();
	    result.getResponderDetails().add(tmpResponderDetails);

		ErrorExtensionType eet = of.createErrorExtensionType();
        if (e instanceof IOException)
        	eet.setReason(XKMSConstants.ErrorExtension_NextResponderInChainNotReached);
        else if (e instanceof LoopDetectedException)
        	eet.setReason(XKMSConstants.ErrorExtension_ResponderChainLoop);
        else
        	eet.setReason(XKMSConstants.ErrorExtension_Unknown);
		eet.setDetail(e.getMessage());
		result.getErrorExtension().add(eet);

		tmpValidateResultType.getMessageExtension().add(of.createValidateResultExtEU(result));

        validateResult = tmpValidateResultType;
    }
    finally
    {
    	// must be reset to keep the XKMS-request hashtable in order
    	aValidateRequest.setId(requestID);
    	synchronized (notifyObject)
    	{
        	notifyObject.notifyAll();
		}
    }
  }

  public static void checkSignature(String xml, X509Certificate cert) throws SignatureException, ParserConfigurationException,
	IOException, SAXException, KeyResolverException,
	XMLSignatureException, XMLSecurityException
  {
	  checkSignature(new InputSource(new StringReader(xml)), cert);
  }



  public static void checkSignature(InputSource xml, X509Certificate cert) throws SignatureException, ParserConfigurationException,
  																			IOException, SAXException, KeyResolverException,
  																			XMLSignatureException, XMLSecurityException

  {
	  ArrayList<X509Certificate> ret = new ArrayList<X509Certificate>();
	  try
	  {
	    DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
	    fact.setNamespaceAware(true);
	    DocumentBuilder builder = fact.newDocumentBuilder();
	    Document doc =
	    	builder
	    	.parse(xml);

	    NodeList signatureNodesList = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature");
	    LOG.fine("count of signature entries: " + signatureNodesList.getLength());

	    for (int i = 0; i < signatureNodesList.getLength(); i++)
	    {
	    	LOG.fine("checkAndLogSig Signature nr: " + i);

	    	Element sigElement = (Element) signatureNodesList.item(i);
	    	XMLSignature signature = new XMLSignature(sigElement, "");
	    	KeyInfo ki = signature.getKeyInfo();
	    	if (ki.containsX509Data())
	    	{
	    		LOG.fine("Signature contains signature certificate");
	    		ret.add(ki.getX509Certificate());
	    	}
	    	else
	    		throw new SignatureException("XMLSignatures without enclosed certificate not supported.");

	    	if (!signature.checkSignatureValue(ret.get(ret.size()-1).getPublicKey()))
	    		throw new SignatureException("Wrong signature found !");
	    }

	    if (ret.size() == 0)
	    	throw new SignatureException("No valid signature found !");

	    if (cert != null)
	    {
    	    boolean expectedCertFound = false;
	    	for (X509Certificate crt : ret)
	    		if (crt.equals(cert))
	    		{
	    			expectedCertFound = true;
	    			break;
	    		}

	    	if (!expectedCertFound)
	    		throw new SignatureException("Configured signature certificate not found in response.");
	    }
	    else
	    {
	    	if (Configuration.acceptTAmessagesOnly)
	    	{
	    	    boolean trustedCertFound = false;

		    	for (X509Certificate crt : ret)
		    		if (Configuration.getTrustedAnchor(ResponderHelper.getFingerprint(crt)) != null)
		    		{
		    			trustedCertFound = true;
		    			break;
		    		}
		    	if (!trustedCertFound)
		    		throw new SignatureException("No signature certificate listed in trusted anchor configuration found in request.");
		    }

    	}

	  }
	  catch (Exception e)
	  {
		  LOG.log(Level.SEVERE, "Problem in signature validation.", e);
		  throw new SignatureException(e.getMessage());
	  }

  }


  private void createErrorResponse()
  {
    ValidateResultType tmpValidateResultType = new ValidateResultType();
    tmpValidateResultType.setId(XKMSResponseHelper.getMessageId());
    tmpValidateResultType.setService(Configuration.service);
    tmpValidateResultType.setResultMajor(XKMSConstants.XKMS_RESULT_MAJOR_Receiver);
    tmpValidateResultType.setResultMinor(XKMSConstants.XKMS_RESULT_MINOR_Failure);
    tmpValidateResultType.setOpaqueClientData(aValidateRequest.getOpaqueClientData());
    tmpValidateResultType.setRequestId(aValidateRequest.getId());
    tmpValidateResultType.setNonce(aValidateRequest.getNonce());
    validateResult = tmpValidateResultType;
  }

  public String getRequestID()
  {
		return requestID;
  }

  public ValidateResultType getValidateResult()
  {
	return validateResult;
  }

  static class LoopDetectedException extends Exception
  {
	  LoopDetectedException(String msg)
	  {
		  super(msg);
	  }
  }

  public static void main(String[] args)
{
	try
	{
		byte[] rsp = ResponderHelper.readBytesFromStream(new FileInputStream("/home/buengener/Dokumente/unizeto_sig_fixed.xml"));
	    //SOAP envelope/body must be removed
	    String charSet = "UTF-8";
	    int begin = 0;
		int end;
		while (rsp[begin] != '>')
			begin++;
		String xmlDecl = new String(rsp, 0, begin);
		if ((begin=xmlDecl.indexOf("encoding")) >= 0)
		{
			begin = xmlDecl.indexOf('\"', begin)+1;
			end = xmlDecl.indexOf('\"', begin);
			charSet = xmlDecl.substring(begin, end);
		}

		String data = new String(rsp, charSet);
	    begin = data.indexOf("ValidateResult");
	    if (begin == -1)
	    {
	    	System.err.println("PENG 1");
	        return;
	    }
	    while (data.charAt(begin) != '<')
	    	begin--;
	    end = data.lastIndexOf("ValidateResult>") + 15;
	    if (end == -1)
	    {
	    	System.err.println("PENG 2");
	      return;
	    }

	    String validateResponse = data.substring(begin, end);

	    XKMSContextHolder tmpXKMSContextHolder = XKMSContextHolder.getSingleton();
	    Unmarshaller u = tmpXKMSContextHolder.getUnmarshaller();
	    JAXBElement<ValidateResultType> tmpResponseObject = (JAXBElement<ValidateResultType>) u.unmarshal(new StringReader(validateResponse));
	    System.err.println(tmpResponseObject.getValue().getId());

	    Init.init();
  	  	checkSignature(data, null);
	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
}
}
