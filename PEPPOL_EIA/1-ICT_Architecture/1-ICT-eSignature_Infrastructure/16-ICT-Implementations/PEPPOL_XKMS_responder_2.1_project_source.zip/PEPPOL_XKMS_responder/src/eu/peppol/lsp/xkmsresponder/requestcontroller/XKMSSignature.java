/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.tm_xml.xmlschema.common.ISOCountryCodeType;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.dto.SignatureTokenDto;


/**
 * Class for generating XML signatures.
 * @author horstmann
 * 
*/
public class XKMSSignature
{
  private static final Logger LOG = Logger.getLogger(XKMSSignature.class.getName());

  private static DocumentBuilderFactory dbf;

  private static TransformerFactory factory = TransformerFactory.newInstance();

  private static String algo_id_signature_rsa_sha = XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA256;

  private static String algo_id_digest = "http://www.w3.org/2001/04/xmlenc#sha256";

  private static PrivateKey pkey = null;

  private static X509Certificate sigCert = null;

  private static String countryCode = "UNKNOWN";

  static
  {
    dbf = DocumentBuilderFactory.newInstance();
    dbf.setNamespaceAware(true);
  }

  public static byte[] signXKMS(InputStream _response, String sigUri)
        throws ParserConfigurationException, SAXException, IOException, XMLSecurityException,
        TransformerException
  {
    LOG.fine("\n(start) signXKMSResponse " + sigUri + "\n");

    DocumentBuilder db = dbf.newDocumentBuilder();
    Document doc = db.parse(_response);

    XMLSignature sig = new XMLSignature(doc, sigUri, algo_id_signature_rsa_sha, Canonicalizer.ALGO_ID_C14N_EXCL_WITH_COMMENTS);
    doc.getDocumentElement().insertBefore(sig.getElement(), doc.getDocumentElement().getFirstChild());

    Transforms transforms = new Transforms(doc);
    transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);
    transforms.addTransform(Transforms.TRANSFORM_C14N_EXCL_WITH_COMMENTS);
    sig.addDocument("#" + sigUri, transforms, algo_id_digest);
    sig.addKeyInfo(sigCert);
    sig.sign(pkey);

    ByteArrayOutputStream outs = new ByteArrayOutputStream();
    Transformer transformer = factory.newTransformer();
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
    Source source = new DOMSource(doc);
    Result result = new StreamResult(outs);
    transformer.transform(source, result);
    outs.close();

    return outs.toByteArray();
  }

  public static String getCountryCode()
  {
	  return countryCode;
  }

  public static void reloadSignatureKey(SignatureTokenDto tmpSignatureTokenDto) throws Exception
  {
//    SignatureTokenDto tmpSignatureTokenDto = SignatureTokenDelegate.getInstance().findTheOneAndOnly();

    if ((tmpSignatureTokenDto != null) && (tmpSignatureTokenDto.getData() != null)
        && (tmpSignatureTokenDto.getAlias() != null) && (tmpSignatureTokenDto.getAlias().trim().length() > 0))
    {
      LOG.fine("getXkmsStream() creating and applying signature from alias "
                + tmpSignatureTokenDto.getAlias());

      KeyStore keyStore = KeyStore.getInstance("PKCS12", ResponderHelper.SECURITYPROVIDER);
      keyStore.load(new ByteArrayInputStream(tmpSignatureTokenDto.getData()),
                    tmpSignatureTokenDto.getPin().toCharArray());
      pkey =
            (RSAPrivateKey) keyStore.getKey(tmpSignatureTokenDto.getAlias(),
                                            tmpSignatureTokenDto.getPin().toCharArray());
      sigCert = (X509Certificate) keyStore.getCertificate(tmpSignatureTokenDto.getAlias());

      if ((pkey == null) || (sigCert == null))
      {
        throw new Exception("No Keys found in KeyStore");
      }

      if (System.getProperty("peppol.xkmsresponder.country") != null)
    	  countryCode = System.getProperty("peppol.xkmsresponder.country");
      else
      {
	      ISOCountryCodeType icct = MessageExtensionHandler.getCountry(sigCert);
	      countryCode = icct == null ? "UNKNOWN" : icct.toString();
      }

      return;
    }

    // Signature disabled
    pkey = null;
    sigCert = null;
  }

  public static boolean isSignatureEnabled()
  {
    LOG.fine("isSignatureEnabled: " + (pkey != null));

    return (pkey != null);
  }

}
