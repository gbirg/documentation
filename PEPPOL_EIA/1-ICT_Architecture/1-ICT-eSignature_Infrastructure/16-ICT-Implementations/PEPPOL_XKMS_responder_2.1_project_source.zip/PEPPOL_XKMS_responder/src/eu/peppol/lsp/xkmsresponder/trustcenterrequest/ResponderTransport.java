/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.CommunicationException;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ProxyDto;


/**
 * Helper class for transport issues.
 *
 * @author jens
 * @author horstmann
 * @author buengener
 * 
*/
public class ResponderTransport
{
  private static final Logger LOG = Logger.getLogger(ResponderTransport.class.getName());

  private static ProxyDto sProxyDto = new ProxyDto();

  private static ProxyDto currentProxyConfig = null;

  private static Object proxyMutex = new Object();

  private static Hashtable<String, String> ldapEnv;

  public static final String[][] HTTP_SOAP_HEADER = {
	  {"Content-Type", "text/xml; charset=utf-8"},
	  {"SOAPAction", ""},
	  {"Accept", "application/soap+xml, application/dime, multipart/related, text/*"},
	  {"User-Agent", "PeppolXKMSResponder"}};

  public static final String[][] HTTP_OCSP_HEADER = {
	  {"Content-Type", "application/ocsp-request"},
	  {"Accept", "application/ocsp-response"}};

  private ResponderTransport()
  {
    // just to make the constructor private
  }

  public static byte[] sendHTTPRequest(String urlString, byte[] request, String[][] header) throws IOException
  {
	    byte[] resp = null;
	    HttpURLConnection con;
	    InputStream in = null;
	    OutputStream out = null;

	    try
	    {
	    	java.net.URL url = new java.net.URL(urlString);

	    	ProxyDto proxyDto = Configuration.getProxyDto();
	    	Proxy proxy;
	    	if (proxyDto != null && proxyDto.getProxyHost().length() > 0 &&  !proxyDto.getNonProxyHosts().contains(url.getHost()))
	    		proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyDto.getProxyHost(), proxyDto.getProxyPort()));
	    	else
	    		proxy = Proxy.NO_PROXY;

//	    	LOG.severe("Send request to " + urlString + " via proxy " + proxy);

	    	if (LOG.isLoggable(Level.FINE) && request != null)
	    	{
	    		LOG.fine("Send request to " + urlString + " via proxy " + proxy);
	    		LOG.fine("Request content " + new String(request));
	    	}

	    	int timeout = proxyDto.getTimeout().intValue() * 1000;
	    	con = (HttpURLConnection) url.openConnection(proxy);
	    	con.setConnectTimeout(timeout);
	    	con.setReadTimeout(timeout);
	    	if (request != null)
	    	{
		    	for (String[] entry : header)
		    		con.setRequestProperty(entry[0], entry[1]);
		    	con.setDoOutput(true);
		    	out = con.getOutputStream();
		    	out.write(request);
		    	out.close();
	    	}
	    	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    	in = con.getInputStream();
	    	byte[] tmp = new byte[1024];
	    	int i;
	    	while ((i = in.read(tmp)) > -1)
	    		baos.write(tmp, 0, i);
	    	in.close();
	    	baos.close();
	    	resp = baos.toByteArray();
	      }
	      finally
	      {
	    	  try
	    	  {
	    		  if (out != null)
	    			  out.close();
	    	  }
	    	  catch (IOException ioe)
	    	  {
	    		LOG.warning("Failed to close HTTP request stream.");
	    	  }
	    	  try
	    	  {
	    		  if (in != null)
	    			  in.close();
	    	  }
	    	  catch (IOException ioe)
	    	  {
	    		  LOG.warning("Failed to close HTTP response stream.");
	    	  }
	      }

//	      LOG.severe("Antwort : " + new String(resp));

	      if (LOG.isLoggable(Level.FINE))
	      {
		      LOG.fine("###############");
		      LOG.fine("Response : " + new String(resp));
		      LOG.fine("###############");
	      }
	      return resp;
  }

  public static NamingEnumeration<SearchResult> sendLDAPRequest(String url, Hashtable<String, String> env,
                                                                String filter, String searchbase,
                                                                String attribute, ProxyDto proxyDto)
        throws Exception
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine(searchbase
                + " attribute=" + attribute);
    }

    NamingEnumeration<SearchResult> response = null;

    try
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("Laenge von env: " + env.size());
      }

      DirContext ctx = new InitialDirContext(env);
      SearchControls constraints = new SearchControls();
      constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
      response = ctx.search(searchbase, filter, constraints);
    }
    catch (CommunicationException ex)
    {
      if (ex.getRootCause() instanceof ConnectException)
      {
        LOG.log(Level.SEVERE, ex.getMessage(), ex.getRootCause());
      }
      else
      {
        LOG.log(Level.SEVERE, ex.getMessage(), ex);
      }

      throw new Exception(ex.getMessage());
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, ex.getMessage(), ex);
      throw new Exception(ex.getMessage());
    }

    return response;
  }

  public static byte[] sendLDAPRequestCRL(String url, Hashtable<String, String> env, String searchbase,
                                          String attribute, ProxyDto proxyDto) throws Exception
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine(" searchbase=" + searchbase + " attribute="  + attribute);
    }

    Attributes response = null;
    byte[] by = null;

    try
    {
      String[] attributeIDs = null;

      if ((attribute != null) && (attribute.length() > 0))
      {
        attributeIDs = new String[1];
        attributeIDs[0] = attribute;
      }
      else
      {
        attributeIDs = new String[2];
        attributeIDs[0] = "certificateRevocationList";
        attributeIDs[1] = "authorityRevocationList";
      }

      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("Laenge von env: " + env.size());
      }

      DirContext ctx = new InitialDirContext(env);
      SearchControls constraints = new SearchControls();
      constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
      response = ctx.getAttributes(searchbase, attributeIDs);

      if (LOG.isLoggable(Level.FINE))
      {
        List<String> tmpAttributeIDs = Arrays.asList(attributeIDs);
        LOG.fine(searchbase
                  + " and attributeIDs " + tmpAttributeIDs + " results in reponse with " + response.size()
                  + " entries");
      }

      Attribute att = null;

      for (String tmpAttributeID : attributeIDs)
      {
        att = response.get(tmpAttributeID);

        if (att != null)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine(tmpAttributeID
                      + " in response: " + att.getID());
          }

          break;
        }

        tmpAttributeID += ";binary";
        att = response.get(tmpAttributeID);

        if (att != null)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine(tmpAttributeID
                      + " in response: " + att.getID());
          }

          break;
        }
      }

      if (att == null)
      {
        LOG.fine("Attribute is null");
        throw new Exception("CertificateRevocationList is null");
      }

      by = (byte[]) att.get();
    }
    catch (CommunicationException ex)
    {
      if (ex.getRootCause() instanceof ConnectException)
      {
        LOG.severe("Cannot download crl " + ex.getRootCause());
      }
      else
      {
        LOG.severe("Error in sendLDAPRequest" + ex);
      }
      throw new Exception(ex.getMessage());
    }
    catch (Exception ex)
    {
      if (LOG.isLoggable(Level.SEVERE))
      {
        LOG.log(Level.SEVERE, "Error in sendLDAPRequest", ex);
      }
      throw ex;
    }

    return by;
  }

}
