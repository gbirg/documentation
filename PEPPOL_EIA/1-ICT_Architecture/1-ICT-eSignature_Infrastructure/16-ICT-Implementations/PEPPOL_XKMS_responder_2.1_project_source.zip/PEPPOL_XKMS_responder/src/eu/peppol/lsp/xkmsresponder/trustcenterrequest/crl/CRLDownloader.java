/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest.crl;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.security.GeneralSecurityException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509CRLEntry;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;

import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DEREnumerated;
import org.bouncycastle.asn1.x509.CRLReason;
import org.bouncycastle.asn1.x509.X509Extensions;

import eu.peppol.lsp.xkmsresponder.certificatepathvalidator.CertificatePathValidatorProcess;
import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.Constants;
import eu.peppol.lsp.xkmsresponder.common.PrincipalParser;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.CRLDownloadDelegate;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CRLDownloadDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CRLEntryDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ProxyDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodCrlDto;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;

/**
 * This class performs parallelized update and download of CRLs..
 * @author buengener
 *
 * 
*/

public class CRLDownloader extends Thread
{
  private static final Logger LOG = Logger.getLogger(CRLDownloader.class.getName());

  private static Vector<String> inProcess = new Vector<String>();

  private static final long serialVersionUID = 6746465353563L;

  private static String aLocalHostAddress = "";

  static
  {
    try
    {
      aLocalHostAddress = InetAddress.getLocalHost().getHostAddress();
    }
    catch (UnknownHostException ex)
    {
      LOG.log(Level.SEVERE, "Can not get IP address of local host. Must stop CRLDownload", ex);
    }
  }

  private static CertificateFactory certificateFactory;

  private ValMethodCrlDto valMethodCrlDto;


  public CRLDownloader(ValMethodCrlDto valMethodCrlDto)
  {
	this.valMethodCrlDto = valMethodCrlDto;
  }

  private static CertificateFactory getCertificateFactory()
  {
    if (certificateFactory != null)
    {
      return certificateFactory;
    }
    try
    {
      certificateFactory = CertificateFactory.getInstance("X509", ResponderHelper.SECURITYPROVIDER);
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Could not create CertificateFactory", ex);
    }
    return certificateFactory;
  }

  // Only called on startup
  public static synchronized void loadCRL(String name)
  {
	  LOG.fine("Load CRL from file " + name);
	  File file = null;
	  try
	  {
		  file = new File(Configuration.CONF_DIR +  URLEncoder.encode(name + ".crl", "UTF-8"));
	  }
	  catch (UnsupportedEncodingException uee)
	  {
		  // impossible
	  }

      if (file.exists())
      {
    	  try
    	  {
	    	  CRLDownloadDto tmpCRLDownloadDto = new CRLDownloadDto();
	    	  tmpCRLDownloadDto.setName(name);
	          tmpCRLDownloadDto.setErrorCount(Integer.valueOf(0));

	          FileInputStream fis = new FileInputStream(file);
	          if (file.length() > Integer.MAX_VALUE)
	        	  throw new IOException("CRL size in file " + file.getPath() + " exceeds max integer value.");
	          byte[] tmpCrlFile = new byte[(int)file.length()];
	          fis.read(tmpCrlFile);
	          fis.close();

	          tmpCRLDownloadDto.setLatestCRL(tmpCrlFile);
	          tmpCRLDownloadDto.setLastCheck(new Date(file.lastModified()));

	          X509CRL tmpX509CRL = parseCRL(tmpCrlFile, name);

          // local file system is trusted
	      //      checkSignature(tmpX509CRL, tmpValMethodName);

	          tmpCRLDownloadDto.setThisUpdate(new Date()); // just to make storeCRL load the entries
	          tmpCRLDownloadDto.setNextUpdate(tmpX509CRL.getNextUpdate());

	          storeCRL(tmpX509CRL, tmpCRLDownloadDto);

	          tmpCRLDownloadDto.setErrorCount(Integer.valueOf(0));
	          tmpCRLDownloadDto.setLastError("");
    	  }
    	  catch (Exception e)
    	  {
    		  LOG.log(Level.SEVERE, "Error loading CRL " + name + " from file system." , e);
    	  }
      }
  }

  public void run()
  {
    String tmpValMethodName = valMethodCrlDto.getName();

    LOG.fine("onMessage() " + tmpValMethodName + ": started");

    if (inProcess.contains(tmpValMethodName))
    {
      LOG.fine("onMessage() " + tmpValMethodName + ": is already processing. Doing nothing");
      return;
    }

    inProcess.add(tmpValMethodName);

    CRLDownloadDto tmpCRLDownloadDto = null;
    tmpCRLDownloadDto = CRLDownloadDelegate.getInstance().findByName(tmpValMethodName);
    if (tmpCRLDownloadDto == null)
    {
      LOG.fine("onMessage() " + tmpValMethodName + ": CRLDownload not found. Creating new");
      tmpCRLDownloadDto = new CRLDownloadDto();
      tmpCRLDownloadDto.setName(tmpValMethodName);
      tmpCRLDownloadDto.setErrorCount(Integer.valueOf(0));
      try
      {
        CRLDownloadDelegate.getInstance().updateCRL(tmpCRLDownloadDto);
      }
      catch (Exception e)
      {
        LOG.severe("onMessage() " + tmpValMethodName + ": cannot create CRLDownloadDto");
        return;
      }
    }

/*
 * @todo: Cluster issues
*/
    // execute Download, update CRLDownload
    try
    {
      executeDownload(valMethodCrlDto, tmpCRLDownloadDto);
    }
    catch (Exception e)
    {
      LOG.log(Level.SEVERE, "onMessage()", e);
    }
    finally
    {
      inProcess.remove(tmpValMethodName);
    }
  }

  private void executeDownload(ValMethodCrlDto tmpValMethodCrlDto, CRLDownloadDto inpCRLDownloadDto)
  {
    CRLDownloadDto retCRLDownloadDto = new CRLDownloadDto(); //(CRLDownloadDto) inpCRLDownloadDto.clone();
    retCRLDownloadDto.setErrorCount(inpCRLDownloadDto.getErrorCount());
//    retCRLDownloadDto.setIssuerList(inpCRLDownloadDto.getIssuerList());
    retCRLDownloadDto.setLastError(inpCRLDownloadDto.getLastError());
    retCRLDownloadDto.setLatestCRL(inpCRLDownloadDto.getLatestCRL());
    retCRLDownloadDto.setName(inpCRLDownloadDto.getName());
    retCRLDownloadDto.setNextUpdate(inpCRLDownloadDto.getNextUpdate());
    retCRLDownloadDto.setThisUpdate(inpCRLDownloadDto.getThisUpdate());

    String tmpValMethodName = inpCRLDownloadDto.getName();

    try
    {
      retCRLDownloadDto.setLastCheck(new Date());
      LOG.fine("Set lastcheck for " + tmpValMethodName + " to " + DateFormat.getDateTimeInstance().format(retCRLDownloadDto.getLastCheck())
    		  + "\n" + retCRLDownloadDto.hashCode());

      byte[] tmpCrlFile = getCRL(tmpValMethodCrlDto);
      retCRLDownloadDto.setLatestCRL(tmpCrlFile);

      X509CRL tmpX509CRL = parseCRL(tmpCrlFile, tmpValMethodName);

      checkSignature(tmpX509CRL, tmpValMethodName);

	  File f = new File(Configuration.CONF_DIR + "/" + URLEncoder.encode(tmpValMethodName + ".crl", "UTF-8"));

	  if (storeCRL(tmpX509CRL, retCRLDownloadDto))
	  {
	      try
	      {
	    	  FileOutputStream fos = new FileOutputStream(f);
	    	  fos.write(tmpCrlFile);
	    	  fos.close();
	      }
	      catch (IOException e)
	      {
	    	  LOG.log(Level.SEVERE, "Error writing CRL " + tmpValMethodName + " to file system.", e);
	      }
	  }

	  f.setLastModified(new Date().getTime());
	  retCRLDownloadDto.setErrorCount(Integer.valueOf(0));
      retCRLDownloadDto.setLastError("");
    }
    catch (Exception ex)
    {
      String tmpLastError = "";
      String tmpMessage = ex.getMessage();
      if (tmpMessage != null)
      {
        tmpLastError = tmpMessage.substring(0, Math.min(tmpMessage.length(), 250));
      }
      else
      {
        tmpLastError = ex.toString();
      }
      retCRLDownloadDto.setLastError(tmpLastError);
      retCRLDownloadDto.setErrorCount(Integer.valueOf(retCRLDownloadDto.getErrorCount().intValue() + 1));

      LOG.log(Level.FINE, "executeDownload() " + tmpValMethodName + ": Error occured ", ex);

      CRLDownloadDelegate.getInstance().updateCRL(retCRLDownloadDto);

    }

    if (((retCRLDownloadDto.getNextUpdate() == null) || (retCRLDownloadDto.getNextUpdate().before(new Date())))
        && (!tmpValMethodCrlDto.getIgnoreNextUpdate()))
    {

    	LOG.severe("CRLDownload-File from " + tmpValMethodCrlDto.getUrl()
                                                            + " could not be downloaded an is run off");
    }

    LOG.fine("executeDownload() " + tmpValMethodName + ": ending");
  }

  private byte[] getCRL(ValMethodCrlDto inpValMethodCrlDto) throws Exception
  {
    String tmpValMethodName = inpValMethodCrlDto.getName();
    String tmpUrl = inpValMethodCrlDto.getUrl();

    LOG.fine("getCRL() " + tmpValMethodName + ": Download CRL from " + tmpUrl);

    ProxyDto tmpProxyDto = null;
    try
    {
      tmpProxyDto = Configuration.getProxyDto();
    }
    catch (Exception e)
    {
      tmpProxyDto = new ProxyDto();
    }

    try
    {
      if (Constants.ATT_VM_CRL_SUBTYPE_HTTP.equals(inpValMethodCrlDto.getSubType()))
      {
        int tmpTimeOut = tmpProxyDto.getTimeout().intValue() * 1000; // convert seconds to millis
        return ResponderTransport.sendHTTPRequest(tmpUrl, null, null);
      }

      Hashtable<String, String> env = new Hashtable<String, String>();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
      env.put(Context.SECURITY_AUTHENTICATION, "none");
      env.put(Context.PROVIDER_URL, tmpUrl);


      return ResponderTransport.sendLDAPRequestCRL(tmpUrl, env, inpValMethodCrlDto.getSearchbase(),
                                               inpValMethodCrlDto.getAttribute(), tmpProxyDto);
    }

    catch (Exception ex)
    {
      LOG.severe("getCRL() " + tmpValMethodName + ": Error get CRL from URL " + tmpUrl + ": " + ex);
      throw new Exception("There was a problem while download the CRL: " + ex);
    }
  }

  private static boolean storeCRL(X509CRL inpX509CRL, CRLDownloadDto refCRLDownloadDto) throws Exception
  {

	boolean ret;
    String tmpValMethodName = refCRLDownloadDto.getName();

    LOG.fine("storeCRL() " + tmpValMethodName + ": start");

    Date tmpOldCrlThisUpdate = refCRLDownloadDto.getThisUpdate();
    Date tmpOldCrlNextUpdate = refCRLDownloadDto.getNextUpdate();
    LOG.fine("storeCRL() " + tmpValMethodName + ": Value in CRL ThisUpdate: " + tmpOldCrlThisUpdate);
    LOG.fine("storeCRL() " + tmpValMethodName + ": Value in CRL NextUpdate: " + tmpOldCrlNextUpdate);

    Date tmpNewCrlThisUpdate = inpX509CRL.getThisUpdate();
    Date tmpNewCrlNextUpdate = inpX509CRL.getNextUpdate();

    if ((tmpNewCrlThisUpdate != null) && (tmpNewCrlThisUpdate.equals(tmpOldCrlThisUpdate)))
    {
      LOG.fine("storeCRL() " + tmpValMethodName + ": No new CRLDownload found. Update Date = "
                + tmpNewCrlThisUpdate.toString());
      ret = false;
    }
    else
    {
      refCRLDownloadDto.setThisUpdate(tmpNewCrlThisUpdate);

      if (tmpNewCrlNextUpdate != null)
      {
        LOG.fine("storeCRL() " + tmpValMethodName + ": Value in CRLDownload.getNextUpdate: "
                  + tmpNewCrlNextUpdate.toString());
      }

      if (tmpNewCrlNextUpdate != null)
      {
        refCRLDownloadDto.setNextUpdate(tmpNewCrlNextUpdate);
      }
      else
      {
        refCRLDownloadDto.setNextUpdate(null);
      }
      refCRLDownloadDto.setLastError("");

      Hashtable<String, Hashtable<BigInteger, CRLEntryDto>> retCRLIssuer = new Hashtable<String, Hashtable<BigInteger, CRLEntryDto>>();
      List<String> issuers = new ArrayList<String>();

      if (inpX509CRL.getRevokedCertificates() != null)
      {

        Set<? extends X509CRLEntry> tmpEntries = inpX509CRL.getRevokedCertificates();

        String issuerDN;
        Hashtable<BigInteger, CRLEntryDto> sm;

        if (tmpEntries != null)
        {
          // Jetzt die CRLEntries auswerten
          for ( X509CRLEntry tmpEntry : tmpEntries )
          {
            if (tmpEntry.getCertificateIssuer() == null)
              issuerDN = new PrincipalParser(inpX509CRL.getIssuerX500Principal()).toString();
            else
              issuerDN = new PrincipalParser(tmpEntry.getCertificateIssuer()).toString();
            if (!retCRLIssuer.containsKey(issuerDN))
            {
              sm = new Hashtable<BigInteger, CRLEntryDto>();
              retCRLIssuer.put(issuerDN, sm);
            }
            else
              sm = retCRLIssuer.get(issuerDN);
            // TODO: Hier muessen Wir noch CRLReason und HoldInstruction auswerten koennen.
            if (!issuers.contains(issuerDN))
            	issuers.add(issuerDN);
            CRLEntryDto tmpCRLEntryDto = new CRLEntryDto(issuerDN, tmpEntry.getSerialNumber());
            tmpCRLEntryDto.setReasonCode(getReason(tmpEntry));
            tmpCRLEntryDto.setRevocationDate(tmpEntry.getRevocationDate());
            sm.put(tmpCRLEntryDto.getSerialNo(), tmpCRLEntryDto);
          }
        }
      }
//      refCRLDownloadDto.setIssuerList(issuers);
      CRLDownloadDelegate.getInstance().updateCRLEntries(refCRLDownloadDto, retCRLIssuer);
      ret = true;
    }

    CRLDownloadDelegate.getInstance().updateCRL(refCRLDownloadDto);
    LOG.fine("storeCRL() " + tmpValMethodName + ": CRL stored successfully");

    return ret;
  }

  public static X509CRL parseCRL(byte[] inpCrlFile, String tmpValMethodName) throws Exception
  {

    X509CRL retX509CRL = null;

    try
    {
      retX509CRL = (X509CRL) getCertificateFactory().generateCRL(new ByteArrayInputStream(inpCrlFile));
    }
    catch (Exception ex)
    {
      LOG.severe("storeCRL() " + tmpValMethodName + ": The downloaded CRL could not be parsed");
      throw new Exception("The downloaded CRL could not be parsed: " + ex);
    }

    if (retX509CRL == null)
    {
      LOG.severe("storeCRL() " + tmpValMethodName
                + ": Can not store CRLDownload-Entry, because the answer contains no CRL");
      throw new Exception("Can not store CRLDownload-Entry, because the answer contains no CRL");
    }

    if (retX509CRL.getExtensionValue("2.5.29.27") != null)
    {
      // RE13401=RE13401, The configured CRL is a Delta-CRL which is not supported.
      LOG.severe("storeCRL() " + tmpValMethodName + ": The CRL is a Delta-CRL which is not supported");
      throw new Exception("The CRL is a Delta-CRL which is not supported");
    }

    return retX509CRL;
  }

  private static Integer getReason(X509CRLEntry ent) throws IOException
  {
    Integer tmpReason = Integer.valueOf(0);
    byte[] extension = ent.getExtensionValue(X509Extensions.ReasonCode.getId());

    if (extension != null)
    {
      ASN1OctetString localASN1OctetString = (ASN1OctetString)ASN1Object.fromByteArray(extension);
      DEREnumerated encodedReason = (DEREnumerated)ASN1Object.fromByteArray(localASN1OctetString.getOctets());
      CRLReason reason = new CRLReason(encodedReason);
      tmpReason = Integer.valueOf(reason.getValue().intValue());
    }
    return tmpReason;
  }

  private void checkSignature(X509CRL inpCRL, String inpValMethodName) throws Exception
  {
    LOG.fine("checkSignature() " + inpValMethodName + ": start");

    String tmpIssuerDN = ResponderHelper.getIssuerDN(inpCRL);
    LOG.fine("checkSignature() " + inpValMethodName + ": retrieving certificates for IssuerDN "
              + tmpIssuerDN);

    CertificateDto tmpSignerCert = getCRLSignerCertificate(inpCRL, inpValMethodName);

    int result = checkCertificate(tmpSignerCert);

    if (result != CertificatevalidatorResult.STATUS_VALID)
    {
      if (result == CertificatevalidatorResult.STATUS_INVALID)
      {
        LOG.severe("checkSignature() " + inpValMethodName + ": CRLSignerCertificate is invalid");
        throw new GeneralSecurityException("CRLSigner-Certificate is invalid");
      }

      LOG.severe("checkSignature() " + inpValMethodName + ": CRLSignerCertificate is indeterminate");
      throw new GeneralSecurityException("CRLSigner-Certificate is indeterminate");
    }

    LOG.fine("checkSignature() " + inpValMethodName + ": CRLSignerCertificate is valid");
  }

  private CertificateDto getCRLSignerCertificate(X509CRL inpCRL, String tmpValMethodName) throws Exception
  {
    String tmpIssuerDN = ResponderHelper.getIssuerDN(inpCRL);
    String tmpKeyId = ResponderHelper.getAuthorityKeyIdentifier(inpCRL);

    Collection<CertificateDto> tmpCertList = null;

    tmpCertList = Configuration.getIssuerCertificateBySubjectDNAndSubjectKeyIdentifier(tmpIssuerDN, tmpKeyId);
    LOG.fine("getCRLSignerCertificate() " + tmpValMethodName + ": Found " + tmpCertList.size()
              + " certificates for IssuerDN " + tmpIssuerDN + " with subject keyID " + tmpKeyId);

    ArrayList<CertificateDto> tmpSignerCerts = new ArrayList<CertificateDto>();

    for (CertificateDto tmpCertificateDto : tmpCertList)
    {
      LOG.fine("getCRLSignerCertificate() " + tmpValMethodName + ": Found certificate with SubjectDN "
                + tmpCertificateDto.getSubjectDN() + " for IssuerDN " + tmpIssuerDN);

      if (tmpCertificateDto.getX509Certificate().getKeyUsage()[6] == true)
      {
        tmpSignerCerts.add(tmpCertificateDto);
      }
    }

    LOG.fine("getCRLSignerCertificate() " + tmpValMethodName + ": Found " + tmpSignerCerts.size()
              + " crl-signer-certificates for IssuerDN " + tmpIssuerDN);

    if (tmpSignerCerts.size() == 0)
    {
      throw new Exception("getCRLSignerCertificate() " + tmpValMethodName
                          + ": Could not find signer certificate for IssuerDN " + tmpIssuerDN);
    }

    CertificateDto retSignerCert = null;

    for (CertificateDto tmpSignerCert : tmpSignerCerts)
    {
      try
      {
        inpCRL.verify(tmpSignerCert.getX509Certificate().getPublicKey());
        retSignerCert = tmpSignerCert;

        break;
      }
      catch (Exception ex)
      {
        LOG.log(Level.FINE, "getCRLSignerCertificate() " + tmpValMethodName + ": CRL is not signed with: "
                  + tmpSignerCert, ex);
      }
    }

    if (retSignerCert == null)
    {
      LOG.severe("getCRLSignerCertificate() " + tmpValMethodName
                + ": Could not find valid signer Certificate for IssuerDN " + tmpIssuerDN);
      throw new Exception("getCRLSignerCertificate() " + tmpValMethodName
                          + ": Could not find valid signer Certificate for IssuerDN " + tmpIssuerDN);
    }

    LOG.fine("getCRLSignerCertificate() " + tmpValMethodName + ": CRL was signed with SubjectDN "
              + retSignerCert.getSubjectDN() + " and IssuerDN " + tmpIssuerDN);
    return retSignerCert;
  }

  private int checkCertificate(CertificateDto inpCertificateDto)
  {
    CPVRequest cpvReq = new CPVRequest();

    try
    {
      cpvReq.addCertifcate(inpCertificateDto.getX509Certificate().getEncoded());
      CPVResponse cPVResponse = CertificatePathValidatorProcess.execute(cpvReq);
      return cPVResponse.getResult().intValue();
    }
    catch (Exception ex1)
    {
      LOG.log(Level.SEVERE, "checkCertificate() " + inpCertificateDto.getSubjectDN() + ": Error ", ex1);

      return CertificatevalidatorResult.STATUS_INDETERMINATE;
    }
  }


}
