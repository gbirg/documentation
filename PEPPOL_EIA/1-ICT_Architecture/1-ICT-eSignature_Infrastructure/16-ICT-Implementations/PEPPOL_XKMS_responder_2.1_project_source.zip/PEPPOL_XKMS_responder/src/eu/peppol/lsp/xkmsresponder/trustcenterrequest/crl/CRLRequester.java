/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest.crl;

import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvCRLResult;
import eu.peppol.lsp.xkmsresponder.common.PrincipalParser;
import eu.peppol.lsp.xkmsresponder.configuration.CRLDownloadDelegate;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CRLDownloadDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CRLEntryDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodCrlDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.xkms.TranslationTable;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;


/**
 * This class checks if a Certificate is revoked.
 * The certificate is checked against the map in the {@link CRLDownloadDelegate}
 * which contains all known CRLDownload-Entrys.
 * @author mho
 * @author buengener
 * @version $Revision: 1.16 $
 * 
*/
public class CRLRequester
{
  private static final Logger LOG = Logger.getLogger(CRLRequester.class.getName());

  private CRLRequester()
  {
    // just to make the constructor private
  }

  /**
   * Process CRLDownload check request.
   *
   * @param issuer Issuer Certificate
   * @param user User Certificate
   * @param validateMethod Describes how to validate the Certificate
   */
  public static CvCRLResult doRequest(final X509Certificate issuer, final X509Certificate user,
                                      final ValMethodCrlDto validateMethod)
        throws IllegalArgumentException, Exception
  {
    if (issuer == null)
    {
      throw new IllegalArgumentException("Param issuer can't be null");
    }

    if (user == null)
    {
      throw new IllegalArgumentException("Param user can't be null");
    }

    if (validateMethod == null)
    {
      throw new IllegalArgumentException("Param validateMethod can't be null");
    }

    String tmpValMethodName = validateMethod.getName();
    LOG.fine("doRequest(" + tmpValMethodName + ") start");

    CvCRLResult cvCRLResult = new CvCRLResult(user);
    cvCRLResult.setValidateScheme(ValMethodType.CRL);

    CRLDownloadDto tmpCRLDownloadDto = null;

    tmpCRLDownloadDto = CRLDownloadDelegate.getInstance().findByName(tmpValMethodName);

    if ((tmpCRLDownloadDto == null) || (tmpCRLDownloadDto.getThisUpdate() == null))
    {
      LOG.fine("doRequest(" + tmpValMethodName + ") No CRL found");
      cvCRLResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      cvCRLResult.setErrorCode(XKMSConstants.ErrorExtension_TrustCenterNotReachable);
      cvCRLResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
      logResult(cvCRLResult, null, tmpValMethodName);
      return cvCRLResult;
    }

    cvCRLResult.setX509Crl(tmpCRLDownloadDto.getLatestCRL());

    Date nextUpdate = computeCrlNextUpdate(validateMethod, tmpCRLDownloadDto);

    if (!nextUpdate.after(new Date()))
    {
      LOG.fine("doRequest(" + tmpValMethodName + ") CRL was outside Valid-Interval");

      cvCRLResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      cvCRLResult.setErrorCode(XKMSConstants.ErrorExtension_TrustCenterNotReachable);
      cvCRLResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
      logResult(cvCRLResult, null, tmpValMethodName);
      return cvCRLResult;
    }

    LOG.fine("doRequest(" + tmpValMethodName + ") CRL was inside Valid-Interval");
    CRLEntryDto tmpCRLEntryDto = null;
    try
    {
	    tmpCRLEntryDto =
	    	CRLDownloadDelegate.getInstance().findRevoked(
	    			new PrincipalParser(user.getIssuerX500Principal()).toString(),
	    			user.getSerialNumber());

	    if (tmpCRLEntryDto == null)
	    {
	      // Certificate is not revoked.
	      LOG.fine("doRequest(" + tmpValMethodName + ") CRLEntryDto not found");
	      cvCRLResult.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
	      cvCRLResult.setStatus(CertificatevalidatorResult.STATUS_VALID);
	    }
	    else
	    {
		    LOG.fine("doRequest(" + tmpValMethodName + ") CRLEntryDto found");
		    cvCRLResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
		    cvCRLResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
		    cvCRLResult.setRevokationTime(tmpCRLEntryDto.getRevocationDate());
		    cvCRLResult.setRevokationReason(tmpCRLEntryDto.getReasonCode().intValue());
	    }
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "doRequest(" + tmpValMethodName + ") CRLEntryDto not found", ex);
      cvCRLResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      cvCRLResult.setErrorCode(XKMSConstants.ErrorExtension_TrustCenterNotReachable);
      cvCRLResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
    }

    logResult(cvCRLResult, tmpCRLEntryDto, tmpValMethodName);

    return cvCRLResult;
  }

  private static void logResult(CvCRLResult inpCvCrlResult, CRLEntryDto inpCrlEntry, String inpValMethodName)
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("** Start Result of " + inpValMethodName);
      LOG.fine("Subject of Certificate: " + inpCvCrlResult.getCertificate().getSubjectDN().getName());
      LOG.fine("Status of Certificate: " + inpCvCrlResult.getStatus());
      LOG.fine("RevocationReason: " + inpCvCrlResult.getRevokationReason());

      StringBuffer tmpValidReasons = new StringBuffer();
      for (Integer tmpValidReason : inpCvCrlResult.getValidReason())
      {
        tmpValidReasons.append(TranslationTable.XKMS_REASON_TABLE.get(tmpValidReason) + "\n");
      }
      LOG.fine("ValidReasons: " + tmpValidReasons.toString());

      StringBuffer tmpIndeterminateReasons = new StringBuffer();
      for (Integer tmpIndeterminateReason : inpCvCrlResult.getIndeterminateReason())
      {
        tmpIndeterminateReasons.append(TranslationTable.XKMS_REASON_TABLE.get(tmpIndeterminateReason) + "\n");
      }
      LOG.fine("IndeterminateReasons: " + tmpIndeterminateReasons.toString());

      StringBuffer tmpInvalidReasons = new StringBuffer();
      for (Integer tmpInvalidReason : inpCvCrlResult.getInvalidReason())
      {
        tmpInvalidReasons.append(TranslationTable.XKMS_REASON_TABLE.get(tmpInvalidReason) + "\n");
      }
      LOG.fine("InvalidReasons: " + tmpInvalidReasons.toString());

      if (inpCrlEntry != null)
      {
        LOG.fine("RevocationReason: " + inpCrlEntry.getReasonCode());
        LOG.fine("Revocation Time: " + inpCrlEntry.getRevocationDate());
      }
      LOG.fine("** End Result of " + inpValMethodName);
    }
  }

  private static Date computeCrlNextUpdate(final ValMethodCrlDto validateMethod, CRLDownloadDto crl)
  {
    Date nextUpdate = null;

    if (crl.getNextUpdate() == null)
    {
      LOG.fine("NextUpdate from CRL is null");
      GregorianCalendar cal = new GregorianCalendar();
      if (validateMethod.getIgnoreNextUpdate())
      {
        LOG.fine("IgnoreNextUpdate from CRL is true. Adding interval " + validateMethod.getIntervall()
                  + " Minutes from CRL");
        cal.add(Calendar.MINUTE, validateMethod.getIntervall().intValue());
      }
      else
      {
        LOG.fine("IgnoreNextUpdate from CRL is false. Adding fix interval of 10 Minutes");
        cal.add(Calendar.MINUTE, 10);
      }
      nextUpdate = cal.getTime();
    }
    else
    {
      nextUpdate = crl.getNextUpdate();
    }
    return nextUpdate;
  }
}
