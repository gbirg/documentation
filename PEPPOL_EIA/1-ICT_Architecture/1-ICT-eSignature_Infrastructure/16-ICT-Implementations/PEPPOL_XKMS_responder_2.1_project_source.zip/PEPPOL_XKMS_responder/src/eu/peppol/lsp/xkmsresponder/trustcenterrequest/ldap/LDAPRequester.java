/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest.ldap;

import java.io.IOException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Hashtable;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.SearchResult;

import org.bouncycastle.asn1.DERObjectIdentifier;

import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvLDAPResult;
import eu.peppol.lsp.xkmsresponder.common.PrincipalParser;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ProxyDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodLdapDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;


/**
 * This class performs LDAP requests.
 * @author horstmann
 * 
*/

public class LDAPRequester
{

  private static final Logger LOG = Logger.getLogger(LDAPRequester.class.getName());

  private static final String LDAP_AUTHENTICATION_SIMPLE = "simple";

  private static final String LDAP_AUTHENTICATION_STRONG = "strong";

  private static CertificateFactory cf;
  static
  {
    try
    {
      cf = CertificateFactory.getInstance("X509", ResponderHelper.SECURITYPROVIDER);
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Could not create CertificateFactory", ex);
    }
  }

  public static CvLDAPResult doRequest(final X509Certificate issuer, final X509Certificate user,
                                       final ValMethodLdapDto validateMethod) throws IllegalArgumentException, IOException
  {
    Vector<String> errorIndicator = new Vector<String>();
    boolean success = true;

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("(start) doRequest(issuer " + issuer.getSubjectDN().getName() + " , user "
                + user.getSubjectDN().getName() + " , ValMethod " + validateMethod.getName() + " )");
    }

    CvLDAPResult cvLDAPResult = new CvLDAPResult(user);
    cvLDAPResult.setValidateScheme(ValMethodType.LDAP);

    if (issuer == null)
    {
      throw new IllegalArgumentException("Param issuer can't be null");
    }

    if (user == null)
    {
      throw new IllegalArgumentException("Param user can't be null");
    }

    if (validateMethod == null)
    {
      throw new IllegalArgumentException("Param pruefmethode can't be null");
    }

    // Hashtable for environmental information
    Hashtable<String, String> env = generateEnviroment(validateMethod);
    String filter = getFilter(validateMethod.getFilter(), user);

    // Security Information
    NamingEnumeration<SearchResult> resp = null;
    boolean responseCheck = false;

    try
    {
      ProxyDto tmpProxyDto = null;
      try
      {
        tmpProxyDto = Configuration.getProxyDto();
      }
      catch (Exception e)
      {
        tmpProxyDto = new ProxyDto();
      }

      resp =
            sendLDAPRequest(validateMethod.getUrl(), env, filter, validateMethod.getSearchbase(),
                            validateMethod.getAttribute(), tmpProxyDto);

      try
      {
        responseCheck = parse(resp, user);
      }
      catch (NamingException ex1)
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.log(Level.SEVERE, "Error while parsing the LDAP-Response", ex1);
        }

        if (!errorIndicator.contains(validateMethod.getName()))
        {
          errorIndicator.add(validateMethod.getName());
        }

        cvLDAPResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
        cvLDAPResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        success = false;
      }
    }
    catch (Exception ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.SEVERE, "Error while sending LDAP-Request", ex);
      }

      if (!errorIndicator.contains(validateMethod.getName()))
      {
        errorIndicator.add(validateMethod.getName());
      }

      success = false;
      cvLDAPResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
      cvLDAPResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);

      return cvLDAPResult;
    }

    if (responseCheck)
    {
      cvLDAPResult.setStatus(CertificatevalidatorResult.STATUS_VALID);
      cvLDAPResult.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    }
    else
    {
      cvLDAPResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
      cvLDAPResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    }

    if (success && errorIndicator.contains(validateMethod.getName()))
    {
      errorIndicator.remove(validateMethod.getName());
    }

    return cvLDAPResult;
  }

  private static Hashtable<String, String> generateEnviroment(ValMethodLdapDto validateMethod)
  {
    Hashtable<String, String> env = new Hashtable<String, String>();

    if ((validateMethod.getAuthenticationType() == null)
        || validateMethod.getAuthenticationType().equalsIgnoreCase(""))
    {
      env.put(Context.SECURITY_AUTHENTICATION, "none");
    }
    else
    {
      env.put(Context.SECURITY_AUTHENTICATION, validateMethod.getAuthenticationType());

      if (validateMethod.getAuthenticationType().equalsIgnoreCase(LDAP_AUTHENTICATION_SIMPLE))
      {
        env.put(Context.SECURITY_PRINCIPAL, validateMethod.getAuthenticationPrincipal());
        env.put(Context.SECURITY_CREDENTIALS, validateMethod.getAuthenticationCredentials());
      }

      if (validateMethod.getAuthenticationType().equalsIgnoreCase(LDAP_AUTHENTICATION_STRONG))
      {
        throw new IllegalArgumentException("Strong Authentication currently not supportet");
      }
    }

    // Specify which class to use for our JNDI Provider
    env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
    // Specify the host and port to use for directory service
    try
    {
      env.put(Context.PROVIDER_URL, validateMethod.getUrl());
    }
    catch (Exception ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.SEVERE, "Error in URL: " + validateMethod.getUrl(), ex);
      }
    }

    return env;
  }

  private static String getFilter(String inpFilter, X509Certificate user) throws IOException
  {
    StringBuffer filter = new StringBuffer();
//    X509CertificateObject obj = null;
    PrincipalParser ppsubject = new PrincipalParser(user.getSubjectX500Principal());

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Value in Filter: " + inpFilter);
    }

    String filterName = inpFilter;

    if (filterName.equalsIgnoreCase("telesecCertificateSerialnumber")
        || filterName.equalsIgnoreCase("serialnumber") || filterName.equalsIgnoreCase("cn")
        || filterName.equalsIgnoreCase("x509subject") || filterName.equalsIgnoreCase("x509SerialNumber"))
    {
      filter.append(filterName + "=");

      if (filterName.equalsIgnoreCase("telesecCertificateSerialnumber"))
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("Append hexifyed serialnumber");
        }

        filter
              .append(ResponderHelper.getTelesecCertificateSerialNumber(user.getSerialNumber().toByteArray(), ""));
      }
      else if (filterName.equalsIgnoreCase("serialNumber") || filterName.equalsIgnoreCase("x509SerialNumber"))
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("Append decimal serialnumber");
        }

        filter.append(user.getSerialNumber());
      }
      else if (filterName.equalsIgnoreCase("x509subject"))
      {
        filter.append(ResponderHelper.getSubjectDN(user));
      }
      else
      {
        String principal = ResponderHelper.getSubjectDN(user);
        int start = principal.indexOf("CN=") + 3;
        int komma = principal.indexOf(",", start);

        if (komma == -1)
        {
          komma = principal.length();
        }

        String cn = principal.substring(start, komma);
        filter.append(cn);
      }
    }
    else
    {
      String[] filtervalues = null;

      byte[] oid = new DERObjectIdentifier(filterName).getEncoded();

      if (ppsubject.getAny(oid) != null)
      {
        filtervalues = new String[]{ppsubject.getAny(oid)};
      }

      if (filtervalues != null)
      {
        for (String tmpElement : filtervalues)
        {
          LOG.fine("Filtervalue: " + tmpElement);
        }

        for (int ta = 0; ta < filtervalues.length; ta++)
        {
          if (ta > 0)
          {
            filter.append(", ");
          }

          //          String filterName = (String) filterlist.get(ti);
          if (filterName.equalsIgnoreCase("mail") && (filtervalues[ta] == null))
          {
            filter.append(filterName + "=");
            filter.append(ppsubject.getEmailAddress());
          }
          else
          {
            filter.append(filterName + "=");
            filter.append(filtervalues[ta]);
          }
        }
      }
      else
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.severe("Filter not found in  certificate");
        }

        throw new IllegalArgumentException("Filter not found in certificate");
      }
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Filter in getFilter: " + filter.toString());
    }

    return filter.toString();
  }

  private static NamingEnumeration<SearchResult> sendLDAPRequest(String uri, Hashtable<String, String> env,
                                                                 String filter, String searchbase,
                                                                 String attribute, ProxyDto proxyDto)
        throws IOException
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("(start) sendLDAPRequest(" + uri + " , _request_ )");
    }

    NamingEnumeration<SearchResult> resp = null;

    if (uri == null)
    {
      throw new IllegalArgumentException("Param url cant be null");
    }


    try
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("vor senden der LDAP-Anfrage");
      }

      resp = ResponderTransport.sendLDAPRequest(uri, env, filter, searchbase, attribute, proxyDto);

      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("nach senden der LDAP-Anfrage");
      }
    }
    catch (final Exception ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.severe("Can't connect to " + uri + " . " + ex.getMessage());
      }

      throw new IOException(ex.getMessage()); // Modulgrenze
    }

    return resp;
  }

  @SuppressWarnings("unchecked")
  public static boolean parse(NamingEnumeration<SearchResult> result, X509Certificate user)
        throws javax.naming.NamingException
  {
    if (result == null)
    {
      LOG.severe("No LDAP-Result found");
      throw new IllegalArgumentException();
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Certificate in parse: " + user.getSubjectDN().toString());
    }

    boolean resu = false;

    try
    {
      LOG.fine("result has more elements ?: " + result.hasMoreElements());

      while (result.hasMoreElements())
      {
        SearchResult res = result.nextElement();

        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("Attributes: " + res.getAttributes().getIDs().toString());
        }

        NamingEnumeration<? extends Attribute> en = res.getAttributes().getAll();
        LOG.fine("NamingEnumeration hasMoreElements ? " + en.hasMoreElements());

        while (en.hasMoreElements())
        {
          Attribute attr = en.nextElement();
          String attributeID = attr.getID();
          LOG.fine("AttributeID: " + attributeID);

          X509Certificate cert = null;

          if (attributeID.equalsIgnoreCase("usercertificate;binary")
              || attributeID.equalsIgnoreCase("cACertificate;binary")
              || attributeID.equalsIgnoreCase("x509userCert;binary"))
          {
            NamingEnumeration<byte[]> certs = (NamingEnumeration<byte[]>) attr.getAll();

            while (certs.hasMore())
            {
              try
              {
                byte[] tmpCertificateBytes = certs.nextElement();
                cert = ResponderHelper.createCertificate(tmpCertificateBytes);
              }
              catch (Exception ex)
              {
                LOG.severe("Received a ldap entry wich contains no certificate");
                continue;
              }

              int r = cert.getSerialNumber().compareTo(user.getSerialNumber());

              if (LOG.isLoggable(Level.FINE))
              {
                LOG
                   .fine("Compare serialnumbers= " + cert.getSerialNumber() + " , " + user.getSerialNumber());
              }

              if (r == 0)
              {
                LOG.fine("LDAPCheck positive");

                return true;
              }

              LOG.fine("LDAPCheck negative");
              resu = false;
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.SEVERE, "An error occured, while parsing the LDAP-Response", ex);
      }

      throw new javax.naming.NamingException();
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Result in parseLDAPResult: " + resu + " for CertificateSubject: "
                + user.getSubjectDN().getName());
    }

    return resu;
  }

}
