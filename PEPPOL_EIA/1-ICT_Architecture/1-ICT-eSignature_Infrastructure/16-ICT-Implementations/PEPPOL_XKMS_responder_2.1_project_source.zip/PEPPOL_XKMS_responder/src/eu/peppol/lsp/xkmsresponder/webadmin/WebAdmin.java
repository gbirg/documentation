/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.webadmin;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.ImportExportHandler;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.requestcontroller.MessageExtensionHandler;


/**
 * Administration servlet. <b>This class is designed for single client access only,</b>
 * all configuration access methods are static.
 *
 * @author buengener
 * 
*/

public class WebAdmin extends HttpServlet
{

	private final static Logger LOG = Logger.getLogger(WebAdmin.class.getName());

	static final String CHARSET = "iso-8859-1";

	private static final String[] ISSUER_HTML_FRAGS = {"<tr><td class=\"midConfigCol\"><a href=\"WebAdmin?issuerName=", // ISSUER
		"\" hreflang=\"en\">&raquo;", // ISSUER
		"</a></td><td class=\"smallConfigCol\">",  // SIGLEVEL
		"</td><td class=\"smallConfigCol\"><div style=\"color:black\" title=\"\">", // VALMETHOD
		"</div></td><td class=\"smallConfigCol\"><a href=\"WebAdmin?issuerName=", // ISSUER
		"&status=change\"><div style=\"color: ", //STATUS
		"</b></div></a></td><td class=\"smallConfigCol\"><input type=\"checkbox\" name=\"deleteIssuer\" value=\"", // ISSUER
		"\"/></td></tr>"};

	private static final String[] CERTIFCATE_ENTRY_HTML_FRAGS = {"<tr><td colspan=\"2\"><a href=\"WebAdmin?", // CERT
		"\" target=\"_blank\">&raquo;", // TA
		"</a></td><td class=\"smallConfigCol\">", // SERNO
		"</td><td class=\"smallConfigCol\">", // VALFROM
		"</td><td class=\"smallConfigCol\">", // VALTO
		"</td><td class=\"smallConfigCol\"><input type=\"checkbox\" name=\"deleteCerts\" value=\"", // TA
		"\"/></td></tr>"};

	private static final String[] CERTIFICATES_LIST_HTML_FRAGS = {"<br><br><table class=\"tab_frame\">"
			+ "<tr><td class=\"smallConfigCol\">", // Title
			"</td></tr><tr><td class=\"smallConfigCol\">", // description
			"</td></tr><tr><td class=\"leftConfigCol\">"
			+ "<form action=\"WebAdmin\" method=\"POST\" enctype=\"multipart/form-data\"><input type=\"submit\" "
			+ "value=\"Add certificate\" /></td><td class=\"midConfigCol\">&nbsp;</td>"
			+ "<td class=\"rigthConfigCol\"><input type=\"file\" name=\"", //newTACertificate
			"\"/></td></form></tr><tr><td>&nbsp;</td></tr><tr><th colspan=\"2\">Common name</th>"
			+ "<th>Serial number</th><th>Valid from</th><th>Valid to</th><th>Delete</th></tr>"
			+ "<tr><td colspan=\"40\"><hr class=\"hline\" /></td></tr>"
			+ "<form action=\"WebAdmin\" method=\"POST\">", // certificate entry list
			"<td class=\"leftConfigCol\"><input type=\"submit\" name=\"", //deleteTAs
			"\" value=\"Delete marked certificates\" /></tr></form></table>"};

	private static String mainHeader, mainIssuer, mainTA, mainFooter;

	private static String issuerHeader, issuerMidsection, issuerFooter;

	static String[] valMethodProperties;

	public void init() throws ServletException
	{
		try
		{
			Configuration.initialize();
			new ConfigData();

			valMethodProperties = new String[ValMethodType.NAMES.length];
			valMethodProperties[ValMethodType.LOCAL_TYPE] = "";
			valMethodProperties[ValMethodType.NONE_TYPE] = "";
			// read main page fragments
			InputStream is = this.getClass().getResourceAsStream("html/xkms_responder.html");
			InputStreamReader isr = new InputStreamReader(is, CHARSET);
			BufferedReader br = new BufferedReader(isr);
			StringBuffer sb = new StringBuffer();
			String line;
			while ((line=br.readLine()).indexOf("${PROPERTIES_LIST}")< 0)
				sb.append(line);
			mainHeader = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine()).indexOf("${ISSUER_LIST}")< 0)
				sb.append(line);
			mainIssuer = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine()).indexOf("${TA_LIST}")< 0)
				sb.append(line);
			mainTA = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine())!=null)
				sb.append(line);
			mainFooter = sb.toString();
			is.close();

			// read issuer detail page fragments
			is = this.getClass().getResourceAsStream("html/issuer_detail.html");
			isr = new InputStreamReader(is, CHARSET);
			br = new BufferedReader(isr);
			sb = new StringBuffer();
			while ((line=br.readLine()).indexOf("${ISSUER_CERTIFICATES}")< 0)
				sb.append(line);
			issuerHeader = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine()).indexOf("${ISSUER_PROPERTIES}")< 0)
				sb.append(line);
			issuerMidsection = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine())!=null)
				sb.append(line);
			issuerFooter = sb.toString();
			is.close();

			// read validation methods fragments
			is = this.getClass().getResourceAsStream("html/valmethod_frags.html");
			isr = new InputStreamReader(is, CHARSET);
			br = new BufferedReader(isr);
			sb = new StringBuffer();
			while ((line=br.readLine()).indexOf("${CRL_PROPERTIES}")< 0)
			{}
			while ((line=br.readLine()).indexOf("${LDAP_PROPERTIES}")< 0)
				sb.append(line);
			valMethodProperties[ValMethodType.CRL_TYPE] = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine()).indexOf("${OCSP_PROPERTIES}")< 0)
				sb.append(line);
			valMethodProperties[ValMethodType.LDAP_TYPE] = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine()).indexOf("${XKMS_PROPERTIES}")< 0)
				sb.append(line);
			valMethodProperties[ValMethodType.OCSP_TYPE] = sb.toString();
			sb = new StringBuffer();
			while ((line=br.readLine())!=null)
				sb.append(line);
			valMethodProperties[ValMethodType.XKMS_TYPE] = sb.toString();
			valMethodProperties[ValMethodType.CRL_LDAP_TYPE] = valMethodProperties[ValMethodType.CRL_TYPE] + valMethodProperties[ValMethodType.LDAP_TYPE];
			br.close();

		}
		catch (IOException ioe)
		{
			throw new ServletException(ioe);
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse rsp) throws ServletException
	{
		PrintWriter pw = null;
		try
		{
			if (LOG.isLoggable(Level.FINE))
				LOG.fine("GET: " + req.getParameterMap());
			rsp.setContentType("text/html");
			rsp.setCharacterEncoding(CHARSET);
			pw = rsp.getWriter();
			Map map = req.getParameterMap();
			if (LOG.isLoggable(Level.FINE))
			{
				Iterator it = map.entrySet().iterator();
				Entry entry;
				while (it.hasNext())
				{
					entry = (Entry)it.next();
					LOG.fine(entry.getKey().toString());
					String[] vals = (String[])entry.getValue();
					for (int i = 0; i < vals.length; i++)
						LOG.fine(vals[i]);
				}

				LOG.fine("ATT: " + req.getAttributeNames());
				LOG.fine("QUERY: " + req.getQueryString());
			}

			if (req.getParameter("issuerName") != null)
			{
				if (req.getParameter("status") != null)
					ConfigData.changeIssuerState(req.getParameter("issuerName"));
				else if (req.getParameter("valmethod") != null)
				{
					writeIssuerPage(pw, req.getParameter("issuerName"), Integer.valueOf(req.getParameter("valmethod")));
					return;
				}
				else
				{
					writeIssuerPage(pw, req.getParameter("issuerName"), -1);
					return;
				}

			}
			else if (req.getParameter("trustedAnchorId") != null)
			{
				pw.write(ConfigData.getTACertDisplay(req.getParameter("trustedAnchorId")));
				return;
			}
			else if (req.getParameter("issuerCertId") != null)
			{
				pw.write(ConfigData.getIssuerCertDisplay(req.getParameter("issuer"), req.getParameter("issuerCertId")));
				return;
			}

			writeMainPage(pw);

		}
		catch (Exception e)
		{
			e.printStackTrace(pw);
			throw new ServletException(e);
		}
		finally
		{
			pw.close();
		}
	}

	public void doPost(HttpServletRequest req, HttpServletResponse rsp) throws ServletException
	{
		PrintWriter pw = null;
		try
		{
			LOG.fine("\nHEADER");
			Enumeration en = req.getHeaderNames();
			String key;
			while (en.hasMoreElements())
			{
				key = (String)en.nextElement();

				LOG.fine(key + ":");
				Enumeration inen = req.getHeaders(key);
				while (inen.hasMoreElements())
					LOG.fine(inen.nextElement().toString());
				LOG.fine("NEXTKEY");

			}
			LOG.fine("\nREST " + req.getParameterMap());
			if (LOG.isLoggable(Level.FINE))
			{
				Map map = req.getParameterMap();
				Iterator it = map.entrySet().iterator();
				Entry entry;
				while (it.hasNext())
				{
					entry = (Entry)it.next();
					LOG.fine(entry.getKey().toString());
					String[] vals = (String[])entry.getValue();
					for (int i = 0; i < vals.length; i++)
					{
						LOG.fine(vals[i]);
					}
				}

				LOG.fine("ATT: " + req.getAttributeNames());
				LOG.fine("QUERY: " + req.getQueryString());
	//			LOG.fine(req.getInputStream().read());
				LOG.fine("END");
			}

			if (req.getParameter("downloadConfigFile") != null)
			{
				try
				{
					rsp.setContentType("application/octet-stream");
					rsp.setCharacterEncoding("UTF-8");
					LOG.fine("START EXPORT");
					OutputStream out = rsp.getOutputStream();
					out.write(ImportExportHandler.exportConfig());
					out.close();
					return;
				}
				catch (Exception e)
				{
					throw new ServletException(e);
				}
			}

			pw = rsp.getWriter();
			rsp.setContentType("text/html");
			rsp.setCharacterEncoding(CHARSET);

			if (req.getParameter("createIssuer") != null)
			{
				String name = req.getParameter("newIssuerName").trim();
				if (name != null && name.length() > 0)
				{
					String newIsuer = ConfigData.createIssuer(name).getName();
					writeIssuerPage(pw, newIsuer, ValMethodType.NONE_TYPE);
					return;
				}
			}

			if (req.getParameter("deleteIssuer") != null)
				ConfigData.deleteIssuers(req.getParameterValues("deleteIssuer"));

			if (req.getParameter("deleteTAs") != null)
				ConfigData.deleteTAs(req.getParameterValues("deleteCerts"));

			if (req.getParameter("deleteIssuerCertificates") != null)
			{
				String[] certs = req.getParameterValues("deleteCerts");
				for (int j = 0; j < certs.length; j++)
					Configuration.removeIssuerCertificateDto(req.getParameter("issuer"), certs[j]);
				writeIssuerPage(pw, req.getParameter("issuer"), -1);
				return;
			}

			if (req.getParameter("applyIssuerProps") != null)
			{
				String issuer = req.getParameter("issuer");
				int valmethod = Integer.parseInt(req.getParameter("valmethod"));
				ConfigData.applyIssuerProps(Configuration.getIssuerDto(issuer), valmethod,
						convertMap(req.getParameterMap()));
				writeIssuerPage(pw, issuer, -1);
				return;
			}

			if (req.getParameter("applyProps") != null)
				ConfigData.applyProps(convertMap(req.getParameterMap()));

			String ct = req.getHeader("content-type");
			if (ct.indexOf("multipart/form-data") > -1)
			{
				Hashtable<String, byte[]> items = readMultiPartFormData(req, ct);
				if (items.containsKey("configFile") && items.get("configFile").length > 0)
				{
					Configuration.loadConfig(items.get("configFile"));
					MessageExtensionHandler.loadTSLs();
					Configuration.storeConfiguration();
				}
				else if (items.containsKey("newTACertificate"))
				{
					ConfigData.addTA(items.get("newTACertificate"));
				}
				else if (items.containsKey("newIssuerCertificate"))
				{
					String issuer = new String(items.get("issuer"), CHARSET);
					ConfigData.addIssuerCertificate(issuer, items.get("newIssuerCertificate"));
					writeIssuerPage(pw, issuer, -1);
					return;
				}
				else if (items.containsKey("newKeystore"))
				{
					ConfigData.loadKeyStore(items.get("newKeystore"), items.get("keystorepwd"));
				}
				else if (items.containsKey("applyIssuerProps"))
				{
					IssuerDto issuer = Configuration.getIssuerDto(new String(items.get("issuer"), CHARSET));
					int valmethod = Integer.parseInt(new String(items.get("valmethod"), CHARSET));
					ConfigData.applyIssuerProps(issuer, valmethod, items);
					writeIssuerPage(pw, issuer.getName(), -1);
					return;
				}
				else if (items.containsKey("applyProps"))
					ConfigData.applyProps(items);
			}

			writeMainPage(pw);

		}
		catch (Exception e)
		{
//			e.printStackTrace(pw);
			throw new ServletException(e);
		}
		finally
		{
			LOG.fine("CLOSE STREAM");
			if (pw != null)
				pw.close();
		}
	}

	private Hashtable<String, byte[]> readMultiPartFormData(HttpServletRequest req, String contentType) throws IOException
	{
		Hashtable<String, byte[]> ret = new Hashtable();
		StringTokenizer st = new StringTokenizer(contentType, ";=");
		String boundary = "";
		while (st.hasMoreElements())
			if (st.nextToken().trim().startsWith("boundary"))
				boundary = st.nextToken();
		LOG.fine("BOUND " + boundary);

		InputStream is = req.getInputStream();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] tmp = new byte[1024];
		int i;
		while ((i=is.read(tmp))>-1)
		{
//			LOG.fine(new String(tmp));
			baos.write(tmp, 0, i);
		}

		byte[] data = baos.toByteArray();
		int index = searchString(data, boundary, 0);
		index = searchString(data, "\r\n", index);
		while (index > -1)
		{
			index = searchString(data, "Content-Disposition", index);
			index = searchString(data, "name=\"", index);
			int start = index;
			index = searchString(data, "\"", index);
			String name = new String(data, start, index-start-1);
			index = searchString(data, "\r\n\r\n", index);
			start = index;
			index = searchString(data, boundary, index);

			byte[] file = new byte[index-start-boundary.length()-4];
			System.arraycopy(data, start, file, 0, file.length);
//			LOG.fine("CONTENT: " + new String(file) + ": END\n\n");

			index = searchString(data, "\r\n", index);

			ret.put(name, file);

		}

		return ret;
	}

	private int searchString(byte[] data, String search, int start)
	{
		int i=start;
		int j=0;
		while (i < data.length && j < search.length())
		{
			while (data[i] != search.charAt(j))
				i++;
			while (j < search.length() && data[i] == search.charAt(j))
			{
				i++;j++;
			}
			if (j < search.length())
			{
				i-=j;
				j = 0;
				i++;
			}
			else
				break;
		}

		if (i >= data.length)
			return -1;

		return i;
	}

	private Hashtable<String, byte[]> convertMap(Map<String, String[]> input) throws UnsupportedEncodingException
	{
		Hashtable<String, byte[]> ret = new Hashtable<String, byte[]>();

		for (Entry<String, String[]> e : input.entrySet())
			ret.put(e.getKey(), e.getValue()[0].getBytes(CHARSET));

		return ret;
	}

	private void writeMainPage(PrintWriter pw) throws IOException, GeneralSecurityException
	{
		pw.println(mainHeader);
		writePropertiesList(pw);
		pw.println(mainIssuer);
		writeIssuerList(pw);
		pw.println(mainTA);
		writeCertificateList(pw, 0, "List of trusted anchors.", "newTACertificate", "deleteTAs", null);
		pw.println(mainFooter);
	}

	private void writeIssuerPage(PrintWriter pw, String issuer, int valMethod) throws IOException
	{
		pw.println(issuerHeader);
		pw.write("<br><h1>" + issuer + "</h1>");
		IssuerDto issdto = Configuration.getIssuerDto(issuer);
		writeCertificateList(pw, 1, "List of issuer certificates.", "newIssuerCertificate", "deleteIssuerCertificates", issdto);
		pw.println(issuerMidsection);
		pw.write("<input type=\"hidden\" name=\"issuer\" value=\"");
		pw.write(issuer);
		pw.write("\"/>");
		if (valMethod < 0)
			valMethod = issdto.getValMethod().ordinal();
		pw.write("<input type=\"hidden\" name=\"valmethod\" value=\"" + valMethod + "\"/>");
		writeIssuerAtts(pw, issdto.getTSLIdentifier(), issdto.getAlgPolicyIdentifier());
		writeQualityListBox(pw, issdto.getQuality());
		writeValModelRadio(pw, issdto.getValidateModel());
		writeCSPAListBox(pw, issdto.getCSPAssurance());
		writeValMethodProps(pw, issdto, valMethod);
		pw.println(issuerFooter);
	}

	private void writePropertiesList(PrintWriter pw) throws IOException, GeneralSecurityException
	{
		Hashtable<String, String> props = ConfigData.getProperties();

		pw.write("<form action=\"WebAdmin\" method=\"POST\"><tr><td class=\"midConfigCol\">Proxy host</td>");
		pw.write("<td colspan=\"2\"><input type=\"text\" name=\"proxyhost\" size=\"20\" value=\"");
		pw.write(props.get("proxyhost"));
		pw.write("\"></td><td class=\"smallConfigCol\"></td>");
		pw.write("<td class=\"midConfigCol\">Proxy port</td>");
		pw.write("<td colspan=\"2\"><input type=\"text\" name=\"proxyport\" size=\"20\" value=\"");
		pw.write(props.get("proxyport"));
		pw.write("\"></td></tr>");
		pw.write("<tr><td class=\"midConfigCol\">User name</td>");
		pw.write("<td colspan=\"2\"><input type=\"text\" name=\"username\" size=\"20\" value=\"");
		pw.write(props.get("username"));
		pw.write("\"></td><td class=\"smallConfigCol\"></td>");
		pw.write("<td class=\"midConfigCol\">Password</td>");
		pw.write("<td colspan=\"2\"><input type=\"password\" name=\"password\" size=\"20\" value=\"");
		pw.write(props.get("password"));
		pw.write("\"></td></tr>");
		pw.write("<tr><td class=\"midConfigCol\">HTTP timeout</td>");
		pw.write("<td colspan=\"2\"><input type=\"text\" name=\"timeout\" size=\"20\" value=\"");
		pw.write(props.get("timeout"));
		pw.write("\"></td><td class=\"smallConfigCol\"></td>");
		pw.write("<td class=\"midConfigCol\">No proxy for:</td>");
		pw.write("<td colspan=\"2\"><input type=\"text\" name=\"nonproxyhosts\" size=\"20\" value=\"");
		pw.write(props.get("nonproxyhosts"));
		pw.write("\"></td></tr><tr><td colspan=\"3\">Signature alias / certificate</td>");
		pw.write("<td colspan=\"4\"><select name=\"signalias\" size=\"1\">");

		if (props.get("keystoreentries").indexOf('\t') < 0)
			pw.write("<option value=\"\">"  + props.get("keystoreentries") + "</option>");
		else
		{
			StringTokenizer st = new StringTokenizer(props.get("keystoreentries"), "\t\n");
			String alias;
			while (st.hasMoreElements())
			{
				alias = st.nextToken();
				pw.write("<option value=\"");
				pw.write(alias);
				pw.write("\"");
				if (alias.equals(props.get("sigalias")))
					pw.write(" selected=\"selected\"");
				pw.write(">");
				alias += ": " +  st.nextToken();
				if (alias.length() > 60)
					alias = alias.substring(0, 60) + "...";
				pw.write(alias);
				pw.write("</option>");
			}
		}
		pw.write("</select></td>");

		pw.write("</tr><tr><td colspan=\"20\">&nbsp;</td></tr>");
		pw.write("<tr><td><input type=\"submit\" value=\"Apply\" name=\"applyProps\" /></td></tr>");
		pw.write("<tr><td colspan=\"20\"><hr class=\"hline\" /></td></tr></form>");

		pw.write("<form action=\"WebAdmin\" method=\"POST\" enctype=\"multipart/form-data\"><tr>");
		pw.write("<td colspan=\"1\">New signature keystore</td>");
		pw.write("<td colspan=\"2\"><input type=\"file\" name=\"newKeystore\" /></td>");
		pw.write("<td colspan=\"2\">PIN <input type=\"password\" name=\"keystorepwd\" size=\"12\"/></td>");
		pw.write("<td class=\"smallConfigCol\"></td><td class=\"midConfigCol\"><input type=\"submit\" value=\"Upload PKCS12 keystore\" /></td></tr></form>");
	}

	private void writeIssuerList(PrintWriter pw)
	{
		Collection<IssuerDto> issuers = Configuration.getIssuerDtos();
		for (IssuerDto issr : issuers)
		{
			pw.write(ISSUER_HTML_FRAGS[0]);
			pw.write(issr.getName());
			pw.write(ISSUER_HTML_FRAGS[1]);
			pw.write(issr.getName());
			pw.write(ISSUER_HTML_FRAGS[2]);
			pw.write(issr.getQuality());
			pw.write(ISSUER_HTML_FRAGS[3]);
			pw.write(issr.getValMethod().toString());
			pw.write(ISSUER_HTML_FRAGS[4]);
			pw.write(issr.getName());
			pw.write(ISSUER_HTML_FRAGS[5]);
			pw.write(issr.getEnabled() ? "green" : "red");
			pw.write("\"><b>");
			pw.write(issr.getEnabled() ? "active" : "inactive");
			pw.write(ISSUER_HTML_FRAGS[6]);
			pw.write(issr.getName());
			pw.write(ISSUER_HTML_FRAGS[7]);
		}
	}

	private void writeCertificateList(PrintWriter pw, int type, String desc, String newCmd, String deleteCmd, IssuerDto issuer)
	{
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);

		pw.write(CERTIFICATES_LIST_HTML_FRAGS[0]);
		String title;
		Collection<CertificateDto> entries;
		if (type==0)
		{
			title = "<h1><a name=\"tac\">Trusted anchor certificates</a></h1></td><td>&nbsp;</td><td><br>Always supposed to be valid, also required for client request signature validation and used as SSL trusted server certificates.";
			entries = Configuration.getTrustedAnchorMap().values();
		}
		else
		{
			title = "<h1>Issuer certificates</h1>";
			entries = issuer.certificateMap.values();
		}
		pw.write(title);
		pw.write(CERTIFICATES_LIST_HTML_FRAGS[1]);
		pw.write(desc);
		pw.write(CERTIFICATES_LIST_HTML_FRAGS[2]);
		if (type==1)
			pw.write(newCmd + "\"/><input type=\"hidden\" name=\"issuer\" value=\"" + issuer.getName());
		else
			pw.write(newCmd);
		pw.write(CERTIFICATES_LIST_HTML_FRAGS[3]);

		if (type==1)
			pw.write("<input type=\"hidden\" name=\"issuer\" value=\"" + issuer.getName() + "\"/>");

		for (CertificateDto cdto : entries)
		{
			pw.write(CERTIFCATE_ENTRY_HTML_FRAGS[0]);
			pw.write(type == 0 ?  "trustedAnchorId=" + cdto.getFingerprint() : "issuer=" + issuer.getName() + "&issuerCertId=" + cdto.getFriendlyName());
			pw.write(CERTIFCATE_ENTRY_HTML_FRAGS[1]);
			pw.write(cdto.getFriendlyName());
			pw.write(CERTIFCATE_ENTRY_HTML_FRAGS[2]);
			pw.write(cdto.getX509Certificate().getSerialNumber().toString());
			pw.write(CERTIFCATE_ENTRY_HTML_FRAGS[3]);
			pw.write(df.format(cdto.getX509Certificate().getNotBefore()));
			pw.write(CERTIFCATE_ENTRY_HTML_FRAGS[4]);
			pw.write(df.format(cdto.getX509Certificate().getNotAfter()));
			pw.write(CERTIFCATE_ENTRY_HTML_FRAGS[5]);
			pw.write(type == 0 ?  cdto.getFingerprint() : cdto.getFriendlyName());
			pw.write(CERTIFCATE_ENTRY_HTML_FRAGS[6]);
		}

		pw.write(CERTIFICATES_LIST_HTML_FRAGS[4]);
		pw.write(deleteCmd);
		pw.write(CERTIFICATES_LIST_HTML_FRAGS[5]);
	}

	private void writeIssuerAtts(PrintWriter pw, String tslId, String algPolId)
	{
		pw.write("<tr><td class=\"midConfigCol\">TSL identifier</td>");
		pw.write("<td colspan=\"2\"><input type=\"text\" name=\"tslId\" size=\"20\" value=\"");
		pw.write(tslId);
		pw.write("\"></td><td class=\"smallConfigCol\"></td>");
		pw.write("<td class=\"midConfigCol\">Algorithm policy identifier</td>");
		pw.write("<td colspan=\"2\"><input type=\"text\" name=\"algPolId\" size=\"20\" value=\"");
		pw.write(algPolId);
		pw.write("\"></td>");
		pw.write("</tr><tr><td colspan=\"40\"><hr class=\"hline\" /></td></tr>");
	}

	private void writeQualityListBox(PrintWriter pw, String selected)
	{
		pw.write("<tr><td class=\"leftConfigCol\">Signature level of certificates</td>");
		pw.write("<td colspan=\"3\"><select name=\"quality\">");
		for (int i = 0; i < ConfigData.QUALITIES.length; i++)
		{
			pw.write("<option value=\"");
			pw.write(ConfigData.QUALITIES[i]);
			pw.write("\"");
			if (ConfigData.QUALITIES[i].equalsIgnoreCase(selected))
				pw.write(" selected=\"selected\"");
			pw.write(">");
			pw.write(ConfigData.QUALITIES[i]);
			pw.write("</option>");
		}
		pw.write("</select></td>");
		pw.write("</tr><tr><td colspan=\"40\"><hr class=\"hline\" /></td></tr>");
	}

	private void writeValModelRadio(PrintWriter pw, String selected)
	{
		pw.write("<tr><td class=\"leftConfigCol\">Validation model</td>");
		for (int i = 0; i < ConfigData.VAL_MODEL.length; i++)
		{
			pw.write("<td colspan=\"2\"/><input type=\"radio\" name=\"valmodel\" value=\"");
			pw.write( ConfigData.VAL_MODEL[i]);
			if (ConfigData.VAL_MODEL[i].equalsIgnoreCase(selected))
				pw.write("\" checked>");
			else
				pw.write("\">");
			pw.write(ConfigData.VAL_MODEL[i]);
			pw.write("</input></td>");
		}
		pw.write("</tr><tr><td colspan=\"40\"><hr class=\"hline\" /></td></tr>");
	}

	private void writeCSPAListBox(PrintWriter pw, String selected)
	{
		pw.write("<tr><td class=\"leftConfigCol\">CSP assurance</td>");
		pw.write("<td colspan=\"3\"><select name=\"cspa\">");
		for (int i = 0; i < ConfigData.CSPA.length; i++)
		{
			pw.write("<option value=\"");
			pw.write(ConfigData.CSPA[i]);
			pw.write("\"");
			if (ConfigData.CSPA[i].equals(selected))
				pw.write(" selected=\"selected\"");
			pw.write(">");
			pw.write(ConfigData.CSPA[i]);
			pw.write("</option>");
		}
		pw.write("</select></td>");
		pw.write("</tr><tr><td colspan=\"40\"><hr class=\"hline\" /></td></tr>");
	}

	private void writeValMethodProps(PrintWriter pw , IssuerDto issuer, int valMethod)
	{
		pw.write("<tr><td class=\"leftConfigCol\">Validation method</td>");

		int vm = valMethod;
		if (vm < 0)
			vm = issuer.getValMethod().ordinal();

		// ValMethod LOCAL removed (ESIG-1)
		for (int i = 1; i < ValMethodType.NAMES.length; i++)
		{
			pw.write("<td class=\"smallConfigCol\"><a href=\"WebAdmin?issuerName=");
			pw.write(issuer.getName());
			pw.write("&valmethod=");
			pw.write(Integer.toString(i));
			pw.write("\">");
			if (i==vm)
				pw.write("<span style=\"color:green\"><b>" + ValMethodType.NAMES[i] + "</b></span>");
			else
				pw.write(ValMethodType.NAMES[i]);
			pw.write("</a></td>");

		}
		pw.write("</tr>");

		pw.write(ConfigData.insertValMethodProps(issuer, valMethod));

	}

	public void destroy()
	{
		LOG.fine("Shut down, cancel PPRS download timer.");
		Configuration.pprsDownloadTimer.cancel();
		LOG.fine("PPRS download timer cancelled.");
		LOG.fine("Cancel CRL download timer.");
		Configuration.crlDownloadTimer.cancel();
		LOG.fine("CRl download timer cancelled.");
		super.destroy();
	}
}
