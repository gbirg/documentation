/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.xkms;

import javax.xml.namespace.QName;


/**
 * XKMS related constants.
 * @author jens
 * @author buengener
 *
 * 
*/
public class XKMSConstants
{

  /**
   * XKMS_NAME_SPACE_INIT
   */
  public static final QName XKMS_NAME_SPACE_INIT = new QName("http://www.w3.org/2002/03/xkms#", "", "xkms");

  /**
   * EUDATA_NAME_SPACE_INIT
   */
  public static final QName LSPEU_NAME_SPACE_INIT =
        new QName("http://uri.peppol.eu/xkmsExt/v2#", "", "xkmsEU");

  /**
   * SIGNATURE_NAME_SPACE_INIT
   */
  public static final QName SIGNATURE_NAME_SPACE_INIT =
        new QName("http://www.w3.org/2000/09/xmldsig#", "", "ds");

  /**
   * ENCRYPTION_NAME_SPACE_INIT
   */
  public static final QName ENCRYPTION_NAME_SPACE_INIT =
        new QName("http://www.w3.org/2001/04/xmlenc#", "", "xenc");

  /**
   * possible values for ResultMinor Attributes are specified below
   */
  /**
   * No match was found for the search prototype provided. For example: The result code MajorResult=Success
   * MinorResult=NoMatch indicates that the service is authoritative for the search prototype specified and
   * that the service positively asserts that no matches exist. The result code MajorResult=Receiver
   * MinorResult=NoMatch indicates that the service is not authoritative for the search prototype provided.
   */
  public static final String XKMS_RESULT_MINOR_NoMatch = "http://www.w3.org/2002/03/xkms#NoMatch";

  /**
   * The request resulted in the number of responses that exceeded either the ResponseLimit value specified in
   * the request or some other limit determined by the service. The service MAY either return a subset of the
   * possible responses or none at all. For example: MajorResult=Success MinorResult=TooManyResponses
   * indicates that the service has returned one or more responses that represent a subset of the possible
   * responses. If MajorResult=Receiver MinorResult=TooManyResponses indicates that the service has returned
   * no responses
   */
  public static final String XKMS_RESULT_MINOR_TooManyResponses =
        "http://www.w3.org/2002/03/xkms#TooManyResponses";

  /**
   * Only part of the information requested could be provided.
   */
  public static final String XKMS_RESULT_MINOR_Incomplete = "http://www.w3.org/2002/03/xkms#Incomplete";

  /**
   * The service attempted to perform the request but the operation failed for unspecified reasons For
   * example: MajorResult=Sender MinorResult=Failure indicates that the reason for failure is attributed to
   * the sender (for example the request failed schema validation). MajorResult=Receiver MinorResult=Failure
   * indicates that the reason for failure is attributed to the receiver (for example a database lookup
   * failed).
   */
  public static final String XKMS_RESULT_MINOR_Failure = "http://www.w3.org/2002/03/xkms#Failure";

  /**
   * The operation was refused. The service did not attempt to perform the request. For example:
   * MajorResult=Sender MinorResult=Refused indicates that the sender failed to provide sufficient information
   * to authenticate or authorize the request (for example not supplied) MajorResult=Receiver
   * MinorResult=Refused indicates that the receiver is currently refusing certain requests for unspecified
   * reasons.
   */
  public static final String XKMS_RESULT_MINOR_Refused = "http://www.w3.org/2002/03/xkms#Refused";

  /**
   * The operation was refused because the necessary authentication information was incorrect or missing.
   */
  public static final String XKMS_RESULT_MINOR_NoAuthentication =
        "http://www.w3.org/2002/03/xkms#NoAuthentication";

  /**
   * The receiver does not implement the specified operation.
   */
  public static final String XKMS_RESULT_MINOR_MessageNotSupported =
        "http://www.w3.org/2002/03/xkms#MessageNotSupported";

  /**
   * The ResponseId for which pending status was requested is unknown to the service
   */
  public static final String XKMS_RESULT_MINOR_UnknownResponseId =
        "http://www.w3.org/2002/03/xkms#UnknownResponseId";

  public static final String XKMS_RESULT_MINOR_RepresentRequired =
        "http://www.w3.org/2002/03/xkms#RepresentRequired";

  /**
   * The receiver does not support synchronous processing of this type of request
   */
  public static final String XKMS_RESULT_MINOR_NotSynchronous =
        "http://www.w3.org/2002/03/xkms#NotSynchronous";

  public static final String XKMS_RESULT_MINOR_OptionalElementNotSupported =
        "http://www.w3.org/2002/03/xkms#OptionalElementNotSupported";

  public static final String XKMS_RESULT_MINOR_ProofOfPossessionRequired =
        "http://www.w3.org/2002/03/xkms#ProofOfPossessionRequired";

  public static final String XKMS_RESULT_MINOR_TimeInstantNotSupported =
        "http://www.w3.org/2002/03/xkms#TimeInstantNotSupported";

  public static final String XKMS_RESULT_MINOR_TimeInstantOutOfRange =
      "http://www.w3.org/2002/03/xkms#TimeInstantOutOfRange";

  public static final String XKMS_RESULT_MINOR_ReasonTrustViolation =
      "http://uri.peppol.eu/xkmsExt/v2#reasonTrustViolation";

  /**
   * possible values for ResultMajor Attributes are specified below
   */
  /**
   * The operation succeeded
   */
  public static final String XKMS_RESULT_MAJOR_Success = "http://www.w3.org/2002/03/xkms#Success";

  /**
   * The service does not support the protocol version specified in the request
   */
  public static final String XKMS_RESULT_MAJOR_VersionMismatch =
        "http://www.w3.org/2002/03/xkms#VersionMismatch";

  /**
   * An error occurred that was due to the message sent by the sender.
   */
  public static final String XKMS_RESULT_MAJOR_Sender = "http://www.w3.org/2002/03/xkms#Sender";

  /**
   * An error occurred at the receiver.
   */
  public static final String XKMS_RESULT_MAJOR_Receiver = "http://www.w3.org/2002/03/xkms#Receiver";

  /**
   * The service has not acted on the request. In order for the request to be acted upon the request MUST be
   * represented with the specified nonce in accordance with the two phase protocol
   */
  public static final String XKMS_RESULT_MAJOR_Represent = "http://www.w3.org/2002/03/xkms#Represent";

  /**
   * The request has been accepted for processing and the service will return the result asynchronously
   */
  public static final String XKMS_RESULT_MAJOR_Pending = "http://www.w3.org/2002/03/xkms#Pending";

  /**
   * Value for /xkmsEU:ResponderDetails/xkmsEU:TSLIdentifier in case the certificate issuer cannot be
   * found in the TSL
   */
  public static final String XKMS_EU_ISSUER_NOT_IN_TSL = "http://uri.peppol.eu/xkmsExt/v2#CertIssuerNotInTSL";

  // ----- XKMS_StatusValue ----
  /**
   * XKMS_XKMS_STATUSVALUE_VALID
   */
  public static final String XKMS_STATUSVALUE_VALID = "http://www.w3.org/2002/03/xkms#Valid";

  /**
   * XKMS_STATUSVALUE_INVALID
   */
  public static final String XKMS_STATUSVALUE_INVALID = "http://www.w3.org/2002/03/xkms#Invalid";

  /**
   * XKMS_STATUSVALUE_INDETERMINATE
   */
  public static final String XKMS_STATUSVALUE_INDETERMINATE = "http://www.w3.org/2002/03/xkms#Indeterminate";

  // ----- END XKMS_StatusValue ----
  // ----- XKMS_KEYUSAGE ----
  /**
   * XKMS_KEYUSAGE_SIGNATURE
   */
  public static final String XKMS_KEYUSAGE_SIGNATURE = "http://www.w3.org/2002/03/xkms#Signature";

  /**
   * XKMS_KEYUSAGE_ENCRYPTION
   */
  public static final String XKMS_KEYUSAGE_ENCRYPTION = "http://www.w3.org/2002/03/xkms#Encryption";

  /**
   * XKMS_KEYUSAGE_EXCHANGE
   */
  public static final String XKMS_KEYUSAGE_EXCHANGE = "http://www.w3.org/2002/03/xkms#Exchange";

  // ------ END XKMS_KEYUSAGE -----
  // ----- XKMS_RESPONDWITH ----
  /**
   * XKMS_RESPONDWITH_X509CERT
   */
  public static final String XKMS_RESPONDWITH_X509CERT = "http://www.w3.org/2002/03/xkms#X509Cert";

  /**
   * XKMS_RESPONDWITH_X509CHAIN
   */
  public static final String XKMS_RESPONDWITH_X509CHAIN = "http://www.w3.org/2002/03/xkms#X509Chain";

  /**
   * XKMS_RESPONDWITH_X509CRL
   */
  public static final String XKMS_RESPONDWITH_X509CRL = "http://www.w3.org/2002/03/xkms#X509CRL";

  /**
   * XKMS_RESPONDWITH_OCSP
   */
  public static final String XKMS_RESPONDWITH_OCSP = "http://uri.peppol.eu/xkmsExt/v2#OCSP";

  /**
   * XKMS_RESPONDWITH_EU_EXTENSION
   */
  public static final String XKMS_RESPONDWITH_EU_EXTENSION = "http://uri.peppol.eu/xkmsExt/v2";

  /**
   * XKMS_RESPONDWITH_SERVICE_INFORMATION
   */
  public static final String XKMS_RESPONDWITH_SERVICE_INFORMATION = "http://uri.etsi.org/02231/v2#ServiceInformation";

  /**
   * XKMS_RESPONDWITH_EIDQUALITY
   */
  public static final String XKMS_RESPONDWITH_EIDQUALITY = "http://uri.peppol.eu/xkmsExt/v2#eIDQuality";

  /**
   * XKMS_RESPONDWITH_VALIDATION_DETAILS
   */
  public static final String XKMS_RESPONDWITH_VALIDATION_DETAILS = "http://uri.peppol.eu/xkmsExt/v2#ValidationDetails";

  /**
   * XKMS_RESPONDWITH_OCSP_NO_CACHE
   */
  public static final String XKMS_RESPONDWITH_OCSPNOCACHE = "http://uri.peppol.eu/xkmsExt/v2#OCSPNoCache";



  // ----- END XKMS_RESPONDWITH ----
  /**
   * The attribute Service in MessageAbstractType <xs:attribute name="Service" type="xs:anyURI"
   * use="required"/>
   */
  public static final String XKMS_ATTRIBUTE_Service = "http://www.lsp.eu/2009/04/XKMS";

  // ------ XKMS_RESPONSEMECHANISM ------
  /**
   * XKMS_RESPONSEMECHANISM_PENDING
   */
  public static final String XKMS_RESPONSEMECHANISM_PENDING = "http://www.w3.org/2002/03/xkms#Pending";

  /**
   * XKMS_RESPONSEMECHANISM_REPRESENT
   */
  public static final String XKMS_RESPONSEMECHANISM_REPRESENT = "http://www.w3.org/2002/03/xkms#Represent";

  /**
   * XKMS_RESPONSEMECHANISM_REQUESTSIGNATUREVALUE
   */
  public static final String XKMS_RESPONSEMECHANISM_REQUESTSIGNATUREVALUE =
        "http://www.w3.org/2002/03/xkms#RequestSignatureValue";

  // ------ XKMS_RESPONSEMECHANISM ------
  // -------XKMS_REASON-----
  /**
   * XKMS_REASON_SIGNATURE
   */
  public static final String XKMS_REASON_SIGNATURE = "http://www.w3.org/2002/03/xkms#Signature";

  /**
   * XKMS_REASON_ISSUERTRUST
   */
  public static final String XKMS_REASON_ISSUERTRUST = "http://www.w3.org/2002/03/xkms#IssuerTrust";

  /**
   * XKMS_REASON_REVOCATIONSTATUS
   */
  public static final String XKMS_REASON_REVOCATIONSTATUS = "http://www.w3.org/2002/03/xkms#RevocationStatus";

  /**
   * QName XKMS_REASON_VALIDITYINTERVALL
   */
  public static final String XKMS_REASON_VALIDITYINTERVALL =
        "http://www.w3.org/2002/03/xkms#ValidityInterval";


  /**
   * VALIDATESCHEME_LOCAL
   */
  public static final String VALIDATESCHEME_LOCAL = "http://uri.peppol.eu/xkmsExt/v2#valSchemeLOCAL";

  /**
   * VALIDATESCHEME_OCSP
   */
  public static final String VALIDATESCHEME_OCSP = "http://uri.peppol.eu/xkmsExt/v2#valSchemeOCSP";

  /**
   * VALIDATESCHEME_OCSPCommonPKI
   */
  public static final String VALIDATESCHEME_OCSP_COMMON_PKI = "http://uri.peppol.eu/xkmsExt/v2#valSchemeOCSPCommonPKI";

  /**
   * VALIDATESCHEME_CRL
   */
  public static final String VALIDATESCHEME_CRL = "http://uri.peppol.eu/xkmsExt/v2#valSchemeCRL";

  /**
   * VALIDATESCHEME_CRL_LDAP
   */
  public static final String VALIDATESCHEME_CRL_LDAP = "http://uri.peppol.eu/xkmsExt/v2#valSchemeCRLLDAP";

  /**
   * VALIDATESCHEME_LDAP
   */
  public static final String VALIDATESCHEME_LDAP = "http://uri.peppol.eu/xkmsExt/v2#valSchemeLDAP";


  /**
   * VALIDATESCHEME_NONE
   */
  public static final String VALIDATESCHEME_NONE = "http://uri.peppol.eu/xkmsExt/v2#valSchemeNONE";


  public static final String VALIDATIONMODEL_PKIX = "http://uri.peppol.eu/xkmsExt/v2#valModelPKIX";

  public static final String VALIDATIONMODEL_CHAIN = "http://uri.peppol.eu/xkmsExt/v2#valModelChain";

  public static final String VALIDATIONMODEL_ESCAPEROUTE = "http://uri.peppol.eu/xkmsExt/v2#valModelEscapeRoute";


  /**
   * CertificateRevocationReason_Unspecified
   */
  public static final String CertificateRevocationReason_Unspecified =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonUnspecified";

  /**
   * CertificateRevocationReason_KeyCompromised
   */
  public static final String CertificateRevocationReason_KeyCompromised =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonKeyCompromise";

  /**
   * CertificateRevocationReason_CaCompromised
   */
  public static final String CertificateRevocationReason_CaCompromised =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonCACompromise";

  /**
   * CertificateRevocationReason_AffiliationChanged
   */
  public static final String CertificateRevocationReason_AffiliationChanged =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonAffiliationChanged";

  /**
   * CertificateRevocationReason_Superseded
   */
  public static final String CertificateRevocationReason_Superseded =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonSuperseded";

  /**
   * CertificateRevocationReason_CessationOfOperation
   */
  public static final String CertificateRevocationReason_CessationOfOperation =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonCessationOfOperation";

  /**
   * CertificateRevocationReason_CertificateHold
   */
  public static final String CertificateRevocationReason_CertificateHold =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonCertificateHold";

  /**
   * CertificateRevocationReason_RemoveFromCRL
   */
  public static final String CertificateRevocationReason_RemoveFromCRL =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonRemoveFromCRL";

  /**
   * CertificateRevocationReason_PRIVILEGEWITHDRAWN
   */
  public static final String CertificateRevocationReason_PRIVILEGEWITHDRAWN =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonPrivilegeWithdrawn";

  /**
   * CertificateRevocationReason_AA_COMPROMISE
   */
  public static final String CertificateRevocationReason_AA_COMPROMISE =
        "http://uri.peppol.eu/xkmsExt/v2#revocationReasonAACompromise";

  /**
   * CertificateRevocationReason_NONE
   */
  public static final String CertificateRevocationReason_NONE =
	  "http://uri.peppol.eu/xkmsExt/v2#revocationReasonNone";


  /**
   * ErrorExtension_OpaqueClientDataToLong
   */
  public static final String ErrorExtension_OpaqueClientDataToLong =
        "http://uri.peppol.eu/xkmsExt/v2#reasonOpaqueClientDataTooLong";

  /**
   * ErrorExtension_TrustCenterNotReachable
   */
  public static final String ErrorExtension_TrustCenterNotReachable =
        "http://uri.peppol.eu/xkmsExt/v2#reasonTrustCenterNotReachable";

  /**
   * ErrorExtension_WrongCertificateFormat
   */
  public static final String ErrorExtension_WrongCertificateFormat =
        "http://uri.peppol.eu/xkmsExt/v2#reasonWrongCertificateFormat";

  /**
   * ErrorExtension_UnknownCA
   */
  public static final String ErrorExtension_UnknownCA =
	  "http://uri.peppol.eu/xkmsExt/v2#reasonUnknownCA";

  /**
   * ErrorExtension_WrongTimeInstant
   */
  public static final String ErrorExtension_WrongTimeInstant =
        "http://uri.peppol.eu/xkmsExt/v2#reasonWrongTimeInstant";

  /**
   * ErrorExtension_SignatureKeyToShort
   */
  public static final String ErrorExtension_SignatureKeyToShort =
        "http://uri.peppol.eu/xkmsExt/v2#reasonSignatureKeyTooShort";

  /**
   * ErrorExtension_NextResponderInChainNotReached
   */
  public static final String ErrorExtension_NextResponderInChainNotReached =
        "http://uri.peppol.eu/xkmsExt/v2#reasonNextResponderInChainNotReached";

  /**
   * ErrorExtension_ResponderChainLoop
   */
  public static final String ErrorExtension_ResponderChainLoop =
        "http://uri.peppol.eu/xkmsExt/v2#reasonResponderChainLoop";

  /**
   * ErrorExtension_InternalError
   */
  public static final String ErrorExtension_Unknown =
	  "http://uri.peppol.eu/xkmsExt/v2#reasonUnknown";

  /**
   * ErrorExtension_InternalError
   */
  public static final String ERROR_EXTENSION_NOT_UNDERSTOOD =
	  "http://uri.peppol.eu/xkmsExt/v2#reasonNotUnderstood";

  /**
   * ErrorExtension_RevocationStatusNoLongerProvided
   */
  public static final String ErrorExtension_RevocationStatusNoLongerProvided =
	  "http://uri.peppol.eu/xkmsExt/v2#reasonRevocationStatusNoLongerProvided";

  /**
   * ErrorExtension_CertQualityNotConsistent
   */
  public static final String ErrorExtension_CertQualityNotConsistent =
	  "http://uri.peppol.eu/xkmsExt/v2#reasonCertQualityNotConsistent";

  /**
   * ErrorExtension_InternalError
   */
//  public static final String ErrorExtension_InternalError = "http://uri.peppol.eu/xkmsExt/v2#reasonInternalError";


  /**
   * CertQuality
   */


  public static final String CertQuality_Unknown = "http://uri.peppol.eu/xkmsExt/v2#certqualityUnknown";

  public static final String CertQuality_Low = "http://uri.peppol.eu/xkmsExt/v2#certqualityLow";

  public static final String CertQuality_Lcp = "http://uri.peppol.eu/xkmsExt/v2#certqualityLCP";

  public static final String CertQuality_Ncp = "http://uri.peppol.eu/xkmsExt/v2#certqualityNCP";

  public static final String CertQuality_Ncpplus = "http://uri.peppol.eu/xkmsExt/v2#certqualityNCPPLUS";

  public static final String CertQuality_Qcp = "http://uri.peppol.eu/xkmsExt/v2#certqualityQCP";

  public static final String CertQuality_Qcpplus = "http://uri.peppol.eu/xkmsExt/v2#certqualityQCPPLUS";


  public static final String CSPAssurance_None = "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceNone";

  public static final String CSPAssuranceIndependentDocumentReview =
        "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceIndependentDocumentReview";

  public static final String CSPAssuranceInternalComplianceAudit =
        "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceInternalComplianceAudit";

  public static final String CSPAssurance_SupervisionWithoutComplianceAudit =
        "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceSupervisionWithoutComplianceAudit";

  public static final String CSPAssurance_ExternalComplianceAudit =
        "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceExternalComplianceAudit";

  public static final String CSPAssurance_ExternalComplianceAuditCertified =
        "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceExternalComplianceAuditCertified";

  public static final String CSPAssurance_SupervisionWithExternalComplianceAudit =
        "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceSupervisionWithExternalComplianceAudit";

  public static final String CSPAssurance_AccreditationWithExternalComplianceAudit =
        "http://uri.peppol.eu/xkmsExt/v2#CSPAssuranceAccreditationWithExternalComplianceAudit";


  /**
   * ERROR_MESSAGE_NOTSUPPORTED
   */
  public static final String ERROR_MESSAGE_NOTSUPPORTED = "MESSAGE NOT SUPPORTED";

  /**
   * ERROR_MESSAGE_REQUESTIDWRONG
   */
  public static final String ERROR_MESSAGE_REQUESTIDWRONG = "REQUEST ID WRONG";
}
