/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.xkms;

import java.util.Random;



/**
 * Helper class for creation of XKMS response messages.
 * @author jens
 *
 * 
*/
public class XKMSResponseHelper
{
  private static Random r = new Random();

  /**
   * Creates a new XKMSResponseHelper object.
   */
  public XKMSResponseHelper()
  {
  }

  public static org.w3._2001._04.xmlenc.ObjectFactory getEncryptionObjectFactory()
    throws Exception
  {
    return new org.w3._2001._04.xmlenc.ObjectFactory();
  }

  public static org.w3._2000._09.xmldsig.ObjectFactory getSignatureObjectFactory()
    throws Exception
  {
    return new org.w3._2000._09.xmldsig.ObjectFactory();
  }

  private static final char[] CHARS =
                                      {
                                        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
                                        'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F',
                                        'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
                                        'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
                                      };

  public static String getMessageId()
  {
    StringBuffer sb = new StringBuffer();
    sb.append(CHARS[r.nextInt(CHARS.length - 10)]);

    for (int i = 0; i < 5; i++)
      sb.append(CHARS[r.nextInt(CHARS.length)]);

    sb.append(new java.util.Date().getTime());

    for (int i = 0; i < 3; i++)
      sb.append(CHARS[r.nextInt(CHARS.length)]);

    return sb.toString();
  }
}
