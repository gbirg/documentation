/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.security.cert.X509Certificate;
import java.util.logging.Logger;

import org.bouncycastle.util.encoders.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.inspectionTests.ResponderTestHelper;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;


/**
 * Tests for Italian certificates.
 * Contains three additional tests for requested CRL, certificate chain, OCSP responses.
 * One additional test for XKMS forward (mediated request).
 * @author buengener
 *
 */

public class ItalyTest extends HttpEntryTest
{

	private final static Logger LOG = Logger.getLogger(ItalyTest.class.getName());

	public ItalyTest(String name)
	{
		super(name);
	}

	public void setUp()
	{
		uploadConfig("/eu/peppol/lsp/xkmsresponder/entry/PeppolTestConfig_IT.xml");
		super.setUp();
	}

	public void testItalyLisitValid() throws Exception
	{
		performTest("/certificates/Italy/LISIT/luigi_vbongiorni.crt", "Valid", null);
	}

	public void testItalyLisitValid2() throws Exception
	{
		performTest("/certificates/Italy/LISIT/maria_vcosta.crt", "Valid", null);
	}

	public void testItalyLisitRevoked() throws Exception
	{
		performTest("/certificates/Italy/LISIT/riccardo_vtoffano.crt", "Invalid", "RevocationStatus");
	}

	public void testItalyInfoCertRevoked() throws Exception
	{
		performTest("/certificates/Italy/InfoCamere/CertRevoked.crt", "Invalid", "RevocationStatus", "2011-06-09T11:26:29+01:00");
	}

	public void testItalyInfoCertValid() throws Exception
	{
		performTest("/certificates/Italy/InfoCamere/CertOk.crt", "Valid", null);
	}

	public void testItalyActalisValid() throws Exception
	{
		performTest("/certificates/Italy/ACTALIS/cert1.crt", "Valid", null);
	}

	public void testItalyActalisRevoked() throws Exception
	{
		performTest("/certificates/Italy/ACTALIS/cert3.crt", "Invalid", "RevocationStatus");
	}

	public void testItalyCNIPA() throws Exception
	{
		performTest("/certificates/Italy/CNIPA/User.crt", "Valid", null, "2009-01-09T11:26:29+01:00");
	}

	public void testXKMSForward() throws Exception
	{
		performTest("/certificates/Germany/user_TeleSec_PKS_SigG_CA_25PN_gueltig.crt", "Valid", null, "2009-01-09T11:26:29+01:00");
	}

	public void testRevocationResonAndOCSPValue() throws Exception
	{
		final byte[] req = createRequestMsg("/certificates/Italy/InfoCamere/CertOk.crt",
				null, new String[]{XKMSConstants.XKMS_RESPONDWITH_OCSP});

		byte[] rsp = ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION, req, ResponderTransport.HTTP_SOAP_HEADER);

		Document doc =  parseResponse(rsp);
		NodeList nl = doc.getElementsByTagNameNS(EULSP_NS, "CertificateRevocationDetails");
		assertEquals("CertificateRevocationDetails not found (or too many)", 1, nl.getLength());
		assertEquals("RevocationTimeInstant not found (or too many)", 1,
				((Element)nl.item(0)).getElementsByTagNameNS(EULSP_NS, "RevocationTimeInstant").getLength());
		nl = ((Element)nl.item(0)).getElementsByTagNameNS(EULSP_NS, "RevocationReason");
		assertEquals("RevocationReason not found (or too many)", 1, nl.getLength());
		assertEquals("Expected RevocationReason not found", XKMSConstants.CertificateRevocationReason_CessationOfOperation,
				((Element)nl.item(0)).getTextContent());
		nl = doc.getElementsByTagNameNS(ETSI_NS, "EncapsulatedOCSPValue");
		assertEquals("OCSPValue not found (or too many)", 1, nl.getLength());
		assertTrue("OCSPValue is empty", ((Element)nl.item(0)).getTextContent().length() > 0);
	}

	public void testCRL() throws Exception
	{
		final byte[] req = createRequestMsg("/certificates/Italy/LISIT/luigi_vbongiorni.crt",
				null, new String[]{XKMSConstants.XKMS_RESPONDWITH_X509CRL, XKMSConstants.XKMS_RESPONDWITH_X509CERT});

		byte[] rsp = ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION, req, ResponderTransport.HTTP_SOAP_HEADER);
		Document doc =  parseResponse(rsp);
		Element kb = (Element)doc.getElementsByTagNameNS(XKMS_NS, "KeyBinding").item(0);
		NodeList nl = kb.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "X509CRL");
		assertEquals("X509Crl not found (or too many)", 1, nl.getLength());
		assertTrue("X509Crl is empty", ((Element)nl.item(0)).getTextContent().length() > 0);

		nl = kb.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "X509Certificate");
		assertEquals("X509Certificate not found (or too many)", 1, nl.getLength());
		String b64 = ((Element)nl.item(0)).getTextContent();
		assertTrue("X509Certificate is empty", b64.length() > 0);

		X509Certificate cert_req = ResponderHelper.createCertificate(this.getClass().getResourceAsStream("/certificates/Italy/LISIT/luigi_vbongiorni.crt"));
		X509Certificate cert_rsp = ResponderHelper.createCertificate(Base64.decode(b64));
		assertEquals("Wrong certificate in response", cert_req, cert_rsp);

	}


	public void testChain() throws Exception
	{
		final byte[] req = createRequestMsg("/certificates/Italy/LISIT/luigi_vbongiorni.crt",
				null, new String[]{XKMSConstants.XKMS_RESPONDWITH_X509CHAIN});

		byte[] rsp = ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION, req, ResponderTransport.HTTP_SOAP_HEADER);
		Document doc =  parseResponse(rsp);
		Element kb = (Element)doc.getElementsByTagNameNS(XKMS_NS, "KeyBinding").item(0);
		NodeList nl = kb.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "X509Certificate");
		assertEquals("X509Certificates not found (or too many)", 2, nl.getLength());
	}


	public static void main(String[] args)
	{
		try
	    {
	    	ItalyTest het = new ItalyTest(null);
	    	het.setUp();
	    	het.testRevocationResonAndOCSPValue();
		}
	    catch (Exception e)
	    {
			e.printStackTrace();
		}
	  }
}
