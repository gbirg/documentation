/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.inspectionTests.ResponderTestHelper;

/**
 * Tests for Norwegian certificates.
 * @author buengener
 *
 */

public class NorwayTest extends HttpEntryTest
{

	private final static Logger LOG = Logger.getLogger(NorwayTest.class.getName());

	private String conf;

	private static final String SSL_CERT =
	"MIIE1jCCA76gAwIBAgIDDAU5MA0GCSqGSIb3DQEBBQUAMEsxCzAJBgNVBAYTAk5PMR0wGwYDVQQK"
	+ "DBRCdXlwYXNzIEFTLTk4MzE2MzMyNzEdMBsGA1UEAwwUQnV5cGFzcyBDbGFzcyAzIENBIDEwHhcN"
	+ "MTAxMTEyMTQzMjA4WhcNMTIxMTEyMTQzMjA4WjCBpzENMAsGA1UEEQwEMDQwMjENMAsGA1UEBwwE"
	+ "T1NMTzEdMBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEzARBgsrBgEEAYI3PAIBAxMCTk8x"
	+ "CzAJBgNVBAYTAk5PMRMwEQYDVQQKDApCVVlQQVNTIEFTMR0wGwYDVQQDDBRvY3NwLnByb2QuYnV5"
	+ "cGFzcy5ubzESMBAGA1UEBRMJOTgzMTYzMzI3MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC"
	+ "AQEA4f2r1zMRVpKXTIjObYFUznL4f+l4H8Rrc5RELbNP4HY64OzQnS5yExc4oMkmzHi93af/TjpF"
	+ "z1vqzwGqHmo6XHXLPHJDlgrUaeWciUXTCYyIyA62Wn+StktZwufI2CCaVq2yLwP7Qownj7i6xDKr"
	+ "Sk4OlBROUSlLPSAsfJWJbk51opwHrEdalePAfp2u17hStdQJcONwfQW+4EbkMsMEp+wjmsyeC6go"
	+ "E5ZYiJIB7/XzrfwzHus6FHo5vGT/yEDBrdVC7f/hOXWk7aU+gT0eDXhizvlNZI0AXCqLd5qjB4xX"
	+ "bKVT2ru3nTwJZkphi8OXSGiLHXwePxdIKgEF7dFGswIDAQABo4IBZDCCAWAwCQYDVR0TBAIwADAf"
	+ "BgNVHSMEGDAWgBQ4FObI8KmkA/ROPiKjW/LW4K1AdDAdBgNVHQ4EFgQUtL8T5gKKCM6qtOUjtzLY"
	+ "eW4gAdcwDgYDVR0PAQH/BAQDAgWgMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjA/BgNV"
	+ "HSAEODA2MDQGCGCEQgEaAQMDMCgwJgYIKwYBBQUHAgEWGmh0dHBzOi8vd3d3LmJ1eXBhc3Mubm8v"
	+ "Y3BzMD8GA1UdHwQ4MDYwNKAyoDCGLmh0dHA6Ly9jcmwucHJvZC5idXlwYXNzLm5vL2NybC9CUENs"
	+ "YXNzM0NBMS5jcmwwHwYDVR0RBBgwFoIUb2NzcC5wcm9kLmJ1eXBhc3Mubm8wQQYIKwYBBQUHAQEE"
	+ "NTAzMDEGCCsGAQUFBzABhiVodHRwOi8vb2NzcC5wcm9kLmJ1eXBhc3Mubm8vQlBDbGFzczIzMA0G"
	+ "CSqGSIb3DQEBBQUAA4IBAQAxwEcmpj6VMTp/hw4m0fHsEe9wdQrQdVaYpX5fntwyzzUQeHim89NH"
	+ "kUDlFoMueU44uD5zr8/waW9aM32GvVxW5MxgGAI91cFL9wjLObUc/Tz+M+E/p4yBezVYf1L0Eeiz"
	+ "pA8l0NigDhva/evRbruNhpNexCUwsbLrZZ3rsc5ZANTtfQXa9nJEjsEkg/Io2VQe550m/ewMSk+r"
	+ "y3vF1j9BCuNSUITrK+/nJaDiX8PSQ/PM7o+8bwq3zZ2dkm6YIgOrfT/uETQECLJu9KW/KSGFlafT"
	+ "us/NRCqJ75jkTef+6fun/sPTU53ipKXRv8pWg+OWYJ3EYKkaub8ILqK/U7vRAANXMIIDUzCCAjug"
	+ "AwIBAgIBAjANBgkqhkiG9w0BAQUFADBLMQswCQYDVQQGEwJOTzEdMBsGA1UECgwUQnV5cGFzcyBB"
	+ "Uy05ODMxNjMzMjcxHTAbBgNVBAMMFEJ1eXBhc3MgQ2xhc3MgMyBDQSAxMB4XDTA1MDUwOTE0MTMw"
	+ "M1oXDTE1MDUwOTE0MTMwM1owSzELMAkGA1UEBhMCTk8xHTAbBgNVBAoMFEJ1eXBhc3MgQVMtOTgz"
	+ "MTYzMzI3MR0wGwYDVQQDDBRCdXlwYXNzIENsYXNzIDMgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQAD"
	+ "ggEPADCCAQoCggEBAKSO13TZKWTeXx+HgJHqTjnmGcZEC4DVC69TB4sSveZn8AKxifZgisRbsELR"
	+ "wCGoy+Gb72RRtqfPFfV0gGgEkKBYouZ0plNTVUhjP5JW3SROjvi6K//zNIqeKNc0n6wv1g/xpC+9"
	+ "UrJJhW05NfBEMJNGJPO251P7vGGvqaMU+8IXF4Rs4HyI+MkcVyzwPX6UvCWThOiaAJpFBUJXgPRO"
	+ "ztmuOfbIUxAMZTpHe2DC1vqRycZxbL2RhzyRhkmr8w+gbCZ2Xhysm3HljbybIR6c1jh+JIAVMYKW"
	+ "sUnTYjdbiAwKYjT+p0h+mbEwi5A3lRyoH6UsjfRVyNvdWQrCrXig9IsCAwEAAaNCMEAwDwYDVR0T"
	+ "AQH/BAUwAwEB/zAdBgNVHQ4EFgQUOBTmyPCppAP0Tj4io1vy1uCtQHQwDgYDVR0PAQH/BAQDAgEG"
	+ "MA0GCSqGSIb3DQEBBQUAA4IBAQABZ6OMySU9E2NdFm/soT4JXJEVKirZgCFPBdy7pYmrEzMqnji3"
	+ "jG8CcmPHc3ceCQa6Oyh7pEfJYWsICCD8igWKH7y6xsL+z27sEzNxZy5p+qksP2bAEllNC1QCkoS7"
	+ "2xLvg3BweMhT+t/Gxv/ciC8HwEmdMldg0/L2mSlf56oBzKwzqBwKu5HEA6BvtjT5htOzdlSY9EqB"
	+ "s1OdTUDs5XcTRa9bqh/YL0yCe/4qxFi7T/ye/QNlGioOw6UgFpRreaaiErS7GqQjel/wroQk5PMr"
	+ "+4okoyeYZdowdXb8GZHo2+ubPzK/QJcHJrrM85SFSnonk8+QQtS4Wxam58tAA915FgMBAAQOAAAA"
	+ "FAMBAAEBFgMBACBfBtDitVX8mSdbHLXSaM5FtPn1+kOIGtQMykZvFyL4OxcDAQDXV4yvntOEzByT"
	+ "cETuybBBPkQrfhklZSLSDa9LaOqjfAXcqdQbZhWVZtXrbQKxdZ9M7RRy0MVaw7JLas2E7BjHlMfi"
	+ "UfC5mlPcYnSUVO3Ms14CIry/MX+Y1QC7xwX6i7ddYbqXJx8McNiaxCNz/I/Q1oneqS8tdWTCTIkm"
	+ "WoRoPVuhXzOFHRGbw9jQ8XgBR6QGuyHfAjAm9dcINcj6I/9YzkA1OfAaAWBey9GdYFpENv46VY5G"
	+ "U86O5BJKFpmLnx1qe+OXSj8TI65xusw1GNWltRT2y3EBz+EXAwEB/qGgziO10k9h2hLDFk3Pipgu"
	+ "VXay6kggySWvIfx8QCSzOm75Ast5Fq+oniIOBae/lBpSXKeEWO2S4ESaQoaSaRFHgpe3R1mX/2KD"
	+ "qNEaorEvo7fhPkCEIKGTOH4w4djOI36bnF0ARbeg1GUSt06n2sLEQsQDuxWaEZi1TNh5KdWRJALV"
	+ "gRkl0Pt7jyypUdRZpB8VNQOzFAhG6t3chZ5CFtT1BX5BRQqYWJbbHWqUa2KuUawlS9AaUozqJNvJ"
	+ "X5vEg2vdkfAL6U3myzBTSUfl1CyplpYBrc4WS5afS+5BnOK/9cqDop1ixicFDWbOdc6/OwSpk7XI"
	+ "LY1+aeu9b/EuCHZ3COXx3eff/jEOWbX7QMnfq9mQjuBQlEF9xuojx05XyaYd5Nq7qKlpWTfFlRKM"
	+ "HOUwRalcO2uJoFxfb/1PN8Uyd56aPN5kaZTrZYgo0QuwmXJdXusdtOw8S5YP58Wa+eV7ZzVTzgeY"
	+ "XWPsXevKg9cfVFfi2YKaMre+L4S40U2V3BaH2ThY3YOI26xuK+Be6hNIK6x9MbCl+/1EXmwQPoq7"
	+ "cNKxoxxxncYGlUZ5l6ud5l+/cOtD1JFrvRp+mgKDVohTePw/SCxEpLRJvIy/Hpr2BQf4dq9/Bm6m"
	+ "Q9b6401YwX4hZuP7OQ6QYpYkpdEbAm/8GMaUd1HK1HAIGZv22w==";

	public NorwayTest(String name)
	{
		super(name);
	}

	public void setUp()
	{
		conf = ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE;

		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("</TACertificates>", "<TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\"><X509Certificate>" + SSL_CERT + "</X509Certificate></TACertificate></TACertificates>");
		uploadConfig("/eu/peppol/lsp/xkmsresponder/entry/PeppolTestConfig_NO.xml");
		super.setUp();
	}

	public void testNorwayCommfides() throws Exception
	{
		performTest("/certificates/Norway/Commfides/user_Person_Standard.crt", "Valid", null);
	}

	public void testNorwayBuypassNonRep() throws Exception
	{
		performTest("/certificates/Norway/Buypass/mhenNonRep.crt", "Valid", null);
	}

	public void testNorwayBuypassAuth() throws Exception
	{
		performTest("/certificates/Norway/Buypass/mhenAuth.crt", "Valid", null);
	}

	public void testNorwayBuypassJonOlnes() throws Exception
	{
		performTest("/certificates/Norway/Buypass/JONOLNES.crt", "Invalid", "ValidityInterval");
	}

	public void testNorwayBuypassJonOlnes2008() throws Exception
	{
		performTest("/certificates/Norway/Buypass/JONOLNES.crt", "Valid", null, "2008-01-09T11:26:29+01:00");
	}

/*
 // Doesn't work anymore, certificate is revoked
	public void testNorwayBuypassJonCertExchange() throws Exception
	{
		performTest("/certificates/Norway/Buypass/CertExchange.crt", "Valid", null, "2011-01-11T11:26:29+01:00");
	}
*/
	public void tearDown()
	{
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE = conf;;
	}

	public static void main(String[] args)
	{
	    try
	    {
	    	NorwayTest het = new NorwayTest("");
	    	het.setUp();
	    	het.testNorwayCommfides();
	    	het.tearDown();
		}
	    catch (Exception e)
	    {
			e.printStackTrace();
		}
	}
}
