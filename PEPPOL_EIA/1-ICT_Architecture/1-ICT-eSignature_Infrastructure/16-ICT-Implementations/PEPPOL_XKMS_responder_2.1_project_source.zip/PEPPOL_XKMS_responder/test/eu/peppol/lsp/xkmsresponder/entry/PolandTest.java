/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.security.cert.X509Certificate;
import java.util.logging.Logger;

import org.bouncycastle.util.encoders.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.inspectionTests.ResponderTestHelper;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;


/**
 * Tests for Italian certificates.
 * Contains three additional tests for requested CRL, certificate chain, OCSP responses.
 * One additional test for XKMS forward (mediated request).
 * @author buengener
 *
 */

public class PolandTest extends HttpEntryTest
{

	private final static Logger LOG = Logger.getLogger(PolandTest.class.getName());
	private String conf;
	private static final String SSL_CERT =
		"MIIFsTCCBJmgAwIBAgIDBxWdMA0GCSqGSIb3DQEBBQUAMHcxCzAJBgNVBAYTAlBMMSIwIAYDVQQK"
		+ "ExlVbml6ZXRvIFRlY2hub2xvZ2llcyBTLkEuMScwJQYDVQQLEx5DZXJ0dW0gQ2VydGlmaWNhdGlv"
		+ "biBBdXRob3JpdHkxGzAZBgNVBAMTEkNlcnR1bSBMZXZlbCBJSSBDQTAeFw0xMDA5MjAxMzA4MTla"
		+ "Fw0xMTA5MjExMzA4MTlaMFYxCzAJBgNVBAYTAnBsMSIwIAYDVQQDExlzdGFuZGFyZHZhLndlYm5v"
		+ "dGFyaXVzLmV1MSMwIQYJKoZIhvcNAQkBFhRpbmZvbGluaWFAdW5pemV0by5wbDCCASIwDQYJKoZI"
		+ "hvcNAQEBBQADggEPADCCAQoCggEBAJRVEzNae2XQFILD400rv7Jt2TyDBrXGdkerZMA6LqyI8iXj"
		+ "6NeaiY5rm1mLFQGuHHG2DTB29jBWyvvHiv3UaHPQWRXS5aIP0jXU/cX0up+UV4XPTbrknYQzwHik"
		+ "RbXMRmNfqYa34RutUjXJi9EhprYlHTVBORatCr7YtpmJS46Vw5eKKYsUo0sUipWWhrNfmZWsJbLf"
		+ "ALH6UGxqmUhWx4YDDzCC8RsSmiw8aA7a8cMNghmbX+zKufm1L8E4A0oZujR3dAkiTeA+NZK/AIO0"
		+ "cTk9TyYQczZ+hAD0O2iUwhunni0AOkWavaP08dx1YxvAMVmDfo35A0uQK3iL1Xdl/DECAwEAAaOC"
		+ "AmUwggJhMAsGA1UdDwQEAwIFoDA0BgNVHSUELTArBggrBgEFBQcDAQYIKwYBBQUHAwIGCisGAQQB"
		+ "gjcKAwMGCWCGSAGG+EIEATAdBgNVHQ4EFgQUY56D0yw+OhqqfC6C6QYg8RIvlCIwHwYDVR0jBBgw"
		+ "FoAUgGIR3sBrpxDhCPBVtDCDv/qPCGAwEQYJYIZIAYb4QgEBBAQDAgZAMCwGA1UdHwQlMCMwIaAf"
		+ "oB2GG2h0dHA6Ly9jcmwuY2VydHVtLnBsL2wyLmNybDBaBggrBgEFBQcBAQROMEwwIQYIKwYBBQUH"
		+ "MAGGFWh0dHA6Ly9vY3NwLmNlcnR1bS5wbDAnBggrBgEFBQcwAoYbaHR0cDovL3d3dy5jZXJ0dW0u"
		+ "cGwvbDIuY2VyMIIBPQYDVR0gBIIBNDCCATAwggEsBgoqhGgBhvZ3AgICMIIBHDAlBggrBgEFBQcC"
		+ "ARYZaHR0cHM6Ly93d3cuY2VydHVtLnBsL0NQUzCB8gYIKwYBBQUHAgIwgeUwIBYZVW5pemV0byBU"
		+ "ZWNobm9sb2dpZXMgUy5BLjADAgEBGoHAVXNhZ2Ugb2YgdGhpcyBjZXJ0aWZpY2F0ZSBpcyBzdHJp"
		+ "Y3RseSBzdWJqZWN0ZWQgdG8gdGhlIENFUlRVTSBDZXJ0aWZpY2F0aW9uClByYWN0aWNlIFN0YXRl"
		+ "bWVudCAoQ1BTKSBpbmNvcnBvcmF0ZWQgYnkgcmVmZXJlbmNlIGhlcmVpbiBhbmQgaW4gdGhlIHJl"
		+ "cG9zaXRvcnkKYXQgaHR0cHM6Ly93d3cuY2VydHVtLnBsL3JlcG9zaXRvcnkuMA0GCSqGSIb3DQEB"
		+ "BQUAA4IBAQDK8jSyLgl3z9tenagL1viKWWhQyH983C6cpZmmhl8XA3mRGW9PE0uhXbuUkXzOCKP5"
		+ "X+ziBB1TuLp7J1X24mm2ptzZT6C8MCPhjGuTRycwBLHbFgQSrEZcgJGnaNeYZgwNSt7bkHbgtjg+"
		+ "KHncu87QD1+UHO5kzEYMr+M5OhAsazbjw6UNfg+uL5hDZlS611eEPPY0WOUjoE6HGWnGKaY+5FsJ"
		+ "1hub8VJBZ7AACA+CMW0nTZzoPGM/6abwinlgVx9Be8ZxRPOTN6HCjc9VKefV7TOs4pN2feA10Lbq"
		+ "cFWbkUwqHSoL5ZYSlszrzz/awoRoCcyLm+MlvN0BbH2YlBsP";

	private static final String KEYSTORE =
	"MIACAQMwgAYJKoZIhvcNAQcBoIAkgASCA+gwgDCABgkqhkiG9w0BBwGggCSABIID6DCCBZowggWW"
	+ "BgsqhkiG9w0BDAoBAqCCBPowggT2MCgGCiqGSIb3DQEMAQMwGgQUFMKDmlGiheAfV+mZ4JYEyrJK"
	+ "/ocCAgQABIIEyFd2IutQS4Ms67wPLzLyYAZ0UusUtWehlk0zx1Lt2lGWYQbcKsfF8tikyCH2LgtS"
	+ "LqtGvyJFhr+ShYsGlUkf6bomd2iPolXZ/PkHcbK4bQaww4dnq/Umhm4gVb2nfvefE40EOHnv84JM"
	+ "kZGLcw1O5o6p/GMyyho/SpBawbn5yJhZ92E56fhbhMP/5M+uX1RiZxCE2bbSGTSj9X9w41ynThbe"
	+ "6fhRPqp3lYFKzPpxuT/JBEYpDAhuGAxYWuXPshuY1LaPOm3vApRb6ku2E8lN3jykk6xf0v1HThSa"
	+ "jZq79yr/0+m64JWlHV74Al143oTbdQVRJPzKJnXkWDiTuJxwGs1sWd31XThpvZTEgr6PIVszgTyw"
	+ "lqSTrv/LZjyclJIUvhr6SjF/XHtuY4jtVVEnA+nVv7gvTZxbSaNWmeQRB9rE6NQUAfNRvEF1IAoX"
	+ "avvO2n/S5wkmEFI0Mm+GaZJtl3yNiVJ3UdeTN1jIntNVUvlEXdaDwmqS9sguHnvxI4MJI+b6HDTy"
	+ "pSVtni5UYApFm3MvAm/ZbPB2OvMowhBuaOuDgV83Ozxa27lx1jV7XNdngNkYXIwn64ngvPtni/We"
	+ "Lsi7WiQYwqW7LvZSOpGMWcw36FDFhvHDufbnntLbE/GY4uEBINYd1oDIjjH6pKaao6jvkOTKlt0k"
	+ "OVHhYw840NJFZU2349lINZN8Q1zG8g30VrDl9VUgf9mZR7i/VDpDqwPbeM9Swivvel5xeNsC0S9D"
	+ "Aei4kvUFEQiuH695LElD1804tnV0bgNcnh8HccKBK57/8hD4/LoqYli9HCUdk7xFYYd37oKv30+c"
	+ "kVcYn7xNVg9oQvy2Bzkv1+eclnSyGphudb01Sb7sP6xu1CH5QrZn7odfCbuSnN80R1s2y3+DDWh5"
	+ "cx4K9WzvNb41+vZ/fFkN/u7lCW1NpH5Om9+b8iPtRWj7tVYsIL9IigEj6RHovolnzBe5uB2kpA1I"
	+ "qhL71askvIRVGS3kUQ0jtJ7LuitcSuCX2LqaJiFT+D+j0OvR09IoZIKETJBZtD3f3bN5C1EqO2uG"
	+ "SHPQm7n4ZXJ0fypJHTNLGuSTeJZ3kmNT31AZod/h+BN68r5XKuyQL1UApNfSrj8LZno20iMKSetO"
	+ "qdEN9aLQOYttu6ObKlzXcOPfKYrOmYvoSTGGniz0Q7CQpTqhGd2kvEMrWS/ScfUKa1kqft2sityb"
	+ "BIID6APoLLFWTnXgwRZcJcdxnospZ7dNAbWtBIIBtlRn8+WxZbLp+AKmghCJMGXUcpFq2/wSziBN"
	+ "K+RM8SAA/fD+91qs5jhfoJl3XzDV5a0o0aDEMtbxQxlTEKGIC8bu5z0ZWdlnFYBboghsNc4JmlcU"
	+ "M9rIFyoUgYxb3r9J46niWJgssPliRMx2+t1pqwdIshzgx7TWU7DKAcRwGsf8cU8R5hNyL7fYZjRV"
	+ "D/JZt76auRMcFMtGQJpm2mFsS/OdIbWasOsoHK5TTrOdMapNYH1xJ35qsjX1aHr79OjjwuKoL57j"
	+ "UhNH50WhB+Dd06qTj8Kc3WnpYgLTTmEQsF9i7P48DxK5cCBUiNlM7T3gODCyUirq7ilsgUHxBP5G"
	+ "55cJziN/fzNLWG4/GPYPxEVqRJDKYRTBkxORG/mI863bzHJ9sQpQzQokQi3lMYGIMCMGCSqGSIb3"
	+ "DQEJFTEWBBTHkM8iZzAGAJlH0frwAE7JDuFHkTBhBgkqhkiG9w0BCRQxVB5SAHAAZQByAHMAbwBu"
	+ "AGEAIABuAG8AdAAgAHYAYQBsAGkAZABhAHQAZQBkACAAKABjAGUAcgB0AHUAbQAgAGwAZQB2AGUA"
	+ "bAAgAGkAIABjAGEAKQAAAAAAADCABgkqhkiG9w0BBwaggDCAAgEAMIAGCSqGSIb3DQEHATAoBgoq"
	+ "hkiG9w0BDAEGMBoEFPa/cMKa0XtEbglTfHHkN/+yZxOeAgIEAKCABIID6Lzbj+5tXn+MSzXRk+B6"
	+ "okO3+WBREOs+Z63K/t9M+gIpQzgfxAKllyk4JVvqpfZtKJm/Hda4RmutHIP6i89ayKaPRbzOMw0S"
	+ "UP1G0qt/mVsaDgQelmHFNWrAdBHWl4clAIdp8gBjW97nRRtvLerJG+9nFPcCRti7YEIREUkk5DrC"
	+ "TbGRqFryCjK/yGh91Xh1AwDs05bHBQakVvRgBmfWwog7DKdC6fpUYFo+Nq2I8NvXYJwtGnXQ/9Yn"
	+ "7sYqjfEIwM2dRhi7GU5mgxCaAChkFMYyYT+CDWhZ43BJ9X49ENKgtqMU7Kku+YQwU/xQ+VVDg2Fy"
	+ "Vi8giuOTmNTHBH9RBBn+ei/8Yi8vSg0BqwCOM2OAOJWs37zAQo2F9endzzLPW1rxZG7jBtTdIQxY"
	+ "aHnEm3b39NLyMh1zPb4JMhb7tA15NWD3b8NnULhGhNNQl8JnVklJGZKQGOPtoeCUiPRcQ7pIt99Z"
	+ "yey/IYn+uZKP1u35BhTRRCB/jU4GmUU85FC+cE8SWkKjrMNc0IIcD2dcGka0eNnkJzEUJhRY0HCu"
	+ "UUmw8et1XFkNImkALH1x9z2erMeulxU782RkgzjTSLRJxpEEggPoATR4VqPklUU0LtXlBIGDJHqe"
	+ "sxmHMb16xKJz8SQVT6kxzSa0BAPRluVD1/Irw/b02ZSStcsyCgZu/kKXfTABtdfl+28flHpT3f6w"
	+ "8PJiaLnoweTrOcx+Lubmp0o87p/np8BtsdXcPFpL/b5utEDMGXeERYUy7N0nuSBeB3edKZvBSPDT"
	+ "xZqA8GYv2+b6Vxc3bBUNtsnr9ry24fdt7D+CCowcniyQhJq1ZTdFyYEFfHgZBdy7mUJydkFUfrb5"
	+ "JwoyYs4SAllIuuigk4mlgrJ4GbUpeP5IdwkVC4/0++KZUfzYRt+bpthfjuMJ1Lsdoz1GjIysNkZO"
	+ "rLjz9qKEup7homA0kPEGSTYbacWN3qv98iuZ8RyRJopou+m8O6O+q2Mwvuopqln+DEZL3bKaobWm"
	+ "TI+DYKagoSYv3tlaaLAivyMNAVguiG3Q8ZJSiY9fXS945U2s/kpiGhMvYASDA2cvsp/GrvE3F3mO"
	+ "d702Rgl9SdkhNL4kLuJqNEguIMiGf93GLqpM3telKaFhzlUKt/ufvz8rhYpCJyZVBjBH3EttBQXI"
	+ "/G+3bqeHZKvqofnOyx40nuV4nyZ06ie16+LW3Ol+28I9lCHayub85e7QQ0nZBmGKAIH1X/DFPJV9"
	+ "A6+WcEgHdOrmgWmvE73wu3uVBPPP0B0UWTXOtqZ8MWoevCsf66uajpV4/ZC+BtPhLlUToIQBe+AW"
	+ "zbN/VVCscrRayU3Ks+cmdcZNgsFBBIID6FhkXqcBaEbYZYjPKSEzyH/b/G0QEfp3dGLjchEaHy6C"
	+ "7/aFPMq4l6Jydg9CAwezyRUJYZljJVtTjDAR4wXIUfHIUEKusfnRvMwwvmSnnCZbkPf2voQI9TsU"
	+ "3fxPy+JYVKjeVkI3yn830Vi9q5LF95cO5VZ24e+cr31BbME/yv+uqUSid9v1rFnuveyFfUBhWphm"
	+ "1Ox60q+a7C4bGlg2OTQ0ir1Xwc9T1QFDn5gt1ZDLiIu66OD9t06BOFq0ezbxQkI2YYzglpBeTYvf"
	+ "ZBasIlBqhnxPgETiP4hQxDGTOhInG6CRRjkJjlxDQRDKj8P3JUJbsm5zZ7AIhGXwk5/pLzx+Lmhx"
	+ "UZYpSP5gM8RSoZGCBiK/Hniwou8m+aSU11u3pM6nG9mCxVCQb+to/NbbCl4a5AZ/F4G3UouG1rLh"
	+ "y+hjOPMwu4IiHw/0k6O8ouygALvq5QWkU5FvPN2h+PrugAz1yOGjdH+tg68cDYiO7Fwq9lcNdLu8"
	+ "IKeMYKfWd3qPFIt9oSGytqbtUYb9SHflXbSSStO6tQTz16urb0I3o+7BwVXYyGQoD2ydsHZL/F00"
	+ "7KZNi6jNwI3Ostt/3gSCA+i2OVnWqggetm8MnW46VCXEmTZxmc69yflWSsTngMaUdlYeCvuz73bI"
	+ "qxaANO99lX+JA+p+XPimm8efpZd2o6XG1DD8WzNU7OiQAltGZmBpP4iOgLwMXBYuFUfQcvnxMW9S"
	+ "ZuztI4HvhMaaAjqHs7507Kl4p7cwpBeIBxYjxwXNcAL4QBaE4pusiGZN6VWl8A5hNW2WDaWgvPb4"
	+ "/CAq2XYv7rrx8q9SHcCHsSLZpPQoYTAQ6ELaRryNA+lUKypP69ny8OujAocpBm7QUegXWk3q/E2l"
	+ "B3R2pp8neLGBOKerCf7N/1rjOm3iclgITvL/Jbyu5D0AK7d+6hCrSU5JNrIQOklUAYzdZmHc7ZW+"
	+ "lwiF4R5y7VnT0h48NfA5+c9cGDsiZGOZpspjDR8AGp8Y80/YvTKnchoU6oyeNE08zrrkZpcNmwHw"
	+ "l+6KET53xTc47T4YEJErbYjYKK+KX9bXZiUE8ASJ2bjdtdxaL80spRwjnl+OEQnQZW5SVU9vIRFm"
	+ "RdrulUYjTt+VZTW+GYg0u21KAwnGRGMUmjwn9aFBms9ipotvM2hpbwKKVHAxWEitlndZYDZk6bLM"
	+ "sndVa8DOsp47DY7MKQ1BhHZW7tqUOB43KfK62tWL8zJv9m16OuPFNr1mAvsSy9UhZOX5jkWEPtYb"
	+ "Us6UsNuvMU+1yUq+u/w8IUw3qlssqBNdKczTDXIfgmb91AJoDoDc9WCLcc6eqL3L/I/ZFMarYMow"
	+ "RT/VBIID6J3r7mOLB4NVA1cVD7j97aIBL1mU9PLzIcOiCo8miIdzZAMQ7The51zKb5KbspnQwv/4"
	+ "7tIoxqUllJInj6JtuCydYy4N3NdCGZxywYg/WFkbDVewR7WQK29/MDxgu7E4PsCVxc/S9j6kyv6B"
	+ "MkFYCi/fB8bif239lUdilzAAyXSVRGQudltKBCIYm9z0dvffv4PTBbWlVkLKNL8ywZTFn8lPT9aN"
	+ "wmwv4jJpy12A/Tx642D9tQgAqvr5/qcuLICuZX15hRC1x8T3EvbrCnJMN1Jqqrsw50sHTL8Jpt9M"
	+ "aHPMK7ZKe8+ltnrTy0d/vJGtAiulmHoNoMc6PxzddOoU1/xW/jL9SpfCZ0v8KPSzxYuuOhZbYE+N"
	+ "g1Nfk0gXYIJvAq0ri2r7AtOXoSluYlh7tFMdMNNAhocCLECvus12A/uwxhzem5oWF/URBGWPprFM"
	+ "pMZcfFmK6XVdkfjLyi3uqnCmIX9hreIRmzmde42fO2E9d7QSFRBZg4ONTBHQTTC8zFaSH5oCfufC"
	+ "qM3ZC5HB1qx1v8IC5u1MCfEcRsZQDBHT1ccc9xzgYYBTydU45t18gjc9dKiRYKuTBIID6EeSbUCw"
	+ "qbz1P2euj8QAjXria+0iN4ZEKnI96D+vaVlGiOXP/0iJ63A0dEs5husB5GvItMQxURlYjAWJWeh/"
	+ "sTCWJLKJR7KQJ22M5M2HRpVikdq4YGfHrKlhS/qq+xv2iyzjPIIYefm0P7bQruz1M+/peroqcEgF"
	+ "F+f/MhE/0SYw+5FxUWJV0Gycxy3HB5q6oLrFtcEP3Hy5TCw6EEJO04s6u+el5Jl4GgCLU6Q4shyz"
	+ "9NyykJAit8JVRtelKWQD0FFljDvmtLXLLdGJiclgM2mK5s9jDJwG+5lfKVlxf3aaCjoHx5opZ/X1"
	+ "kyUgR4IDp/tq1OIdEIX9BOWQiqJDdcI1sZOZNMKosCg/FFnfPKZpVgH58pt9zE82OQokI0E8Hn32"
	+ "L0WAaIe2Xrf061c++e8SpaLaLMwax6soxkTuwZA5T/jdEcVOS/w2HJgnSS8ALjcawDd7BEYY2hRD"
	+ "7Pal+tXGDGsOUbzBN9kZ1E2NzCmoDC/Rv5SGN7MjtxRbT7JiaML8VKn4BljVHzuerw9zR2O7xnWN"
	+ "9SlzmvxRRf3ZQU/X5GL4N/dfZyHIatKvl+mbz4qYyapQ0yyzoI+842cvYe/m8wN6tgPM0niKUqLb"
	+ "WtNHR5KGie9X4mqFCIQSJDulsNhg5DV4ts4zzacvJDr9kjmawIEKXnLSFFXIO+g5aVdQ/RoA1F1h"
	+ "cpbzDqwxJcbAfKWMKzl37hlvGX4I3JY2vIXrIYUpc+Q/2WW9kKjsWZbWBIICiMkgQRvuxvDIijEK"
	+ "U5yKvjcwvtOG9Cmhl39y5RIeX34RiqiAvkmnh6ZUv1N8iulQPcNr95rzlRlpb19ySjgHCmBQwKGR"
	+ "daw08Ym5xO5MNpzwBjgsnYchxn26RzFZK+hYQfaWNiBGz2jft1qURMcrBeL4BWUoYL1eom5U1M+D"
	+ "OYmwuCUHW5RtSHvdg0WkqU5y3o2QJ1YOdNKKZqM6E3pYwEnTL8NAczPvK3XNPCi6/OHEOSlVtkWm"
	+ "ZnsfvSWJkqgWTFF6vCuzJG2H3g28j4kwgkDw/RiZWRPFvVz3F+jBQWSoSPULABpzzivtayE7j29t"
	+ "kLwhizEGw/REUWT7moJOL9Buc/yB+KceWq++9aZaruw1s4b000Cwt2DlROiicVE5xDWIBx4ZGr+m"
	+ "yaUq6qlXLL/04CcnoAATSeQK0i0GQYn0HSiMbXLtrU8M9Sph5VCjzq0jkFwGs8z8j+7+fngfbCZG"
	+ "Ehsc5GTPwC8NsoAJ9Q89gh6ZX+5FCdPcwzSu9PzJjsq/0w/dlmDAQrMQBDOID/14B6KwCollGoXi"
	+ "mZouLn5ZyJP7jvOkGAj2Lre+uNbgRAYqMXoEgeDZ2A49Qtsp5MGVMvnRG8wg2GcVcuUjOf9WBehK"
	+ "4EWCPUoA9zgIQdMx7z/OMdf8TAHAhI7Xl5+vEWInEIPu9ixa+vP4vcbKFRt90wMB68FwnmaytV7Y"
	+ "AcUptrxyuQsqQc85cXpy05rjyNtUIIRuujs5XbiWt8qkqmwbauaFmBZ5EnlE3E+dCqMweNBn+tlM"
	+ "5id6EF+1tnN+BYSOteCBX+wm0L03dY/JUF6V4x18LB1+S7Uj5Q29ZmRzm+5cco8spqgOh1koHIg/"
	+ "KWzG4w4MQb9rO8h2OgAAAAAAAAAAAAAAAAAAAAAAADA9MCEwCQYFKw4DAhoFAAQU6+2zbGaYEiiz"
	+ "A6b8KYGfo2+15rEEFBoUwONkSpMPuXaaxgTxFLgn2NrvAgIEAAAA";
	public PolandTest(String name)
	{
		super(name);
	}

	public void setUp()
	{
		conf = ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE;

		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("</TACertificates>", "<TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\"><X509Certificate>" + SSL_CERT + "</X509Certificate></TACertificate></TACertificates>");
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("alias=\".*?\"", "alias=\"persona not validated (certum level i ca)\"");
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("<keystore>.*?</keystore>", "<keystore>"+ KEYSTORE + "</keystore>");

		System.err.println(ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE);
//	  	"<TACertificates><TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\">"
//	  	+ "<X509Certificate>" +  SSL_CERT + "</X509Certificate></TACertificate></TACertificates>"
//	  	+ "<Proxy timeout=\"30"
//	  	+ "\" password=\"" + props.getProperty("responder_proxyPassword", "")
//	  	+ "\" nonProxyHosts=\"" + props.getProperty("responder_nonProxyHosts", "")
//	  	+ "\" username=\"" + props.getProperty("responder_proxyUsername", "")
//	  	+ "\" proxyPort=\"" + props.getProperty("responder_proxyPort", "")
//	  	+ "\" proxyHost=\"" + props.getProperty("responder_proxyHost", "")
//	  	+ "\"/><Signature pin=\"" + props.getProperty("responder_keystorePin", "")
//	  	+ "\" alias=\"" + props.getProperty("responder_keystoreAlias", "")
//	  	+ "\"><keystore>" + props.getProperty("responder_keystore", "")
//	  	+ "</keystore></Signature>";

		uploadConfig("/eu/peppol/lsp/xkmsresponder/entry/PeppolTestConfig_PL.xml");
		super.setUp();
	}

	public void tearDown()
	{
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE = conf;;
	}

	public void testPolandLisitValid() throws Exception
	{
		performTest("/certificates/Poland/Unizeto/unizetoTestUser.cer", "Valid", null, "2011-02-09T11:26:29+01:00");
	}

	public static void main(String[] args)
	{
		try
	    {
			PolandTest het = new PolandTest(null);
	    	het.setUp();
	    	het.testPolandLisitValid();
	    	het.tearDown();

//			System.err.println(ResponderHelper.toHexString(Base64.decode(SSL_CERT)));
//			System.err.println(ResponderHelper.toHexString(ResponderHelper.createCertificate(Base64.decode(SSL_CERT)).getEncoded()));


//			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
//				ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replace("<X509Certificate>.*</X509Certificate></TACertificate>",
//						"<X509Certificate>PUFF</X509Certificate></TACertificate>");
//			System.err.println(ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("<X509Certificate>.*?</X509Certificate>", "<X509Certificate>RUMMS</X509Certificate>"));
//			System.err.println(ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("alias=\".*?\"", "alias=\"BUMM\""));
//			System.err.println(ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("<keystore>.*?</keystore>", "<keystore>BOING</keystore>"));
//			System.err.println(ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE);
//			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
//				ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replace("<keystore>.*</keystore>", "RUMMS");
		}
	    catch (Exception e)
	    {
			e.printStackTrace();
		}
	  }
}
