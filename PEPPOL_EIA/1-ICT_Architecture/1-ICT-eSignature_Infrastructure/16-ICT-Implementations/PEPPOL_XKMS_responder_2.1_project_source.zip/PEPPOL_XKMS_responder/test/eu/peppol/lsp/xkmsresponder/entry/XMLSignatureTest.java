/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.io.FileOutputStream;
import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import junit.framework.TestCase;

import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.keys.keyresolver.KeyResolverException;
import org.apache.xml.security.signature.XMLSignature;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.requestcontroller.XKMSSignature;

/*
 * <p>XMLSignatureTest</p> <p>Tests to check the XML signature.</p>
 * @author Andre Jens
 * @author Nils Buengener
 */
public class XMLSignatureTest extends TestCase
{
  private static final Logger LOG = Logger.getLogger(XMLSignatureTest.class.getName());

  private static final String SIG_NAMESPACE = "ds";

  private static final String XPATH_TO_SIGNATURE = "//ds:Signature";

  static void createSignedDoc() throws Exception
  {
	  FileOutputStream fos = new FileOutputStream("CompoundRequest_fehlerhafte_Signatur.xml");
	  fos.write(XKMSSignature.signXKMS(XMLSignatureTest.class
			  .getResourceAsStream("/eu/peppol/lsp/xkmsresponder/entry/CompoundRequest.xml"), "_db70e1b2-eb2f-4016-b85c-c0853fe061f1"));
	  fos.close();
  }

  public static void checkAndLogSig(byte[] sig) throws Exception
  {
    Document doc = createDOM(sig);
    NodeList validateRequest = doc.getElementsByTagNameNS("http://www.w3.org/2002/03/xkms#", "CompoundResult");
    if (validateRequest.getLength() == 0)
        validateRequest = doc.getElementsByTagNameNS("http://www.w3.org/2002/03/xkms#", "ValidateResult");

    DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
    doc = docBuilder.newDocument();
    doc.appendChild(doc.importNode(validateRequest.item(0), true));

    NodeList signatureNodesList = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature");
    LOG.fine("count of signature entries: " + signatureNodesList.getLength());

    if (signatureNodesList.getLength() == 0)
    	fail("No signature found");

    for (int i = 0; i < signatureNodesList.getLength(); i++)
    {
      LOG.fine("checkAndLogSig Signature nr: " + i);

      Element sigElement = (Element) signatureNodesList.item(i);
      XMLSignature signature = new XMLSignature(sigElement, "");
      KeyInfo ki = signature.getKeyInfo();
      X509Certificate cert = findCertificate(ki);
      if (cert != null)
      {
        assertTrue("Signature check", signature.checkSignatureValue(cert.getPublicKey()));
      }
      else
    	  fail("Kein Signaturzertifikat in Signatur");
    }
  }


  public static Document createDOM(byte[] _data) throws Exception
  {
    java.io.ByteArrayInputStream ins = null;

    try
    {
      LOG.fine("(start) createDOM(__)");

      javax.xml.parsers.DocumentBuilderFactory dbf = javax.xml.parsers.DocumentBuilderFactory.newInstance();
      dbf.setNamespaceAware(true);

      javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();
      ins = new java.io.ByteArrayInputStream(_data);

      Document doc = db.parse(ins);
      LOG.fine("return doc");

      return doc;
    }
    finally
    {
      if (ins != null)
      {
        try
        {
          ins.close();
        }
        catch (IOException e)
        {
          LOG.fine("Can't close stream");
        }
      }

      LOG.fine("(end) createDOM()");
    }
  }

  private static X509Certificate findCertificate(KeyInfo keyInfo)
  {
    X509Certificate cert = null;

    try
    {
      if (keyInfo.containsX509Data())
      {
        LOG.fine("Contains!!!");
        cert = keyInfo.getX509Certificate();
      }
    }
    catch (KeyResolverException ex)
    {
      LOG.log(Level.SEVERE, "error", ex);
      return null;
    }

    return cert;
  }

}
