/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.inspectionTests;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;

import org.bouncycastle.ocsp.CertificateID;
import org.bouncycastle.ocsp.OCSPException;
import org.bouncycastle.util.encoders.Base64;
import org.w3._2000._09.xmldsig.KeyInfoType;
import org.w3._2000._09.xmldsig.X509DataType;
import org.w3._2002._03.xkms.CompoundRequestType;
import org.w3._2002._03.xkms.CompoundResultType;
import org.w3._2002._03.xkms.KeyBindingType;
import org.w3._2002._03.xkms.QueryKeyBindingType;
import org.w3._2002._03.xkms.ResultType;
import org.w3._2002._03.xkms.StatusType;
import org.w3._2002._03.xkms.TimeInstantType;
import org.w3._2002._03.xkms.ValidateRequestType;
import org.w3._2002._03.xkms.ValidateResultType;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.dto.SignatureTokenDto;
import eu.peppol.lsp.xkmsresponder.requestcontroller.XKMSSignature;
import eu.peppol.lsp.xkmsresponder.xkms.NamespacePrefixMapperImpl;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSContextHolder;
import eu.peppol.uri.xkmsext.v2.ObjectFactory;
import eu.peppol.uri.xkmsext.v2.ValidateRequestExtEUType;


public class ResponderTestHelper
{
  protected static final Logger LOG = Logger.getLogger(ResponderTestHelper.class.getName());

  public static String RESPONDER_PROXY_AND_SIGNATURE;

  public static String LOCAL_PROXY_HOST = null;

  public static int LOCAL_PROXY_PORT = 0;

  public static String URL_VALIDATION;

  public static String URL_ADMIN;

  private static final String CONTENT_TYPE_HEADER = "Content-Type";

  private static final String ACCEPT_HEADER = "Accept";

  private static byte[] SOAP_START;

  private static byte[] SOAP_END;

  private static Proxy proxy;

  public static SignatureTokenDto signatureTokenDto;

  // Some tests use this Proxy
  public static class Proxy
  {
    String proxyHost = "";

    int proxyPort;

    URL server = null;

    /**
     * @param inpServer
     * @param inpProxyHost
     * @param inpProxyPort
     */
    public Proxy(URL inpServer, String inpProxyHost, int inpProxyPort)
    {
      super();
      server = inpServer;
      proxyHost = inpProxyHost;
      proxyPort = inpProxyPort;
    }

    public String getProxyHost()
    {
      return proxyHost;
    }

    public int getProxyPort()
    {
      return proxyPort;
    }

    public URL getServer()
    {
      return server;
    }
  }

// Static initializer to make properties available
  static
  {
	  try
	  {
		  SOAP_START =
		        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Body>".getBytes("UTF-8");

		  SOAP_END = "</soapenv:Body></soapenv:Envelope>".getBytes("UTF-8");
		  proxy = setUp();
	  }
	  catch (Exception e)
	  {
		  LOG.log(Level.SEVERE, "Failed to read test.properties.", e);
	  }
  }

  /**
   * Creates a new Helper object.
   */
  private ResponderTestHelper()
  {
  }

  /**
   * Read the Proxy properties from "test.properties" and return a Proxy-Object
   * @return a Proxy-Object with the Proxy-Configuration
   * @throws Exception
   */
  public static Proxy getProxy() throws Exception
  {
	  return proxy;
  }

  /**
   * Read the Proxy properties from the given file and return a Proxy-Object
   * @param inpPropertiesFileName the filename to read the properties from
   * @return a Proxy-Object with the Proxy-Configuration
   * @throws Exception
   */
  protected static Proxy setUp() throws Exception
  {
    LOG.fine("setUp() setting up connection values with properties from test.properties");
    Properties props = new Properties();

    try
    {
      InputStream inprop = ResponderTestHelper.class.getResourceAsStream("/test.properties");
      props.load(inprop);
    }
    catch (Exception e)
    {
      LOG.info("No test.properties file found !");
    }

    if (props.getProperty("proxyHost") != null
    		&& props.getProperty("proxyHost").trim().length() != 0)
    {
	    LOCAL_PROXY_HOST = props.getProperty("proxyHost");
	    LOCAL_PROXY_PORT = Integer.parseInt(props.getProperty("proxyPort", "0"));
    }

    URL_VALIDATION = props.getProperty("url_validation",
                                  "http://127.0.0.1:8080/PeppolXKMSResponder/validate");

    URL_ADMIN = props.getProperty("url_admin",
                                  "http://127.0.0.1:8080/PeppolXKMSResponder/WebAdmin");

     LOG.fine("setUp() connection values: server=" + URL_VALIDATION + "; proxyHost=" + LOCAL_PROXY_HOST + "; proxyPort="
              + LOCAL_PROXY_PORT);

     RESPONDER_PROXY_AND_SIGNATURE =
  	  	"<TACertificates><TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\">"
  	  	+ "<X509Certificate>" +  props.getProperty("ta_certificate") + "</X509Certificate></TACertificate>"
 	  	+ "<TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\">"
 	  	+ "<X509Certificate>" +  props.getProperty("ta_certificate_pprs") + "</X509Certificate></TACertificate>"
 	  	+ "<TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\">"
 	  	+ "<X509Certificate>" +  props.getProperty("ta_certificate_eu_tsl") + "</X509Certificate></TACertificate>"
 	  	+ "<TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\">"
 	  	+ "<X509Certificate>" +  props.getProperty("ta_certificate_eu_ssl") + "</X509Certificate></TACertificate></TACertificates>"
 	  	+ "<Proxy timeout=\"" +  props.getProperty("responder_proxyTimeout", "30")
 	  	+ "\" password=\"" + props.getProperty("responder_proxyPassword", "")
 	  	+ "\" nonProxyHosts=\"" + props.getProperty("responder_nonProxyHosts", "")
 	  	+ "\" username=\"" + props.getProperty("responder_proxyUsername", "")
 	  	+ "\" proxyPort=\"" + props.getProperty("responder_proxyPort", "")
 	  	+ "\" proxyHost=\"" + props.getProperty("responder_proxyHost", "")
 	  	+ "\"/><Signature pin=\"" + props.getProperty("responder_keystorePin", "")
 	  	+ "\" alias=\"" + props.getProperty("responder_keystoreAlias", "")
 	  	+ "\"><keystore>" + props.getProperty("responder_keystore", "")
 	  	+ "</keystore></Signature>";

     signatureTokenDto = new SignatureTokenDto();
     signatureTokenDto.setData(org.apache.xml.security.utils.Base64.decode(props.getProperty("responder_keystore", "")) );
     signatureTokenDto.setAlias(props.getProperty("responder_keystoreAlias", ""));
     signatureTokenDto.setPin(props.getProperty("responder_keystorePin", ""));

     return new Proxy(new URL(URL_VALIDATION), LOCAL_PROXY_HOST, LOCAL_PROXY_PORT);
  }

  /**
   * DOCUMENT ME!
   *
   * @param checkCert DOCUMENT ME!
   * @param timeInstance DOCUMENT ME!
   * @param respondWith DOCUMENT ME!
   * @param ocspNoCache DOCUMENT ME!
   * @param advancedRespondSubject DOCUMENT ME!
   * @param advancedRespondIssuer DOCUMENT ME!
   * @param advancedRespondExtension DOCUMENT ME!
   * @param keyUsage DOCUMENT ME!
   * @param requestID DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static ValidateRequestType createXKMSRequest(X509Certificate[] checkCert,
                                                      GregorianCalendar timeInstance,
                                                      ArrayList<String> respondWith, boolean ocspNoCache,
                                                      ArrayList<String> keyUsage, String requestID)
  {
    KeyInfoType keyInfo = null;
    org.w3._2000._09.xmldsig.ObjectFactory tmpObjectFactory =
          new org.w3._2000._09.xmldsig.ObjectFactory();
    try
    {
      // add certificate and TimeInstance to ValidateRequest
      X509DataType x509Data = new X509DataType();
      keyInfo = new KeyInfoType();
      for (X509Certificate tmpElement : checkCert)
      {
        JAXBElement<byte[]> cert = tmpObjectFactory.createX509DataTypeX509Certificate(tmpElement.getEncoded());
        x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().add(cert);
      }
      JAXBElement<X509DataType> tmpDataElement = tmpObjectFactory.createX509Data(x509Data);
      keyInfo.getContent().add(tmpDataElement);

      QueryKeyBindingType queryKeyBinding = new QueryKeyBindingType();
      queryKeyBinding.setKeyInfo(keyInfo);

      if ((keyUsage != null) && (keyUsage.size() > 0))
      {
        for (int ti = 0; ti < keyUsage.size(); ti++)
        {
          queryKeyBinding.getKeyUsage().add(keyUsage.get(ti));
        }
      }

      if (timeInstance != null)
      {
        TimeInstantType timeInstant = new TimeInstantType();
        timeInstant.setTime(DatatypeFactory.newInstance().newXMLGregorianCalendar(timeInstance));
        queryKeyBinding.setTimeInstant(timeInstant);
      }

      ObjectFactory of = new ObjectFactory();
      ValidateRequestType request = new ValidateRequestType();
      ValidateRequestExtEUType vreet = new ValidateRequestExtEUType();
      vreet.setRequestingNodeChain(of.createRequestingNodeChainType());
      request.getMessageExtension().add(of.createValidateRequestExtEU(vreet));
      request.setQueryKeyBinding(queryKeyBinding);
      // add RequestID
      //    request.setId("d76WZIjk3AIJj5m3sgxT");
      request.setId(requestID);
      request.setService("http://test.xmltrustcenter.org/XKMS");

      // add RespondWith Information
      if (respondWith != null)
        for (String element : respondWith)
            request.getRespondWith().add(element);

      return request;
    }
    catch (RuntimeException ex)
    {
      System.err.println("Error while creating XKMS-Request. ");
      ex.printStackTrace();
    }
    catch (Exception ex)
    {
      System.err.println("Error while creating XKMS-Request. ");
      ex.printStackTrace();
    }

    return null;
  }

  /**
   * DOCUMENT ME!
   *
   * @param checkCert DOCUMENT ME!
   * @param timeInstance DOCUMENT ME!
   * @param respondWith DOCUMENT ME!
   * @param ocspNoCache DOCUMENT ME!
   * @param advancedRespondSubject DOCUMENT ME!
   * @param advancedRespondIssuer DOCUMENT ME!
   * @param advancedRespondExtension DOCUMENT ME!
   * @param keyUsage DOCUMENT ME!
   * @param requestID DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static ValidateRequestType createXKMSRequest(X509Certificate checkCert,
                                                      GregorianCalendar timeInstance,
                                                      ArrayList<String> respondWith, boolean ocspNoCache,
                                                      ArrayList<String> keyUsage, String requestID)
  {
    return createXKMSRequest(new X509Certificate[] { checkCert }, timeInstance, respondWith, ocspNoCache,
                             keyUsage, requestID);
  }

  /**
   * DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  @SuppressWarnings("unchecked")
  public static ByteArrayOutputStream prepareRequest(Object request)
  {
    try
    {
//      JAXBContext jc = javax.xml.bind.JAXBContext.newInstance("de.bos_bremen.governikus2.xkms2");
      Marshaller m = XKMSContextHolder.getSingleton().getMarshaller();  // jc.createMarshaller();

      // Unmarshaller um = jc.createUnmarshaller();
      ByteArrayOutputStream bout = new ByteArrayOutputStream();
      m.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapperImpl());
      m.setProperty(Marshaller.JAXB_FRAGMENT, true);

      if (request == null)
      {
        System.out.println("Request is NULL");
        LOG.severe("Request is NULL");
      }
      else
      {
        if (request instanceof CompoundRequestType)
        {
          m.marshal(new JAXBElement(new QName("http://www.w3.org/2002/03/xkms#", "CompoundRequest"),
                                    request.getClass(), request), bout);
        }
        else
        {
          m.marshal(new JAXBElement(new QName("http://www.w3.org/2002/03/xkms#", "ValidateRequest"),
                                    request.getClass(), request), bout);
        }
      }
      System.out.println("request: " + new String(bout.toByteArray()));
      return bout;
    }
    catch (Exception ex)
    {
      System.out.println("Fehler: " + ex);
      ex.printStackTrace();
    }

    return null;
  }

  public static byte[] prepareSoapOutputStream(ByteArrayOutputStream bout, String sigId)
  {
	  return prepareSoapOutputStream(bout.toByteArray(), sigId);
  }

  /**
   * DOCUMENT ME!
   *
   * @param bout DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static byte[] prepareSoapOutputStream(byte[] bout, String sigId)
  {
    try
    {
  	  XKMSSignature.reloadSignatureKey(ResponderTestHelper.signatureTokenDto);

  	  byte[] out = XKMSSignature.signXKMS(new ByteArrayInputStream(bout), sigId);

  	  int start_len = SOAP_START.length;
  	  int out_len = out.length;
  	  byte[] ret = new byte[start_len + out_len + SOAP_END.length];
  	  System.arraycopy(SOAP_START, 0, ret, 0, SOAP_START.length);
  	  System.arraycopy(out, 0, ret, start_len, out.length);
  	  System.arraycopy(SOAP_END, 0, ret, start_len + out_len, SOAP_END.length);

//      System.out.println("Request with Soap-Header: " + new String(ret));
      return ret;
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Fehler: ", ex);
    }

    return null;
  }

  /**
   * DOCUMENT ME!
   *
   * @param resp DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static Hashtable<String, Object> parseResponse(String resp)
  {
    try
    {
    	Unmarshaller um = XKMSContextHolder.getSingleton().getUnmarshaller();
      Hashtable<String, Object> results = new Hashtable<String, Object>();
      LOG.fine("Response in parseResponse: \n" + resp);

      if (resp.indexOf("<Fault>") > -1)
      {
        int t1 = resp.indexOf("<ResultMajor>") + 13;
        int t2 = resp.indexOf("</ResultMajor>");
        LOG.fine("ResultMajor:" + resp.substring(t1, t2));
        results.put("FaultMajor", resp.substring(t1, t2));

        int t3 = resp.indexOf("<ResultMinor>") + 13;
        int t4 = resp.indexOf("</ResultMinor>");
        LOG.fine("ResultMinor:" + resp.substring(t3, t4));
        results.put("FaultMinor", resp.substring(t3, t4));

        return results;
      }

      int t1 = resp.indexOf("<soapenv:Body>");
      t1 += "<soapenv:Body>".length();

      int t2 = resp.indexOf("</soapenv:Body>");
      //      System.out.println("t1 : " + t1 + " t2:" + t2);

      String xkmsResponse = resp.substring(t1, t2);

      if (xkmsResponse.indexOf("<soapenv:Fault>") > -1)
      {
    	  results.put("FaultCode", xkmsResponse.substring(xkmsResponse.indexOf("<soapenv:Code>"),
    			  xkmsResponse.indexOf("</soapenv:Code>")));
    	  results.put("FaultReason", xkmsResponse.substring(xkmsResponse.indexOf("<soapenv:Text"),
    			  xkmsResponse.indexOf("</soapenv:Text>")));
    	  return results;
      }

      // System.out.println("xkmsResponse: " + xkmsResponse);
      System.out.println("before UnMarshaler");

      ByteArrayInputStream bin = new ByteArrayInputStream(xkmsResponse.getBytes());
      JAXBElement<?> tmpElement = (JAXBElement<?>) um.unmarshal(bin);

      Object o = tmpElement.getValue();

      if (ValidateResultType.class.isAssignableFrom(o.getClass()))
      {
        System.out.println("ValidateResult");

        ValidateResultType result = (ValidateResultType) o;
        results.put(result.getRequestId(), result);
      }
      else if (CompoundResultType.class.isAssignableFrom(o.getClass()))
      {
        System.out.println("CompoundResult");

        CompoundResultType compound = (CompoundResultType) o;
        for (ResultType result : compound.getLocateResultOrValidateResultOrRegisterResult())
        {
          ValidateResultType validateResult = (ValidateResultType) result;
          results.put(validateResult.getRequestId(), validateResult);
        }
      }
      else
      {
        System.out.println("Can not parse result !!!");
      }

      return results;
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Error in parseResponse:", ex);
      System.out.println("Fehler:");
      ex.printStackTrace();
    }

    return null;
  }

  /**
   * DOCUMENT ME!
   *
   * @param _response DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   *
   * @throws Exception DOCUMENT ME!
   */
  public static ResultType parseXKMSResponse(String _response) throws Exception
  {
    if (_response == null)
    {
      throw new Exception("Response ist null!");
    }

    if (_response.indexOf("<soapenv:Body/>") != -1)
    {
      throw new Exception("Soap-Body ist leer! Ist das Relay in 'Betrieb'?");
    }

    int r1 = _response.indexOf("<soapenv:Body>") + "<soapenv:Body>".length();
    String xkmsresp = _response.substring(r1, _response.indexOf("</soapenv:Body>"));
    ByteArrayInputStream inStream = null;
    inStream = new ByteArrayInputStream(xkmsresp.getBytes("UTF-8"));

    Unmarshaller unmarshaller = XKMSContextHolder.getSingleton().getUnmarshaller(); //jaxbContext.createUnmarshaller();
    Object tmpUnmarshal = unmarshaller.unmarshal(inStream);
    @SuppressWarnings("unchecked")
    JAXBElement<ResultType> tmpJAXBElement = (JAXBElement<ResultType>) tmpUnmarshal;
    ResultType resOb = tmpJAXBElement.getValue();

    return resOb;
  }

  /**
   * DOCUMENT ME!
   *
   * @param issuerCert DOCUMENT ME!
   * @param userCert DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   *
   * @throws OCSPException DOCUMENT ME!
   */
  public static CertificateID buildID(final X509Certificate issuerCert, final X509Certificate userCert)
        throws OCSPException
  {
    CertificateID id = null;

    try
    {
      id = new CertificateID(CertificateID.HASH_SHA1, issuerCert, userCert.getSerialNumber());
    }
    catch (OCSPException ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.SEVERE, "Can't create CertificateID", ex);
      }

      throw ex;
    }

    return id;
  }

  /**
   * DOCUMENT ME!
   *
   * @param inpValidateResultImpl DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   *
   * @throws Gov2InternalException DOCUMENT ME!
   * @throws CertificateException
   */
  public static X509Certificate getCertificate(ValidateResultType inpValidateResult)
        throws Exception, CertificateException
  {
    KeyBindingType keyb = inpValidateResult.getKeyBinding().get(0);
    @SuppressWarnings("unchecked")
    JAXBElement<X509DataType> tmpX509DataElement =
          (JAXBElement<X509DataType>) keyb.getKeyInfo().getContent().get(0);
    X509DataType data = tmpX509DataElement.getValue();
    @SuppressWarnings("unchecked")
    JAXBElement<byte[]> tmpX509CertificateElement =
          ((JAXBElement<byte[]>)data.getX509IssuerSerialOrX509SKIOrX509SubjectName().get(0));
    X509Certificate rcert = null;
    rcert = ResponderHelper.createCertificate(tmpX509CertificateElement.getValue());

    return rcert;
  }

  /**
   * DOCUMENT ME!
   *
   * @param inpValidateResult DOCUMENT ME!
   * @param inpValue DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static boolean checkStatusValue(ValidateResultType inpValidateResult, String inpValue)
  {
    StatusType tmpStatus = getStatus(inpValidateResult);

    if (tmpStatus.getStatusValue().indexOf(inpValue) != -1)
    {
      return true;
    }

    return false;
  }

  /**
   * DOCUMENT ME!
   *
   * @param inpValidateResult DOCUMENT ME!
   * @param inpReasonType DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static boolean checkValidReason(ValidateResultType inpValidateResult, String inpReasonType)
  {
    Iterator<String> tmpReasonIterator = getStatus(inpValidateResult).getValidReason().iterator();

    return checkReasonType(inpReasonType, tmpReasonIterator);
  }

  /**
   * DOCUMENT ME!
   *
   * @param inpValidateResult DOCUMENT ME!
   * @param inpReasonType DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static boolean checkInValidReason(ValidateResultType inpValidateResult, String inpReasonType)
  {
    Iterator<String> tmpReasonIterator = getStatus(inpValidateResult).getInvalidReason().iterator();

    return checkReasonType(inpReasonType, tmpReasonIterator);
  }

  /**
   * DOCUMENT ME!
   *
   * @param inpValidateResult DOCUMENT ME!
   * @param inpReasonType DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  public static boolean checkIndeterminateReason(ValidateResultType inpValidateResult, String inpReasonType)
  {
    Iterator<String> tmpReasonIterator = getStatus(inpValidateResult).getIndeterminateReason().iterator();

    return checkReasonType(inpReasonType, tmpReasonIterator);
  }

  /**
   * @param inpValidateResult
   * @return
   */
  private static StatusType getStatus(ValidateResultType inpValidateResult)
  {
    KeyBindingType keyb = inpValidateResult.getKeyBinding().get(0);
    StatusType tmpStatus = keyb.getStatus();

    return tmpStatus;
  }

  /**
   * @param inpReasonType
   * @param inpValidReasonIterator
   * @return
   */
  private static boolean checkReasonType(String inpReasonType, Iterator<String> inpValidReasonIterator)
  {
    while (inpValidReasonIterator.hasNext())
    {
      String element = inpValidReasonIterator.next();

      if (element.indexOf(inpReasonType) != -1)
      {
        return true;
      }
    }

    return false;
  }

  public static byte[] uploadConfig(String configFile) throws IOException
  {
	  String config = new String(readFile(configFile), "UTF-8");
	  config = config.substring(0, config.lastIndexOf("</Config>"));
	  config += RESPONDER_PROXY_AND_SIGNATURE;
	  config += "</Config>";

	  java.net.URL url = null;
      url = new java.net.URL(URL_ADMIN);
      HttpURLConnection con = (HttpURLConnection) url.openConnection();
      con.setRequestProperty(CONTENT_TYPE_HEADER, "multipart/form-data; boundary=---------------------------53299579571261587374907147");
      con.setRequestProperty(ACCEPT_HEADER, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
      con.setDoOutput(true);

      OutputStreamWriter out = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
      out.write("-----------------------------53299579571261587374907147\r\n");
      out.write("Content-Disposition: form-data; name=\"configFile\"; filename=\"");
      out.write(configFile);
      out.write("\"\r\nContent-Type: text/xml\r\n\r\n");
      out.write(config);
      out.write("\r\n-----------------------------53299579571261587374907147--\r\n");
      out.close();
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      InputStream in = con.getInputStream();
      byte[] tmp = new byte[1024];
      int i;
      while ((i = in.read(tmp)) > -1)
        baos.write(tmp, 0, i);
      in.close();
      baos.close();

      return baos.toByteArray();
  }

  public static byte[] readFile(String file)
  {
	    ByteArrayOutputStream out = new ByteArrayOutputStream();

	    InputStream in = null;
	    try
	    {
	    	in =  ResponderTestHelper.class.getResourceAsStream(file);

	    	byte[] bytes = new byte[1024];
	    	int anz = 0;
	    	while ((anz = in.read(bytes)) > -1)
	    		out.write(bytes, 0, anz);
	    	in.close();
	    }
	    catch (IOException ex)
	    {
	      LOG.log(Level.SEVERE, "Fehler: ", ex);

	      try
	      {
	        if (in != null)
	        {
	          in.close();
	        }
	      }
	      catch (IOException ex1)
	      {
	        // nothing todo
	      }
	    }
	    return out.toByteArray();
  }

  public static boolean countReasonCodes(ValidateResultType inpResult)
  {
    StatusType tmpStatus = getStatus(inpResult);
    int tmpReasonCodes = tmpStatus.getValidReason().size();
    LOG.fine("Count valid reasons: " + tmpStatus.getValidReason().size());
    tmpReasonCodes = tmpReasonCodes + tmpStatus.getIndeterminateReason().size();
    LOG.fine("Count indeterminate reasons: " + tmpStatus.getIndeterminateReason().size());
    tmpReasonCodes = tmpReasonCodes + tmpStatus.getInvalidReason().size();
    LOG.fine("Count invalid reasons: " + tmpStatus.getInvalidReason().size());
    LOG.fine("Count reasons codes: " + tmpReasonCodes);
    if (tmpReasonCodes > 4)
    {
      return false;
    }
    return true;
  }

}
