/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.testutils;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidParameterException;
import java.security.NoSuchProviderException;
import java.security.cert.CertPathBuilderException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.certificatepathvalidator.CertificatePathValidatorProcess;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.BuilderParameters;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.CertPath;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.CertPathBuilder;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.CertPathBuilderResult;
import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvCRLResult;
import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodCrlDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodOcspDto;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.TrustCenterRequester;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.crl.CRLRequester;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ocsp.OCSPRequester;


/*
 * Utility class to call methods within the server applications classloader context. To be used by
 * tests. <p>Copyright: Copyright (c) 2003 bremer online service GmbH</p>
 * @author aj
 * @version $Revision: 1.6 $
 */
public class TestSessionHelper
{
  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private static Logger LOG = Logger.getLogger(TestSessionHelper.class.getName());


  public CvOCSPResult doOCSPRequest(final byte[] issuer, final byte[] user,
                                    final ValMethodOcspDto validateMethod, final boolean ocspNoCache,
                                    Long _requestID) throws Exception
  {
    try
    {
      return OCSPRequester.doRequest(ResponderHelper.createCertificate(issuer), ResponderHelper.createCertificate(user),
                                     validateMethod, ocspNoCache, _requestID);
    }
    catch (Throwable e)
    {
      throw new Exception(e);
    }
  }


  public CvCRLResult doCRLRequest(final byte[] issuer, final byte[] user, final ValMethodCrlDto validateMethod)
        throws Exception
  {
    try
    {
      return CRLRequester.doRequest(ResponderHelper.createCertificate(issuer), ResponderHelper.createCertificate(user),
                                    validateMethod);
    }
    catch (Throwable e)
    {
      throw new Exception(e);
    }
  }

  public CertificatevalidatorResult processTrustCenterRequest(final byte[] issuer, final byte[] user,
                                                              final IssuerDto inpIssuerDto,
                                                              final boolean ocspNoCache, final Long _requestID)
        throws Exception
  {
    try
    {
      return TrustCenterRequester.processRequest(ResponderHelper.createCertificate(issuer),
                                                 ResponderHelper.createCertificate(user), inpIssuerDto, ocspNoCache,
                                                 _requestID);
    }
    catch (Throwable e)
    {
      throw new Exception(e);
    }
  }

  @SuppressWarnings("unchecked")
  public List buildPath(final ArrayList<byte[]> target, final ArrayList<byte[]> doNotUse) throws Exception
  {
    try
    {

      final X509Certificate[] tmpTarget = convertCertificates(target);
      final X509Certificate[] tmpDoNotUse = convertCertificates(doNotUse);
      return buildPath(tmpTarget, tmpDoNotUse).getCertificates();
    }
    catch (CertPathBuilderException e)
    {
      if (LOG.isLoggable(Level.SEVERE))
      {
        LOG.severe("buildPath() " + e);
      }
      throw e;
    }
  }

  public CPVResponse checkChain(CPVResponse response, CPVRequest request, String valModel) throws IOException
  {
    return CertificatePathValidatorProcess.checkChain(response, request, valModel);
  }

  /**
   * @param inpCertificates
   * @return
   * @throws Gov2InternalException
   */
  private X509Certificate[] convertCertificates(final ArrayList<byte[]> inpCertificates)
        throws CertificateException, NoSuchProviderException, ParseException, IOException
  {
    if (inpCertificates == null)
    {
      return null;
    }

    X509Certificate[] tmpCertificates = new X509Certificate[inpCertificates.size()];
    int i = 0;
    for (byte[] tmpCertificateBytes : inpCertificates)
    {
      X509Certificate tmpCertificate = ResponderHelper.createCertificate(tmpCertificateBytes);
      tmpCertificates[i++] = tmpCertificate;
    }
    return tmpCertificates;
  }

  /**
   * Build a CertificatePath.
   *
   * @param target Certificates that schould be used to build a valid CertPath
   * @param doNotUse Certificates that not be used when build a valid CertPath
   * @return a valid CertPath
   * @throws InvalidParameterException
   *
   * @todo Welche Exceptions sollen geworfen werden ?????
   */
  public CertPath buildPath(final X509Certificate[] target, final X509Certificate[] doNotUse)
        throws InvalidParameterException, InvalidAlgorithmParameterException, CertPathBuilderException
  {

    CertPathBuilder cpb = new CertPathBuilder();
    BuilderParameters params = new BuilderParameters(target, doNotUse);

    //Den CertPathBuilder initalisieren
    try
    {
      //      if(cpb == null){
      //        cpb = new CertPathBuilder();
      //      }
      CertPathBuilderResult result = cpb.build(params);
      CertPath path = result.getCertPath();

      return path;
    }
    catch (final CertPathBuilderException ex)
    {
      LOG.info("Could not build a valid certpath: " + ex.getMessage());

      throw ex;
    }
  }

}
