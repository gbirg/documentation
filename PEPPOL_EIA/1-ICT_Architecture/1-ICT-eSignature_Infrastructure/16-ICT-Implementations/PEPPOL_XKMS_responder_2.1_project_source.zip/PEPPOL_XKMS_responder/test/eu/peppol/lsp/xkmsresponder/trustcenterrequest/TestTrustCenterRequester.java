/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.security.cert.X509Certificate;
import java.util.Date;

import junit.framework.Assert;
import junit.framework.TestCase;
import eu.peppol.lsp.xkmsresponder.PeppolTestSuite;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodOcspDto;
import eu.peppol.lsp.xkmsresponder.testutils.TestSessionHelper;


/*
 * <p>TestTrustCenterRequester</p> <p>Tests to check the
 * trust center requests</p>
 * @author Andre Jens
 * @author Nils Buengener
 */
public class TestTrustCenterRequester extends TestCase
{

  private TestSessionHelper testSessionHelper;

  private static ValMethodOcspDto valmethod_telesec;

  private IssuerDto issuerClickAndTrust;

  @Override
  protected void setUp() throws Exception
  {
    super.setUp();
    testSessionHelper = new TestSessionHelper();
    PeppolTestSuite.loadConfig();
    valmethod_telesec =
        Configuration.getIssuerDto("TeleSec acc")
                            .getValMethodOcspDto();
    issuerClickAndTrust =
        Configuration.getIssuerDto("BANQUE FEDERALE DES BANQUES POPULAIRES");
  }

  /**
   * Performs a OCSP request for a valid certificate and checks the result status 'valid'
   * and the the returned valid reason "revocation status".
   */
  public void testOCSPValid() throws Exception
  {
    try
    {
      X509Certificate userCert_telesec = loadCert("peppol/user-TeleSec-PKS-SigG-CA-13.crt");
      X509Certificate issuerCert_telesec = loadCert("peppol/TeleSec_PKS_SigG_CA_13_PN.crt");
      CvOCSPResult actualReturn = doRequestOCSP(userCert_telesec, issuerCert_telesec, valmethod_telesec);
      assertEquals("Is Certificate valid", CertificatevalidatorResult.STATUS_VALID, actualReturn.getStatus());
      assertTrue("Valid Reason Revocation status present",
                 actualReturn.getValidReason()
                             .contains(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS));
    }
    catch (IllegalArgumentException ex)
    {
      ex.printStackTrace();
      Assert.fail("IllegalArgument");
    }
  }

  /**
   * Performs a OCSP request for an invalid certificate and checks the result status 'invalid'
   * and the the returned invalid reason "revocation status".
   */
  public void testOCSPRevoked() throws Exception
  {
    try
    {
      X509Certificate userCert_telesec = loadCert("peppol/telesec_gesperrt.crt");
      X509Certificate issuerCert_telesec = loadCert("peppol/TeleSec_PKS_SigG_CA_13_PN.crt");
      CvOCSPResult actualReturn = doRequestOCSP(userCert_telesec, issuerCert_telesec, valmethod_telesec);

      assertEquals("Is Certificate invalid", CertificatevalidatorResult.STATUS_INVALID,
                   actualReturn.getStatus());
      assertTrue("Invalid Reason Revocation status present",
                 actualReturn.getInvalidReason()
                             .contains(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS));
    }
    catch (IllegalArgumentException ex)
    {
    	ex.printStackTrace();
      Assert.fail("IllegalArgument");
    }
  }

  /**
   * Performs a OCSP request for a revoked certificate and checks the result status 'invalid'
   * and the returned invalid reason "revocation status".
   */
  public void testCRLRevoked() throws Exception
  {


    X509Certificate user_revoked = loadCert("France/ClickAndTrust/Admineo_User.crt");
    X509Certificate issuer_valid = loadCert("France/ClickAndTrust/AC_C&T_TVA_170908_ca.crt");
    CertificatevalidatorResult actualReturn = doRequestCrl(user_revoked, issuer_valid, issuerClickAndTrust);
    assertEquals("return value", CertificatevalidatorResult.STATUS_INVALID, actualReturn.getStatus());
    assertTrue("Invalid Reason",
               actualReturn.getInvalidReason()
                           .contains(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS));
  }

  /**
   * Performs a CRL request for a revoked certificate and checks the result for
   * the returned invalid reason "revocation status".
   */
  private CertificatevalidatorResult doRequestCrl(X509Certificate user_valid, X509Certificate issuer_valid,
                                                  IssuerDto inpIssuerDto) throws Exception
  {
    CertificatevalidatorResult actualReturn =
          testSessionHelper.processTrustCenterRequest(issuer_valid.getEncoded(), user_valid.getEncoded(),
                                                      inpIssuerDto, false,
                                                      Long.valueOf(System.currentTimeMillis()));

    return actualReturn;
  }

  /**
   * @param inpUserCert
   * @param inpIssuerCert
   * @param inpValmethod
   * @return
   * @throws ClassNotFoundException
   * @throws IllegalAccessException
   * @throws InstantiationException
   * @throws NoSuchMethodException
   * @throws InvocationTargetException
   * @throws RemoteException
   */
  private CvOCSPResult doRequestOCSP(X509Certificate inpUserCert, X509Certificate inpIssuerCert,
                                     ValMethodOcspDto inpValmethod) throws Exception
  {
    CvOCSPResult actualReturn =
          testSessionHelper.doOCSPRequest(inpIssuerCert.getEncoded(), inpUserCert.getEncoded(), inpValmethod,
                                          false, Long.valueOf(new Date().getTime()));

    return actualReturn;
  }

  private X509Certificate loadCert(String inpFilename) throws Exception
  {
    return ResponderHelper
                 .createCertificate(TestTrustCenterRequester.class
                                                                     .getResourceAsStream("/certificates/"
                                                                                          + inpFilename));
  }

  public static void main(String[] args)
{
	try
	{
		TestTrustCenterRequester t = new TestTrustCenterRequester();
		t.setUp();
		t.testOCSPValid();
		t.tearDown();
	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
}

}
